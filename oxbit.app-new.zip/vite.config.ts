import { defineConfig, Plugin } from 'vite'
import react from '@vitejs/plugin-react'
import { parse as parseUrl } from 'node:url'

function proxyPlugin(): Plugin {
  return {
    name: 'oxbit-proxy',
    configureServer(server) {
      const ALLOW = new Set([
        'query1.finance.yahoo.com',
        'query2.finance.yahoo.com',
        'finance.yahoo.com',
        'api.binance.com',
        'fapi.binance.com',
        'api.coingecko.com',
        'www.okx.com',
        'api.exchange.coinbase.com',
        's3.tradingview.com',
        'www.google.com',
        'stooq.com',
        'stooq.pl',
      ])

      server.middlewares.use('/api/proxy', async (req, res) => {
        try {
          const urlParam = new URL(req.url!, 'http://local').searchParams.get('url')
          if (!urlParam) {
            res.statusCode = 400
            res.end('missing url')
            return
          }
          const target = new URL(urlParam)
          if (!/^https?:$/.test(target.protocol)) {
            res.statusCode = 400
            res.end('invalid protocol')
            return
          }
          if (!ALLOW.has(target.hostname)) {
            res.statusCode = 403
            res.end('host not allowed')
            return
          }
          const r = await fetch(target.toString(), {
            headers: {
              'user-agent': 'oxbit-proxy/1.0 (+vite dev)',
              'accept': 'application/json,text/plain,*/*',
              'accept-language': 'ko,en;q=0.9',
            },
          })
          res.statusCode = r.status
          // forward content-type if present
          const ct = r.headers.get('content-type')
          if (ct) res.setHeader('content-type', ct)
          // allow browser to cache briefly
          res.setHeader('cache-control', 'public, max-age=15')
          const buf = Buffer.from(await r.arrayBuffer())
          res.end(buf)
        } catch (e: any) {
          res.statusCode = 502
          res.end('proxy error')
        }
      })
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), proxyPlugin()],
})
