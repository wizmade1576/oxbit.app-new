import { create } from 'zustand'
import { supabase } from '../services/supabase'
import { upsertProfileFromUser } from '../services/profileService'

export const useAuthStore = create((set, get) => ({
  user: null,
  isAdmin: false,
  init: async () => {
    const { data } = await supabase.auth.getUser()
    const user = data?.user || null
    set({ user, isAdmin: !!user?.app_metadata?.claims?.admin })
  },
  // 이메일 링크(OTP) 로그인
  signInWithOtp: async (email) => {
    await supabase.auth.signInWithOtp({ email })
  },
  // 이메일/비밀번호 로그인
  signInWithPassword: async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    set({ user: data?.user || null, isAdmin: !!data?.user?.app_metadata?.claims?.admin })
    // Best-effort: ensure profiles row exists from user metadata
    if (data?.user) {
      try { await upsertProfileFromUser(data.user) } catch (_) {}
    }
    return data
  },
  // 회원가입
  signUpWithEmail: async (email, password, profile = {}) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: profile },
    })
    if (error) throw error
    // If signup does not require email verification, user may be present
    if (data?.user) {
      try { await upsertProfileFromUser(data.user) } catch (_) {}
    }
    return data
  },
  signOut: async () => {
    await supabase.auth.signOut()
    set({ user: null, isAdmin: false })
  },
  // SMS OTP 전송 (회원가입 전 본인인증 용도)
  sendSmsOtp: async (phone) => {
    const { error } = await supabase.auth.signInWithOtp({ phone, options: { shouldCreateUser: false } })
    if (error) throw error
    return true
  },
  // SMS OTP 검증
  verifySmsOtp: async (phone, code) => {
    const { data, error } = await supabase.auth.verifyOtp({ phone, token: code, type: 'sms' })
    if (error) throw error
    return !!data?.session
  },
  // 비밀번호 재설정 이메일 전송
  resetPasswordForEmail: async (email, redirectTo) => {
    const { data, error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo })
    if (error) throw error
    return data
  },
}))
