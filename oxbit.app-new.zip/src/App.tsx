import React, { Fragment } from 'react'
import { createBrowserRouter, RouterProvider, Outlet, Navigate } from 'react-router-dom'
import { QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { queryClient } from './queryClient'

// Layout UI
import Header from './components/HeaderWithTheme.jsx'
import MobileBottomNav from './components/nav/MobileBottomNav.jsx'
import Footer from './components/Footer.jsx'

// Common pages
import Home from './pages/Home.jsx'
import SearchPage from './pages/SearchPage.jsx'
import NewsDetail from './pages/NewsDetail.jsx'
import Community from './components/Community.jsx'
import CommunityDetail from './pages/CommunityDetail.jsx'
import Live from './pages/Live.jsx'

import Login from './pages/Login.jsx'
import ResetPassword from './pages/ResetPassword.jsx'
import Signup from './pages/Signup.jsx'
import ResetPasswordConfirm from './pages/ResetPasswordConfirm.jsx'
import ProfileEdit from './pages/ProfileEdit.jsx'
import Terms from './pages/legal/Terms.jsx'
import Privacy from './pages/legal/Privacy.jsx'
import NotFound from './pages/NotFound.jsx'

// Admin shell & pages
import AdminShell from './admin/AdminShell.jsx'
import AdminDiag from './pages/AdminDiag.jsx'
import AdminSetup from './pages/AdminSetup.jsx'
import AdminDashboardPage from './admin/pages/Dashboard.jsx'
import AdminNewsPage from './admin/pages/News.jsx'
import AdminEventsPage from './admin/pages/Events.jsx'
import AdminPositionsDbPage from './admin/pages/AdminPositionsDb.jsx'
import AdminWhalesPage from './admin/pages/Whales.jsx'
import AdminCommunityPage from './admin/pages/Community.jsx'
import AdminAdsPage from './admin/pages/Ads.jsx'
import AdminUsers from './admin/routes/AdminUsers.jsx'
import AdminLogs from './admin/routes/AdminLogs.jsx'
import AdminSettingsPage from './admin/pages/Settings.jsx'

// Market sub pages
import MarketIndex from './pages/Market/Index.jsx'
import SpotKR from './pages/Market/SpotKR.jsx'
import SpotGlobal from './pages/Market/SpotGlobal.jsx'
import Futures from './pages/Market/Futures.jsx'
import Stock from './pages/Market/Stock.jsx'
import Schedule from './pages/Market/Schedule.jsx'
import KimchiPage from './pages/Market/Kimchi.jsx'

// Positions pages
import PositionsWhales from './pages/positions/Whales.jsx'
import PositionsFearGreed from './pages/positions/FearGreed.jsx'

// Extras
import ResponsiveHome from './pages/ResponsiveHome.jsx'
import MockTrading from './pages/MockTrading.jsx'

// Breaking (속보) — consolidated entry
import { BreakingList as Breaking, BreakingDetail, BreakingHomeMobile } from './features/breaking'

function MainLayout() {
  return (
    <>
      <Header />
      <main className="ox-container py-6">
        <Outlet />
      </main>
      <MobileBottomNav />
      <Footer />
    </>
  )
}

export default function App() {
  const router = createBrowserRouter([
    { path: '/search', element: <SearchPage /> },
    { path: '/__admin/diag', element: <AdminDiag /> },
    { path: '/admin/setup', element: <AdminSetup /> },
    {
      path: '/',
      element: <MainLayout />,
      children: [
        { index: true, element: <ResponsiveHome /> },
        { path: 'breaking', element: <Breaking /> },
        { path: 'breaking/mobile', element: <BreakingHomeMobile /> },
        { path: 'breaking/detail', element: <BreakingDetail /> },
        { path: 'news/detail', element: <NewsDetail /> },
        // Market routes
        { path: 'market', element: <Navigate to="/market/stock" replace /> },
        { path: 'market/spot-kr', element: <SpotKR /> },
        { path: 'market/spot-global', element: <SpotGlobal /> },
        { path: 'market/stock', element: <Stock /> },
        { path: 'market/kimchi', element: <KimchiPage /> },
        { path: 'market/kimchi/*', element: <KimchiPage /> },
        { path: 'market/futures', element: <Futures /> },
        { path: 'market/schedule', element: <Schedule /> },
        // Positions
        { path: 'positions', element: <Navigate to="/mock" replace /> },
        { path: 'positions/whales', element: <PositionsWhales /> },
        { path: 'positions/feargreed', element: <PositionsFearGreed /> },
        // Community
        { path: 'community', element: <Community /> },
        { path: 'community/post/:id', element: <CommunityDetail /> },
        // Others
        { path: 'live', element: <Live /> },
        { path: 'login', element: <Login /> },
        { path: 'signup', element: <Signup /> },
        { path: 'reset-password', element: <ResetPassword /> },
        { path: 'reset-password/confirm', element: <ResetPasswordConfirm /> },
        { path: 'profile/edit', element: <ProfileEdit /> },
        { path: 'legal/terms', element: <Terms /> },
        { path: 'legal/privacy', element: <Privacy /> },
        { path: 'mock', element: <MockTrading /> },
        { path: '*', element: <NotFound /> },
      ],
    },
    {
      path: '/admin',
      element: <AdminShell />,
      children: [
        { index: true, element: <AdminDashboardPage /> },
        { path: 'dashboard', element: <AdminDashboardPage /> },
        { path: 'news', element: <AdminNewsPage /> },
        { path: 'events', element: <AdminEventsPage /> },
        { path: 'positions', element: <AdminPositionsDbPage /> },
        { path: 'whales', element: <AdminWhalesPage /> },
        { path: 'community', element: <AdminCommunityPage /> },
        { path: 'ads', element: <AdminAdsPage /> },
        { path: 'users', element: <AdminUsers /> },
        { path: 'logs', element: <AdminLogs /> },
        { path: 'settings', element: <AdminSettingsPage /> },
        { path: '*', element: <NotFound /> },
      ],
    },
  ])

  return (
    <div className="min-h-screen bg-[#0F1114] text-gray-200">
      <QueryClientProvider client={queryClient}>
        <RouterProvider router={router} />
        {import.meta?.env?.DEV && (
          <ReactQueryDevtools initialIsOpen={false} buttonPosition="bottom-right" />
        )}
      </QueryClientProvider>
    </div>
  )
}


