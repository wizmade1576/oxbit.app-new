import React from 'react'
import Home from './Home.jsx'
import Breaking from './Breaking.jsx'

export default function ResponsiveHome() {
  const isMobile = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(max-width: 768px)').matches
  if (isMobile) return <Breaking />
  return <Home />
}

