import React from 'react'
import { supabase } from '../services/supabase'

export default function AdminDiag() {
  const [info, setInfo] = React.useState({})
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    (async () => {
      try {
        const { data: userData } = await supabase.auth.getUser()
        const user = userData?.user || null
        let role = null
        if (user?.id) {
          const { data: prof } = await supabase.from('profiles').select('role').eq('id', user.id).maybeSingle()
          role = prof?.role ?? null
        }
        const bypass = typeof localStorage !== 'undefined' ? localStorage.getItem('ADMIN_BYPASS') : null
        setInfo({
          userId: user?.id || null,
          email: user?.email || null,
          appMetaAdmin: !!user?.app_metadata?.claims?.admin,
          profilesRole: role,
          adminBypass: bypass,
        })
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  return (
    <section className="mx-auto max-w-xl w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-3">
        <h1 className="text-lg font-semibold">Admin 진단</h1>
        {loading ? (
          <div className="text-sm text-gray-400">확인 중…</div>
        ) : (
          <div className="text-sm text-gray-300 space-y-1">
            <div><span className="text-gray-400">userId:</span> {String(info.userId)}</div>
            <div><span className="text-gray-400">email:</span> {String(info.email)}</div>
            <div><span className="text-gray-400">appMetaAdmin:</span> {String(info.appMetaAdmin)}</div>
            <div><span className="text-gray-400">profiles.role:</span> {String(info.profilesRole)}</div>
            <div><span className="text-gray-400">ADMIN_BYPASS:</span> {String(info.adminBypass)}</div>
          </div>
        )}
        <div className="pt-2 text-xs text-gray-400">
          개발용: 브라우저 콘솔에서 <code>localStorage.setItem('ADMIN_BYPASS','1')</code> 후 /admin 이동
        </div>
      </div>
    </section>
  )
}

