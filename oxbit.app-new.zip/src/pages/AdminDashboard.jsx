import { useAuthStore } from '../store/useAuthStore';
import { useState, useEffect } from 'react';
import { supabase } from '../services/supabase';

export default function AdminDashboard() {
  const { user, isAdmin } = useAuthStore();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isAdmin) {
      loadUsers();
    }
  }, [isAdmin]);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.from('users').select('*');
      setUsers(data);
    } catch (error) {
      console.error('사용자를 불러오는데 실패했습니다:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isAdmin) return <div>관리자 권한이 필요합니다.</div>;

  return (
    <section className="p-6 space-y-4">
      <h2 className="text-lg font-semibold">관리자 대시보드</h2>
      <div className="text-sm text-gray-400">로그인: {user ? user.email : '미로그인'}</div>

      <div className="mt-4">
        <h3 className="font-semibold text-md">사용자 목록</h3>
        {loading ? (
          <p>불러오는 중...</p>
        ) : (
          <ul>
            {users.map((u) => (
              <li key={u.id} className="border-b py-2">{u.email}</li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
