import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="min-h-full grid place-items-center p-8">
      <div className="text-center space-y-4">
        <h1 className="text-2xl font-semibold">페이지를 찾을 수 없습니다</h1>
        <p className="opacity-70">요청하신 경로가 존재하지 않습니다.</p>
        <Link className="text-blue-600 hover:underline" to="/">홈으로 돌아가기</Link>
      </div>
    </div>
  )
}

