import React from 'react'

export default function MockTrading() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-8 text-zinc-200">
        <h1 className="mb-3 text-xl font-semibold">모의투자</h1>
        <p className="leading-7">
          이 페이지는 준비중입니다. </p>
         <p> 빠른 시일내에 찾아뵙도록 하겠습니다.
        </p>
      </div>
    </div>
  )
}

