﻿import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchSpotTickers } from '../services/marketService'
import SearchBar from '../components/SearchBarClean.jsx'
import CoinRow from '../components/CoinRowFixed.jsx'
import KimpTab from '../components/KimpTab.jsx'
import Futures from '../Market/Futures.jsx'
import Schedule from '../Market/Schedule.jsx'

export default function Market() {
  const [tab, setTab] = useState('coin')
  const [region, setRegion] = useState('krw')
  const [rate] = useState(1350)
  const [q, setQ] = useState('')
  const [sortKey, setSortKey] = useState('volume')
  const [sortDir, setSortDir] = useState('desc')
  const [visible, setVisible] = useState(60)
  const sentinelRef = useRef(null)

  const { data = [], isLoading } = useQuery({
    queryKey: ['market:tickers', { exchange: 'binance' }],
    queryFn: () => fetchSpotTickers('binance'),
    staleTime: 30000,
    refetchInterval: 60000,
  })

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase()
    if (!s) return data
    return data.filter((it) =>
      (it.base || '').toLowerCase().includes(s) ||
      (it.symbol || '').toLowerCase().includes(s)
    )
  }, [data, q])

  const upDown = useMemo(() => {
    let up = 0, down = 0
    for (const it of filtered) {
      if (!isFinite(it.changePct)) continue
      if (it.changePct > 0) up++
      else if (it.changePct < 0) down++
    }
    return { up, down }
  }, [filtered])

  const sorted = useMemo(() => {
    const arr = [...filtered]
    const pick = (it) =>
      sortKey === 'price'
        ? it.last
        : sortKey === 'change'
        ? it.changePct
        : it.quoteVolume

    arr.sort((a, b) => {
      const av = pick(a), bv = pick(b)
      return (isFinite(av) ? av : -Infinity) - (isFinite(bv) ? bv : -Infinity)
    })

    if (sortDir === 'desc') arr.reverse()
    return arr
  }, [filtered, sortKey, sortDir])

  useEffect(() => { setVisible(60) }, [q, sortKey, sortDir])

  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting)
          setVisible((v) => Math.min(v + 60, sorted.length))
      })
    }, { rootMargin: '200px' })
    io.observe(el)
    return () => io.disconnect()
  }, [sorted.length])

  const toggleSort = (key) => {
    setSortKey((prev) => (prev === key ? prev : key))
    setSortDir((prev) =>
      sortKey === key ? (prev === 'asc' ? 'desc' : 'asc') : 'desc'
    )
  }

  const arrow = (key) => {
    if (sortKey !== key) return ''
    return sortDir === 'asc' ? '▲' : '▼'
  }

  const breadcrumb = useMemo(() => {
    if (tab === 'coin') return region === 'krw' ? '현물(국내)' : '현물(글로벌)'
    if (tab === 'kimchi') return '김프'
    if (tab === 'futures') return '선물'
    if (tab === 'schedule') return '일정'
    return ''
  }, [tab, region])

  const pathHint = useMemo(() => {
    if (tab === 'coin') return region === 'krw' ? '/market/spot-kr' : '/market/spot-global'
    if (tab === 'kimchi') return '/market/kimchi'
    if (tab === 'futures') return '/market/futures'
    if (tab === 'schedule') return '/market/schedule'
    return '/market'
  }, [tab, region])

  return (
    <section className="space-y-4">
      <div className="space-y-1">
        <h1 className="text-xl font-bold text-gray-100">마켓 · {breadcrumb}</h1>
        <div className="text-xs text-gray-400">{pathHint}</div>

        <div className="mt-2 flex items-center gap-2">
          {[
            { key: 'coin', label: '코인' },
            { key: 'kimchi', label: '김프' },
            { key: 'futures', label: '선물' },
            { key: 'schedule', label: '일정' },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-3 py-2 rounded-md text-sm border ${
                tab === t.key
                  ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white'
                  : 'border-white/10 text-gray-300 hover:bg-white/10'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === 'coin' && (
        <div className="sticky top-6 z-10 bg-[#0F1114]/90 backdrop-blur border-b border-white/5 py-0">
          <div className="ox-container px-0">
            <div className="flex items-center justify-between gap-3">
              <div className="inline-flex rounded-md overflow-hidden border border-white/10">
                <button
                  onClick={() => setRegion('krw')}
                  className={`px-3 py-2 text-sm ${
                    region === 'krw'
                      ? 'bg-[#1D6FEA] text-white'
                      : 'text-gray-300 hover:bg-white/10'
                  }`}
                >
                  현물(국내)
                </button>
                <button
                  onClick={() => setRegion('global')}
                  className={`px-3 py-2 text-sm ${
                    region === 'global'
                      ? 'bg-[#1D6FEA] text-white'
                      : 'text-gray-300 hover:bg-white/10'
                  }`}
                >
                  현물(글로벌)
                </button>
              </div>

              <div className="hidden sm:block w-80">
                <SearchBar value={q} onChange={setQ} />
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-2 py-1 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  상승 {upDown.up}
                </span>
                <span className="px-2 py-1 rounded bg-rose-500/15 text-rose-300 border border-rose-500/30">
                  하락 {upDown.down}
                </span>
              </div>
            </div>

            <div className="sm:hidden mt-2">
              <SearchBar value={q} onChange={setQ} />
            </div>
          </div>
        </div>
      )}

      {tab === 'coin' ? (
        <>
          {/* Desktop */}
          <div className="hidden md:block">
            <div className="rounded-xl border border-white/10 overflow-hidden bg-[#0F1114]">
              <table className="w-full text-sm">
                <thead className="bg-black/20 text-gray-400">
                  <tr className="divide-x divide-white/5">
                    <th className="px-3 py-2 text-left w-12">#</th>
                    <th className="px-3 py-2 text-left">코인명</th>
                    <th className="px-3 py-2 text-right cursor-pointer" onClick={() => toggleSort('price')}>
                      가격 {arrow('price')}
                    </th>
                    <th className="px-3 py-2 text-right cursor-pointer" onClick={() => toggleSort('change')}>
                      변동률 {arrow('change')}
                    </th>
                    <th className="px-3 py-2 text-right cursor-pointer" onClick={() => toggleSort('volume')}>
                      24H 거래량 {arrow('volume')}
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-white/10">
                  {sorted.slice(0, visible).map((it, i) => (
                    <CoinRow key={it.symbol} item={it} index={i} region={region} krwRate={rate} view="table" />
                  ))}
                </tbody>
              </table>

              <div ref={sentinelRef} className="h-10" />

              {visible < sorted.length && (
                <div className="p-3 text-center">
                  <button
                    onClick={() => setVisible((v) => Math.min(v + 60, sorted.length))}
                    className="px-4 py-2 rounded-md border border-white/10 text-sm text-gray-200 hover:bg-white/10"
                  >
                    더보기
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Mobile */}
          <div className="md:hidden grid grid-cols-1 sm:grid-cols-2 gap-3">
            {sorted.slice(0, visible).map((it, i) => (
              <CoinRow key={it.symbol} item={it} index={i} region={region} krwRate={rate} view="card" />
            ))}

            <div ref={sentinelRef} className="col-span-full h-10" />

            {visible < sorted.length && (
              <div className="col-span-full p-2 text-center">
                <button
                  onClick={() => setVisible((v) => Math.min(v + 60, sorted.length))}
                  className="px-4 py-2 rounded-md border border-white/10 text-sm text-gray-200 hover:bg-white/10"
                >
                  더보기
                </button>
              </div>
            )}
          </div>

          {isLoading && <div className="text-sm text-gray-400">불러오는 중…</div>}
          {!isLoading && sorted.length === 0 && <div className="text-sm text-gray-400">표시할 코인이 없습니다.</div>}
        </>
      ) : tab === 'kimchi' ? (
        <KimpTab />
      ) : tab === 'futures' ? (
        <Futures />
      ) : tab === 'schedule' ? (
        <Schedule />
      ) : (
        <div className="rounded-xl border border-white/10 bg-[#0F1114] min-h-[40vh] flex items-center justify-center p-6">
          <div className="text-sm text-gray-300">해당 UI는 준비 중입니다.</div>
        </div>
      )}
    </section>
  )
}






