import React from 'react'

export default function Terms() {
  return (
    <section className="mx-auto max-w-3xl w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <h1 className="text-xl font-semibold">서비스 이용약관</h1>
        <div className="prose prose-invert max-w-none text-sm leading-6 text-gray-300">
          <p>본 약관은 서비스 이용과 관련하여 회사와 이용자 간의 권리, 의무 및 책임사항을 규정합니다.</p>
          <h3>제1조 (목적)</h3>
          <p>이 약관은 회사가 제공하는 모든 온라인 서비스의 이용에 관한 조건과 절차를 정함을 목적으로 합니다.</p>
          <h3>제2조 (계정 및 보안)</h3>
          <ul>
            <li>이용자는 계정 정보의 기밀성을 유지할 책임이 있습니다.</li>
            <li>허가되지 않은 사용이 의심되는 경우 즉시 회사에 알려야 합니다.</li>
          </ul>
          <h3>제3조 (콘텐츠 이용)</h3>
          <ul>
            <li>콘텐츠의 무단 복제, 배포, 변형은 금지됩니다.</li>
            <li>서비스 내 제공되는 정보는 투자 조언이 아닙니다.</li>
          </ul>
          <h3>제4조 (책임의 제한)</h3>
          <p>회사는 불가항력 및 이용자 과실로 인한 손해에 대해 책임지지 않습니다.</p>
          <h3>제5조 (기타)</h3>
          <p>세부 조항은 실제 서비스 정책에 맞춰 추가/수정해 주세요.</p>
        </div>
      </div>
    </section>
  )
}

