import React from 'react'

export default function Privacy() {
  return (
    <section className="mx-auto max-w-3xl w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <h1 className="text-xl font-semibold">개인정보 처리방침</h1>
        <div className="prose prose-invert max-w-none text-sm leading-6 text-gray-300">
          <p>회사는 이용자의 개인정보를 보호하기 위해 관련 법령을 준수하며, 다음과 같이 개인정보를 처리합니다.</p>
          <h3>수집 항목 및 목적</h3>
          <ul>
            <li>필수: 이메일, 비밀번호(해시) — 계정 생성 및 인증</li>
            <li>선택: 닉네임, 전화번호, 성별, 관심분야 — 서비스 맞춤 제공</li>
          </ul>
          <h3>보관 기간</h3>
          <p>회원 탈퇴 시 또는 법령이 정한 기간까지 보관 후 파기합니다.</p>
          <h3>제3자 제공</h3>
          <p>법령에 의한 경우를 제외하고 사전 동의 없이 제공하지 않습니다.</p>
          <h3>정보주체의 권리</h3>
          <p>이용자는 개인정보 열람, 정정, 삭제, 처리정지 등을 요청할 수 있습니다.</p>
          <p>실제 방침 전문은 서비스 정책에 맞게 업데이트해 주세요.</p>
        </div>
      </div>
    </section>
  )
}

