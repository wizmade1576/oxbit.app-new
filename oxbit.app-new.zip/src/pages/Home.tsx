export default function Home() {
  return (
    <div className="min-h-full grid place-items-center p-8 bg-white text-gray-900 dark:bg-gray-950 dark:text-gray-100">
      <div className="text-center space-y-4">
        <h1 className="text-3xl sm:text-4xl font-bold">React + Vite + Tailwind</h1>
        <p className="text-base opacity-80">프로젝트가 성공적으로 설정되었습니다.</p>
        <div className="flex items-center justify-center gap-3">
          <a className="text-blue-600 hover:underline" href="https://react.dev" target="_blank" rel="noreferrer">React</a>
          <span>·</span>
          <a className="text-blue-600 hover:underline" href="https://vite.dev" target="_blank" rel="noreferrer">Vite</a>
          <span>·</span>
          <a className="text-blue-600 hover:underline" href="https://tailwindcss.com" target="_blank" rel="noreferrer">Tailwind</a>
        </div>
      </div>
    </div>
  )
}

