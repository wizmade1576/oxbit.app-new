import React, { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { listBreaking, subscribeBreaking } from '../services/breakingService'

export default function Breaking() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [visible, setVisible] = useState(30)

  // UI state
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('all') // all | public | private
  const [importantOnly, setImportantOnly] = useState(false)

  // Load initial data
  useEffect(() => {
    let active = true
    async function load() {
      try {
        setLoading(true)
        // Fetch a reasonable window then filter client-side
        const data = await listBreaking({ limit: 200 })
        if (!active) return
        setItems(Array.isArray(data) ? data : [])
      } catch (e) {
        if (!active) return
        setError(e?.message || '로딩 오류가 발생했습니다.')
      } finally {
        if (active) setLoading(false)
      }
    }
    load()

    const unsub = subscribeBreaking((payload) => {
      if (!active) return
      const rec = payload?.new || payload?.record || payload
      if (!rec) return
      setItems((prev) => {
        const exists = prev.some((p) => p.id === rec.id)
        const next = exists ? prev.map((p) => (p.id === rec.id ? rec : p)) : [rec, ...prev]
        return next.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      })
    })

    return () => {
      active = false
      try { unsub?.() } catch {}
    }
  }, [])

  const filtered = useMemo(() => {
    let data = items
    if (status !== 'all') {
      data = data.filter((it) => (status === 'public' ? it.status === 'public' : it.status !== 'public'))
    }
    if (importantOnly) {
      data = data.filter((it) => !!it.important)
    }
    if (q.trim()) {
      const s = q.trim().toLowerCase()
      data = data.filter((it) =>
        (it.title || '').toLowerCase().includes(s) || (it.body || '').toLowerCase().includes(s)
      )
    }
    return data
  }, [items, status, importantOnly, q])

  const canLoadMore = filtered.length > visible
  const shown = filtered.slice(0, visible)

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <header className="mb-4 flex flex-wrap items-center gap-3">
        <h1 className="mr-auto text-2xl font-semibold">속보</h1>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="검색(제목/본문)"
          className="w-56 rounded border border-zinc-700 bg-zinc-900 px-3 py-1 text-sm outline-none focus:border-zinc-500"
        />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded border border-zinc-700 bg-zinc-900 px-3 py-1 text-sm"
        >
          <option value="all">전체</option>
          <option value="public">공개</option>
          <option value="private">비공개</option>
        </select>
        <label className="flex items-center gap-2 text-sm text-zinc-300">
          <input
            type="checkbox"
            checked={importantOnly}
            onChange={(e) => setImportantOnly(e.target.checked)}
          />
          중요만
        </label>
      </header>

      <section className="rounded-lg border border-zinc-800 bg-zinc-900">
        {loading ? (
          <p className="p-4">불러오는 중…</p>
        ) : error ? (
          <p className="p-4 text-red-400">{error}</p>
        ) : filtered.length === 0 ? (
          <p className="p-4 text-zinc-400">표시할 속보가 없습니다.</p>
        ) : (
          <>
          <ul className="divide-y divide-zinc-800">
            {shown.map((it) => (
              <li key={it.id} className="p-4 hover:bg-white/5">
                <Link to={`/breaking/detail?id=${it.id}`}>
                  <div className="flex items-center justify-between gap-4">
                    <h3 className="line-clamp-2 text-base font-medium">
                      {it.title}
                      {it.important ? (
                        <span className="ml-2 align-middle text-xs text-red-300">중요</span>
                      ) : null}
                    </h3>
                    <time className="whitespace-nowrap text-xs text-zinc-500">
                      {it.created_at ? new Date(it.created_at).toLocaleString() : ''}
                    </time>
                  </div>
                  {it.body ? (
                    <p className="mt-1 line-clamp-2 text-sm text-zinc-400">{it.body}</p>
                  ) : null}
                </Link>
              </li>
            ))}
          </ul>
          {canLoadMore && (
            <div className="border-t border-zinc-800 p-4 text-center">
              <button
                className="rounded bg-white/10 px-4 py-2 text-sm hover:bg-white/20"
                onClick={() => setVisible((v) => v + 30)}
              >
                더보기
              </button>
            </div>
          )}
          </>
        )}
      </section>
    </div>
  )
}
