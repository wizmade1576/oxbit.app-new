import React from 'react'
import { supabase } from '../services/supabase'
import { useAuthStore } from '../store/useAuthStore'

export default function AdminSetup() {
  const { user, init, signInWithPassword, signUpWithEmail } = useAuthStore()
  const [loading, setLoading] = React.useState(true)
  const [adminCount, setAdminCount] = React.useState(0)
  const [error, setError] = React.useState('')
  const [notice, setNotice] = React.useState('')

  // 로그인 폼
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')

  React.useEffect(() => {
    (async () => {
      try {
        await init()
        const { count } = await supabase
          .from('profiles')
          .select('id', { count: 'exact', head: true })
          .eq('role', 'admin')
        setAdminCount(count || 0)
      } finally {
        setLoading(false)
      }
    })()
  }, [init])

  const login = async (e) => {
    e.preventDefault(); setError(''); setNotice('')
    const DEV = !!(import.meta && import.meta.env && import.meta.env.DEV)
    const BOOT = DEV || String(import.meta?.env?.VITE_DEV_ADMIN_BOOTSTRAP || '') === '1'
    try {
      // 개발 전용 부트스트랩: admin/1234로 최초 1명 자동 생성 + 권한 부여
      if (BOOT && adminCount === 0 && (email === 'admin' || email === 'admin@local' || email === 'admin@example.com') && password === '1234') {
        const adminEmail = email.includes('@') ? email : 'admin@local'
        try { await signUpWithEmail(adminEmail, password) } catch (_) {}
        await signInWithPassword(adminEmail, password)
        // 권한 부여
        const uid = (await supabase.auth.getUser()).data?.user?.id
        if (uid) {
          await supabase.from('profiles').upsert({ id: uid, role: 'admin', updated_at: new Date().toISOString() })
          setAdminCount(1)
          setNotice('개발용 기본 관리자(admin/1234)가 활성화되었습니다. /admin으로 이동해 주세요.')
          return
        }
      }
      // 일반 로그인
      await signInWithPassword(email, password)
      setNotice('로그인 성공')
    } catch (err) {
      setError(err?.message || '로그인 실패')
    }
  }

  const signup = async (e) => {
    e.preventDefault(); setError(''); setNotice('')
    try {
      const res = await signUpWithEmail(email, password)
      // 이메일 인증이 꺼져 있으면 바로 세션이 생기므로 자동 로그인 시도
      try {
        await signInWithPassword(email, password)
        setNotice('계정이 생성되어 자동 로그인되었습니다.')
        // 관리자 수 갱신
        const { count } = await supabase
          .from('profiles')
          .select('id', { count: 'exact', head: true })
          .eq('role', 'admin')
        setAdminCount(count || 0)
      } catch (_) {
        // 이메일 인증이 필요한 프로젝트인 경우
        setNotice('계정이 생성되었습니다. 이메일 인증이 필요한 설정이면 메일에서 확인 후 로그인하세요.')
      }
    } catch (err) {
      setError(err?.message || '회원가입 실패')
    }
  }

  const makeMeAdmin = async () => {
    setError(''); setNotice('')
    try {
      if (!user?.id) { setError('먼저 로그인해 주세요'); return }
      if (adminCount > 0) {
        // 최초 1명만 앱 내에서 부여(보안)
        setError('이미 관리자 계정이 존재합니다. 콘솔에서 권한을 부여하세요.'); return
      }
      const { error: upErr } = await supabase
        .from('profiles')
        .upsert({ id: user.id, role: 'admin', updated_at: new Date().toISOString() })
      if (upErr) throw upErr
      setNotice('관리자 권한이 부여되었습니다. /admin 으로 이동해 주세요.')
      setAdminCount(1)
    } catch (err) {
      setError(err?.message || '권한 부여 실패')
    }
  }

  if (loading) return <div className="ox-container py-10 text-sm text-gray-400">확인 중…</div>

  return (
    <div className="ox-container py-8 space-y-6">
      <h1 className="text-lg font-semibold">관리자 초기 셋업</h1>

      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-3">
        <div className="text-sm text-gray-300">현재 관리자 수: <span className="font-semibold text-white">{adminCount}</span></div>
        {adminCount === 0 ? (
          <div className="text-xs text-gray-400">최초 1명은 앱 내에서 관리자 권한을 부여할 수 있습니다. 이후 추가 관리자 권한은 Supabase 콘솔에서 부여하세요.</div>
        ) : (
          <div className="text-xs text-gray-400">이미 관리자 계정이 존재합니다. 추가 관리자는 Supabase 콘솔(SQL)에서 권한을 부여해 주세요.</div>
        )}
      </div>

      {!user && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 로그인 */}
          <form onSubmit={login} className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-3">
            <div className="text-sm font-medium">로그인</div>
            <input type="text" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="email@example.com (개발: admin)" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="비밀번호 (개발: 1234)" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            <button className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">로그인</button>
          </form>

          {/* 회원가입 */}
          <form onSubmit={signup} className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-3">
            <div className="text-sm font-medium">회원가입(관리자용)</div>
            <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="email@example.com" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="비밀번호(6자 이상)" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            <button className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">가입</button>
          </form>
        </div>
      )}

      {user && (
        <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-3">
          <div className="text-sm text-gray-300">현재 로그인: <span className="text-white">{user.email}</span></div>
          <button disabled={adminCount>0} onClick={makeMeAdmin} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5 disabled:opacity-50">
            관리자 권한 부여(최초 1회)
          </button>
        </div>
      )}

      {notice && <div className="text-sm text-emerald-400">{notice}</div>}
      {error && <div className="text-sm text-rose-400">{error}</div>}
    </div>
  )
}
