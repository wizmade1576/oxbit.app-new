import { useState } from 'react'
import { useAuthStore } from '../store/useAuthStore'
import { supabase } from '../services/supabase'

export default function Admin() {
  const { user, isAdmin } = useAuthStore()
  const [title, setTitle] = useState('')
  const [saving, setSaving] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    if (!isAdmin) return alert('관리자 권한 필요')
    if (!title.trim()) return
    setSaving(true)
    try {
      await supabase.from('breaking_news').insert({ title })
      setTitle('')
      alert('등록 완료')
    } finally {
      setSaving(false)
    }
  }

  return (
    <section className="space-y-4">
      <h2 className="text-lg font-semibold">관리자</h2>
      <div className="text-sm text-gray-400">로그인: {user ? user.email : '미로그인'}</div>
      <form onSubmit={submit} className="flex gap-2">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="속보 제목"
          className="flex-1 bg-white/5 border border-white/10 rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-[#1D6FEA]"
        />
        <button disabled={saving} className="px-4 py-2 bg-[#1D6FEA] text-white rounded text-sm">
          {saving ? '등록중…' : '등록'}
        </button>
      </form>
    </section>
  )
}

