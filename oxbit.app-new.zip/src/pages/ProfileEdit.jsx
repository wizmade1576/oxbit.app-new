import React from 'react'
import { supabase } from '../services/supabase'
import { upsertProfile } from '../services/profileService'

export default function ProfileEdit() {
  const [loading, setLoading] = React.useState(true)
  const [saving, setSaving] = React.useState(false)
  const [error, setError] = React.useState('')
  const [notice, setNotice] = React.useState('')
  const [email, setEmail] = React.useState('')
  const [nickname, setNickname] = React.useState('')
  const [phone, setPhone] = React.useState('')
  const [gender, setGender] = React.useState('')
  const [interest, setInterest] = React.useState('')
  const [avatarUrl, setAvatarUrl] = React.useState('')
  const [uploading, setUploading] = React.useState(false)
  const fileRef = React.useRef(null)

  React.useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser()
      const u = data?.user
      if (!u) { setLoading(false); return }
      setEmail(u.email || '')
      const md = u.user_metadata || {}
      setNickname(md.nickname || '')
      setPhone(md.phone || '')
      setGender(md.gender || '')
      setInterest(md.interest || '')
      setAvatarUrl(md.avatar_url || '')
      setLoading(false)
    })()
  }, [])

  const onCheck = (setter, val) => setter((v) => (v === val ? '' : val))

  const save = async (e) => {
    e.preventDefault()
    setError(''); setNotice(''); setSaving(true)
    try {
      const { data } = await supabase.auth.getUser()
      const u = data?.user
      if (!u) throw new Error('로그인이 필요합니다')
      // Update metadata
      await supabase.auth.updateUser({ data: { nickname, phone, gender, interest, avatar_url: avatarUrl || null } })
      // Upsert profile row
      await upsertProfile({ id: u.id, nickname, phone, gender, interest, avatar_url: avatarUrl || null })
      setNotice('프로필이 저장되었습니다')
    } catch (err) {
      setError(err?.message || '저장에 실패했습니다')
    } finally { setSaving(false) }
  }

  const pickFile = () => fileRef.current?.click()

  const uploadAvatar = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) { setError('이미지 파일만 업로드할 수 있습니다'); return }
    if (file.size > 3 * 1024 * 1024) { setError('이미지 크기는 3MB 이하여야 합니다'); return }
    setError(''); setNotice(''); setUploading(true)
    try {
      const { data } = await supabase.auth.getUser()
      const u = data?.user
      if (!u) throw new Error('로그인이 필요합니다')
      const ext = file.name.split('.').pop() || 'jpg'
      const path = `${u.id}/${Date.now()}.${ext}`
      const { error: upErr } = await supabase.storage.from('avatars').upload(path, file, { upsert: true, contentType: file.type, cacheControl: '3600' })
      if (upErr) throw upErr
      const { data: pub } = supabase.storage.from('avatars').getPublicUrl(path)
      setAvatarUrl(pub?.publicUrl || '')
      setNotice('아바타가 업로드되었습니다')
    } catch (err) {
      setError(err?.message || '업로드에 실패했습니다')
    } finally { setUploading(false); if (fileRef.current) fileRef.current.value = '' }
  }

  if (loading) return <div className="text-sm text-gray-400">로딩 중…</div>

  return (
    <section className="mx-auto max-w-xl w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <h2 className="text-lg font-semibold">프로필 수정</h2>
        <form onSubmit={save} className="space-y-4">
          {/* Avatar */}
          <div className="flex items-center gap-4">
            {avatarUrl ? (
              <img src={avatarUrl} alt="avatar" className="h-20 w-20 rounded-full object-cover border border-white/10" />
            ) : (
              <div className="h-20 w-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400">No Image</div>
            )}
            <div className="space-y-2">
              <button type="button" onClick={pickFile} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5" disabled={uploading}>{uploading ? '업로드 중…' : '아바타 변경'}</button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={uploadAvatar} />
              <div className="text-[11px] text-gray-500">최대 3MB, JPG/PNG 권장</div>
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-300">이메일</label>
            <input disabled value={email} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm opacity-70" />
          </div>
          <div>
            <label className="text-xs text-gray-300">닉네임</label>
            <input value={nickname} onChange={(e)=>setNickname(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="text-xs text-gray-300">전화번호</label>
            <input value={phone} onChange={(e)=>setPhone(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-gray-300">성별</label>
            <div className="flex items-center gap-4 text-sm text-gray-300">
              <label className="inline-flex items-center gap-2"><input type="checkbox" className="accent-[#1D6FEA]" checked={gender==='male'} onChange={()=>onCheck(setGender,'male')} /> 남성</label>
              <label className="inline-flex items-center gap-2"><input type="checkbox" className="accent-[#1D6FEA]" checked={gender==='female'} onChange={()=>onCheck(setGender,'female')} /> 여성</label>
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs text-gray-300">관심분야</label>
            <div className="flex items-center gap-4 text-sm text-gray-300">
              <label className="inline-flex items-center gap-2"><input type="checkbox" className="accent-[#1D6FEA]" checked={interest==='coin'} onChange={()=>onCheck(setInterest,'coin')} /> 코인</label>
              <label className="inline-flex items-center gap-2"><input type="checkbox" className="accent-[#1D6FEA]" checked={interest==='stock'} onChange={()=>onCheck(setInterest,'stock')} /> 주식</label>
              <label className="inline-flex items-center gap-2"><input type="checkbox" className="accent-[#1D6FEA]" checked={interest==='both'} onChange={()=>onCheck(setInterest,'both')} /> 코인+주식</label>
            </div>
          </div>
          {notice && <div className="text-sm text-emerald-400">{notice}</div>}
          {error && <div className="text-sm text-rose-400">{error}</div>}
          <button disabled={saving} className="px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">{saving ? '저장 중…' : '저장하기'}</button>
        </form>
      </div>
    </section>
  )
}
