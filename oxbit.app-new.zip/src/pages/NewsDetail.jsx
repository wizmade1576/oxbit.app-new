import { useMemo, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { fetchNewsDetail, searchNews } from '../services/newsService'

export default function NewsDetail() {
  const navigate = useNavigate()
  const params = new URLSearchParams(useLocation().search)
  const id = params.get('id')
  const titleQ = params.get('title')

  const { data: news, isLoading: loading } = useQuery({
    queryKey: ['newsDetail', { id, title: titleQ }],
    queryFn: () => fetchNewsDetail({ id, title: titleQ }),
    enabled: Boolean(id || titleQ),
    staleTime: 5 * 60 * 1000,
  })

  const { data: allNews } = useQuery({
    queryKey: ['newsAll', 50],
    queryFn: () => searchNews(50),
    staleTime: 60 * 1000,
    enabled: !!news,
  })

  const related = useMemo(() => {
    if (!news || !allNews) return []
    const firstWord = (news.title || '').toLowerCase().split(' ')[0] || ''
    const rel = allNews
      .filter((n) => n.id !== news.id)
      .filter((n) => n.title?.toLowerCase().includes(firstWord))
      .slice(0, 6)
    return rel.length ? rel : allNews.filter((n) => n.id !== news.id).slice(0, 6)
  }, [news, allNews])

  const [showEmbed, setShowEmbed] = useState(true)

  const EMBED_WHITELIST = useMemo(
    () => [
      'coindesk.com', 'www.coindesk.com',
      'cointelegraph.com', 'www.cointelegraph.com',
      'decrypt.co', 'www.decrypt.co',
      'bloomberg.com', 'www.bloomberg.com',
      'reuters.com', 'www.reuters.com',
      'news.yahoo.com', 'www.news.yahoo.com',
      'coinstats.app'
    ],
    []
  )

  const canEmbed = useMemo(() => {
    try {
      if (!news?.url) return false
      const host = new URL(news.url).hostname.toLowerCase()
      return EMBED_WHITELIST.some((d) => host === d || host.endsWith('.' + d))
    } catch { return false }
  }, [news?.url, EMBED_WHITELIST])

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">뉴스 상세</h1>
        <button onClick={() => navigate(-1)} className="px-3 py-1.5 text-sm rounded bg-white/10 hover:bg-white/20">뒤로</button>
      </div>

      {loading && <div className="text-sm text-gray-400">불러오는 중…</div>}
      {!loading && !news && <div className="text-sm text-gray-400">해당 뉴스를 찾을 수 없습니다.</div>}

      {news && (
        <article className="border border-white/10 rounded-md p-4 bg-black/20 space-y-3">
          <h2 className="text-lg font-semibold">{news.title}</h2>
          <div className="text-xs text-gray-400">{news.source} · {new Date(news.published_at).toLocaleString()}</div>
          {news.image && (
            <img src={news.image} alt="news" className="rounded-md w-full max-h-72 object-cover" />
          )}
          {news.description && (
            <p className="text-sm text-gray-200 whitespace-pre-line">{news.description}</p>
          )}
          {/* Tags */}
          <div className="flex flex-wrap gap-2 pt-1">
            {Array.from(new Set((news.title + ' ' + (news.description || ''))
              .match(/#?[A-Za-z]{2,10}|#[가-힣A-Za-z0-9]+/g) || []))
              .slice(0, 8)
              .map((t) => (
                <button key={t} onClick={() => navigate(`/news?q=${encodeURIComponent(t.replace('#',''))}`)} className="text-xs rounded-full bg-white/10 px-2 py-1 hover:bg-white/20">
                  {t.startsWith('#') ? t : `#${t}`}
                </button>
              ))}
          </div>
          <div className="flex items-center gap-3">
            <a href={news.url} target="_blank" rel="noreferrer" className="text-sm text-blue-400 hover:underline">원문 보기</a>
            {canEmbed && (
              <button type="button" className="text-sm rounded bg-white/10 px-2 py-1 hover:bg-white/20" onClick={() => setShowEmbed((v) => !v)}>
                {showEmbed ? '임베드 숨기기' : '임베드 보기'}
              </button>
            )}
          </div>
          {/* Share */}
          <div className="flex gap-2 pt-2">
            <button className="px-3 py-1.5 text-sm rounded bg-white/10 hover:bg-white/20" onClick={() => navigator.clipboard?.writeText(window.location.href)}>
              링크 복사
            </button>
            <a className="px-3 py-1.5 text-sm rounded bg-blue-500/80 hover:bg-blue-500 text-white" href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(news.title)}&url=${encodeURIComponent(window.location.href)}`} target="_blank" rel="noreferrer">
              X 공유
            </a>
          </div>
        </article>
      )}

      {/* Related */}
      {!!related.length && (
        <section className="space-y-2">
          <h3 className="text-base font-semibold">관련 기사</h3>
          <ul className="grid md:grid-cols-2 gap-3">
            {related.map((n) => (
              <li key={n.id} className="border border-white/10 rounded-md p-3 bg-black/20 hover:bg-white/10">
                <button className="text-left w-full" onClick={() => navigate(`/news/detail?id=${encodeURIComponent(n.id)}`)}>
                  <div className="text-sm font-medium text-gray-100 line-clamp-2">{n.title}</div>
                  <div className="text-xs text-gray-400 mt-1">{n.source} · {new Date(n.published_at).toLocaleString()}</div>
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Embed */}
      {news && canEmbed && showEmbed && (
        <section className="mt-2">
          <div className="border border-white/10 rounded-md overflow-hidden bg-black/20">
            <iframe
              title="news-embed"
              src={news.url}
              className="w-full h-[70vh]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            />
          </div>
          <p className="mt-2 text-xs text-gray-400">일부 사이트는 보안정책으로 임베드가 제한될 수 있습니다.</p>
        </section>
      )}
    </section>
  )
}

