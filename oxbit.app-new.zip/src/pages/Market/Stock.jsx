﻿import React from 'react'
import MarketTabsNav from '../../components/nav/MarketTabsNav.jsx'
import TVAdvancedChart from '../../components/TVAdvancedChart.jsx'
import { useQuery } from '@tanstack/react-query'
import { fetchStockTopMetrics } from '../../services/stockMetricsService.js'

const presets = [
  { key: 'nas', label: '나스닥100', sub: 'Nasdaq100 (CFD)', symbol: 'OANDA:NAS100USD' },
  { key: 'spx', label: 'S&P500', sub: 'INDEXSP (INX)', symbol: 'FOREXCOM:SPX500' },
  { key: 'dxy', label: '달러 인덱스', sub: 'DXY', symbol: 'TVC:DXY' },
  { key: 'btc', label: '바이낸스 BTC', sub: 'Binance BTC', symbol: 'BINANCE:BTCUSDT' },
  { key: 'dom', label: '도미넌스', sub: 'BTC.D', symbol: 'CRYPTOCAP:BTC.D' },
]

const IconUp = (props) => (<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}><path d="M12 6l6 8H6z"/></svg>)
const IconDown = (props) => (<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}><path d="M12 18L6 10h12z"/></svg>)
const IconNasdaq = (props) => (<svg viewBox="0 0 32 32" {...props}><path fill="#00A6E7" d="M5 20.5 12.5 4h5L10 20.5zM20 12l-5 10h5l5-10z"/></svg>)
const IconSPX = (props) => (<svg viewBox="0 0 32 32" {...props}><circle cx="16" cy="16" r="15" fill="#E31E24"/><rect x="2" y="14" width="28" height="4" fill="#fff"/></svg>)
const IconDXY = (props) => (<svg viewBox="0 0 32 32" {...props}><rect x="4" y="4" width="24" height="24" rx="6" fill="#0ea5e9"/><text x="16" y="20" fontSize="10" textAnchor="middle" fill="#fff" fontFamily="sans-serif">DXY</text></svg>)
const IconBTC = (props) => (<svg viewBox="0 0 32 32" {...props}><circle cx="16" cy="16" r="15" fill="#F3BA2F"/><path fill="#111" d="M19.6 14.3c.7-.5 1.1-1.1 1.1-2.1 0-1.9-1.6-3.2-3.9-3.2h-1.1V7h-2v2H11v2h2v6H11v2h2v2h2v-2h.9c2.6 0 4.3-1.3 4.3-3.4 0-1.3-.7-2.1-1.6-2.6ZM15 11h1.5c1.1 0 1.7.5 1.7 1.3s-.6 1.3-1.7 1.3H15V11Zm1.7 6.9H15V15h1.8c1.3 0 2 .6 2 1.5s-.7 1.4-2.1 1.4Z"/></svg>)
const IconDom = (props) => (<svg viewBox="0 0 32 32" {...props}><circle cx="16" cy="16" r="15" fill="#f59e0b"/><text x="16" y="20" fontSize="10" textAnchor="middle" fill="#111" fontFamily="sans-serif">BTC.D</text></svg>)

const ICON_FOR = { spx: IconSPX, nas: IconNasdaq, dxy: IconDXY, btc: IconBTC, dom: IconDom }

export default function Stock() {
  const [active, setActive] = React.useState('nas')
  const [interval, setInterval] = React.useState('15')
  const sym = presets.find(p => p.key === active)?.symbol || 'FOREXCOM:SPX500'
  const { data: metrics = {} } = useQuery({
    queryKey: ['stock:metrics'],
    queryFn: fetchStockTopMetrics,
    refetchInterval: 30_000,
    staleTime: 20_000,
  })

  return (
    <section className="space-y-3">
      <header>
        <h1 className="hidden md:block text-xl font-semibold text-white">마켓 · 스톡</h1>
      </header>
      <MarketTabsNav />

      <div className="relative z-30 rounded-xl border border-white/10 bg-[#0F1114] divide-y md:divide-y-0 md:divide-x divide-white/10 grid grid-cols-1 md:grid-cols-5 overflow-visible">
        {(() => {
          const items = [
            {key:'nas', name:'NASDAQ 100', sub:'USD', m:metrics.nasdaq},
            {key:'spx', name:'S&P 500', sub:'USD', m:metrics.spx},
            {key:'dxy', name:'DXY', sub:'USD', m:metrics.dxy},
            {key:'btc', name:'BTC Binance', sub:'USD', m:metrics.btc},
            {key:'dom', name:'BTC Dominance', sub:'%/share', m:metrics.dominance},
          ]
          const fmtPrice = (k, v) => {
            if (v == null || !isFinite(v)) return '—'
            const val = (k==='dom'||k==='dxy') ? Number(v).toFixed(2) : Number(v).toLocaleString()
            if (k==='dom') return `${val}%`
            return `$ ${val}`
          }
          const fmtAbs = (k, v) => {
            if (v == null || !isFinite(v)) return '—'
            if (k === 'dom') return `${Number(v).toFixed(2)}`
            if (k === 'dxy') return `${Number(v).toFixed(2)}`
            return Math.abs(Number(v)).toLocaleString()
          }
          return items.map((it) => {
            const price = isFinite(it.m?.price) ? it.m.price : null
            const pct = isFinite(it.m?.changePct) ? it.m.changePct : null
            const abs = isFinite(it.m?.changeAbs) ? it.m.changeAbs : null
            const prev = isFinite(it.m?.prevClose) ? it.m.prevClose : null
            const high = isFinite(it.m?.high) ? it.m.high : null
            const low = isFinite(it.m?.low) ? it.m.low : null
            const up = pct != null && pct > 0
            const Icon = ICON_FOR[it.key]
            const animKey = `${it.key}-${price ?? ''}-${pct ?? ''}-${abs ?? ''}`
            return (
              <button key={animKey} onClick={()=>setActive(it.key)} className={`p-3 w-full text-left ${active===it.key?'bg-white/5':''} relative group`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <Icon className="h-5 w-5" />
                    <div className="leading-tight min-w-0">
                      <div className="text-xs text-gray-300">{it.name}</div>
                      <div className="text-[10px] text-gray-500">{it.sub}</div>
                    </div>
                  </div>
                  <div className="text-sm font-semibold text-gray-100 animate-metric-fade flash-once">{fmtPrice(it.key, price)}</div>
                </div>
                <div className="mt-2 flex items-end gap-2">
                  <div className={`flex items-center gap-1 text-[15px] font-bold animate-metric-fade ${pct==null?'text-gray-400':(up?'text-emerald-400':'text-rose-400')}`}>
                    {pct==null ? null : (up ? <IconUp className="w-3.5 h-3.5"/> : <IconDown className="w-3.5 h-3.5"/>) }
                    <span>{pct!=null? `${up?'+':''}${pct.toFixed(2)}%`:'—'}</span>
                  </div>
                  <div className={`text-[11px] animate-metric-fade ${pct==null?'text-gray-500':(up?'text-emerald-300':'text-rose-300')}`}>{fmtAbs(it.key, abs)}</div>
                </div>
                <div className="hidden md:block pointer-events-none absolute left-3 right-3 -bottom-2 translate-y-full opacity-0 md:group-hover:opacity-100 transition rounded-md border border-white/10 bg-black/80 text-[11px] text-gray-200 px-3 py-2 z-50">
                  <div className="flex justify-between"><span>전일가</span><span>{fmtPrice(it.key, prev)}</span></div>
                  <div className="flex justify-between"><span>최고</span><span>{fmtPrice(it.key, high)}</span></div>
                  <div className="flex justify-between"><span>최저</span><span>{fmtPrice(it.key, low)}</span></div>
                </div>
              </button>
            )
          })
        })()}
      </div>

      <div className="flex flex-wrap items-center gap-2 text-xs">
        {['1', '5', '15', '60', '240', 'D'].map(tf => (
          <button
            key={tf}
            onClick={() => setInterval(tf)}
            className={`px-2 py-1 rounded border ${interval===tf ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'bg-white/5 border-white/10 text-gray-200'}`}
          >{tf === '60' ? '1h' : tf === '240' ? '4h' : (tf==='D'?'1d': `${tf}m`)}</button>
        ))}
      </div>

      <div className="relative z-10 rounded-xl border border-white/10 bg-[#0F1114] p-2">
        <TVAdvancedChart symbol={sym} interval={interval} height={520} />
      </div>
    </section>
  )
}
