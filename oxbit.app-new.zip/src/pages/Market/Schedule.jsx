﻿import React, { useEffect, useMemo, useRef, useState } from 'react'
import MarketTabsNav from '../../components/nav/MarketTabsNav.jsx'
import FilterTabs from '../../components/Market/Schedule/FilterTabs.jsx'
import MonthSection from '../../components/Market/Schedule/MonthSection.jsx'

// Fallback mock when API fails (간단 예비데이터)
const MOCK = [
  { date: '2025-11-20', day: '목요일', title: 'BTC 옵션 만기 (대규모)', category: 'major', tags: ['BTC', '옵션만기'], source: 'Deribit' },
  { date: '2025-11-22', day: '토요일', title: '바이낸스 공지 예정', category: 'exchange', tags: ['Binance'], source: 'Binance' },
  { date: '2025-11-25', day: '화요일', title: 'SOL 메인넷 업그레이드(예정)', category: 'project', tags: ['SOL'], source: 'Solana' },
  { date: '2025-12-10', day: '수요일', title: 'Cardano 파라미터 변경(예정)', category: 'project', tags: ['ADA'] },
]

export default function Schedule() {
  const [filter, setFilter] = useState('all')
  const [visible, setVisible] = useState(6)
  const [items, setItems] = useState(MOCK)
  const sentinelRef = useRef(null)

  // Group by month label
  const byMonth = useMemo(() => {
    const fmt = (d) => {
      const obj = new Date(d)
      const y = obj.getFullYear()
      const m = obj.getMonth() + 1
      return `${y}년 ${m}월`
    }
    const src = filter === 'all' ? items : items.filter((it) => it.category === filter)
    const map = new Map()
    src
      .slice()
      .sort((a, b) => (a.date > b.date ? -1 : 1))
      .slice(0, visible)
      .forEach((it) => {
        const k = fmt(it.date)
        if (!map.has(k)) map.set(k, [])
        map.get(k).push(it)
      })
    return Array.from(map.entries()).map(([month, list]) => ({ month, list }))
  }, [items, visible, filter])

  useEffect(() => { setVisible(6) }, [filter])

  // Fetch from API with fallback
  useEffect(() => {
    const params = new URLSearchParams()
    if (filter !== 'all') params.set('category', filter)
    params.set('sort', 'desc')
    params.set('page', '1')
    params.set('pageSize', '200')
    fetch(`/api/schedule?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => { if (Array.isArray(d.items)) setItems(d.items); else setItems(MOCK) })
      .catch(() => setItems(MOCK))
  }, [filter])

  // Infinite scroll sentinel
  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) setVisible((v) => Math.min(v + 6, items.length)) })
    }, { rootMargin: '200px' })
    io.observe(el)
    return () => io.disconnect()
  }, [items.length])

  return (
    <section className="space-y-2">
      <header>
        <h1 className="hidden md:block text-xl font-semibold text-white">일정</h1>
      </header>
      <MarketTabsNav />
      <FilterTabs value={filter} onChange={setFilter} />

      <div className="space-y-6">
        {byMonth.map((g) => (
          <MonthSection key={g.month} monthLabel={g.month} items={g.list} />
        ))}
      </div>

      <div ref={sentinelRef} className="h-10" />

      {items.length === 0 && (
        <div className="text-sm text-gray-400">일정 데이터가 없습니다.</div>
      )}
    </section>
  )
}



