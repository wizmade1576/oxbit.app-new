import React from 'react'
import MarketTabsNav from '../../components/nav/MarketTabsNav.jsx'
import KimpTab from '../../components/KimpTab.jsx'

export default function KimchiPage() {
  return (
    <section className="space-y-6">
      <header>
        <h1 className="hidden md:block text-xl font-semibold text-white">마켓 · 김프</h1>
        
      </header>
      <MarketTabsNav />
      <KimpTab />
    </section>
  )
}

