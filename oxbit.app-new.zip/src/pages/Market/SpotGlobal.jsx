import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { fetchSpotTickers } from '../../services/marketService'
import CoinRow from '../../components/CoinRowFixed.jsx'
import MarketHeaderSection from '../../components/market/MarketHeaderSection.jsx'
import MarketSummaryCards from '../../components/market/MarketSummaryCards.jsx'
import CoinFilterBar from '../../components/market/CoinFilterBar.jsx'

export default function SpotGlobal() {
  const [q, setQ] = useState('')
  const [gexch, setGexch] = useState('binance') // binance | bybit | coinbase | okx | bitget
  const [sortKey, setSortKey] = useState('volume')
  const [sortDir, setSortDir] = useState('desc')
  const [visible, setVisible] = useState(60)
  const sentinelRef = useRef(null)
  const [searchParams, setSearchParams] = useSearchParams()

  const { data = [], isLoading } = useQuery({
    queryKey: ['market:spot-global', { exchange: gexch }],
    queryFn: () => fetchSpotTickers(gexch),
    staleTime: 30000,
    refetchInterval: 60000,
  })

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase()
    if (!s) return data
    return data.filter((it) => (it.base || '').toLowerCase().includes(s) || (it.symbol || '').toLowerCase().includes(s))
  }, [data, q])

  const upDown = useMemo(() => {
    let up = 0, down = 0
    for (const it of filtered) {
      if (!isFinite(it.changePct)) continue
      if (it.changePct > 0) up++; else if (it.changePct < 0) down++
    }
    return { up, down }
  }, [filtered])

  const sorted = useMemo(() => {
    const arr = [...filtered]
    const pick = (it) => (sortKey === 'price' ? it.last : sortKey === 'change' ? it.changePct : it.quoteVolume)
    arr.sort((a, b) => {
      const av = pick(a), bv = pick(b)
      return (isFinite(av) ? av : -Infinity) - (isFinite(bv) ? bv : -Infinity)
    })
    if (sortDir === 'desc') arr.reverse()
    return arr
  }, [filtered, sortKey, sortDir])

  useEffect(() => { setVisible(60) }, [q, sortKey, sortDir])

  // URL sync + restore
  useEffect(() => {
    const urlEx = searchParams.get('exch')
    const allowed = ['binance', 'bybit', 'coinbase', 'okx', 'bitget']
    const stored = localStorage.getItem('market:spotgl:exch')
    if (urlEx && allowed.includes(urlEx)) setGexch(urlEx)
    else if (stored && allowed.includes(stored)) setGexch(stored)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  useEffect(() => {
    const sp = new URLSearchParams(searchParams)
    sp.set('exch', gexch)
    setSearchParams(sp, { replace: true })
    try { localStorage.setItem('market:spotgl:exch', gexch) } catch {}
  }, [gexch])

  useEffect(() => {
    const el = sentinelRef.current; if (!el) return
    const io = new IntersectionObserver(
      (entries) => { entries.forEach((e) => { if (e.isIntersecting) setVisible((v) => Math.min(v + 60, sorted.length)) }) },
      { rootMargin: '200px' }
    )
    io.observe(el); return () => io.disconnect()
  }, [sorted.length])

  const toggleSort = (key) => { setSortKey((prev) => (prev === key ? prev : key)); setSortDir((prev) => (sortKey === key ? (prev === 'asc' ? 'desc' : 'asc') : 'desc')) }
  const arrow = (key) => (sortKey !== key ? '' : sortDir === 'asc' ? '▲' : '▼')

  return (
    <section className="space-y-0">
      <MarketHeaderSection issueCount={5} issueText="150만 ETH 스테이킹 대기" />
      <MarketSummaryCards up={upDown.up} down={upDown.down} />
      <div className="pt-2">
        <CoinFilterBar
          onReset={() => setQ('')}
          search={q}
          onSearch={setQ}
          exchangeValue={gexch}
          onExchangeChange={setGexch}
          exchangeOptions={[
            { value: 'binance', label: '바이낸스', icon: 'https://www.google.com/s2/favicons?domain=binance.com&sz=64' },
            { value: 'bybit', label: '바이빗', icon: 'https://www.google.com/s2/favicons?domain=bybit.com&sz=64' },
            { value: 'coinbase', label: '코인베이스', icon: 'https://www.google.com/s2/favicons?domain=coinbase.com&sz=64' },
            { value: 'okx', label: 'OKX', icon: 'https://www.google.com/s2/favicons?domain=okx.com&sz=64' },
            { value: 'bitget', label: '빗겟', icon: 'https://www.google.com/s2/favicons?domain=bitget.com&sz=64' },
          ]}
        />
      </div>

      <div className="rounded-xl border border-white/10 bg-[#0F1114] overflow-x-auto">
        <table className="w-full min-w-[680px] text-sm">
          <thead className="bg-black/20 text-gray-400">
            <tr className="divide-x divide-white/5">
              <th className="px-3 py-2 text-left w-12">#</th>
              <th className="px-3 py-2 text-left">종목</th>
              <th className="px-3 py-2 text-right cursor-pointer" onClick={() => toggleSort('price')}>가격 {arrow('price')}</th>
              <th className="px-3 py-2 text-right cursor-pointer" onClick={() => toggleSort('change')}>변동률 {arrow('change')}</th>
              <th className="px-3 py-2 text-right cursor-pointer" onClick={() => toggleSort('volume')}>24H 거래금액 {arrow('volume')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {sorted.slice(0, visible).map((it, i) => (
              <CoinRow key={it.symbol || i} item={it} index={i} region={'global'} view="table" />
            ))}
          </tbody>
        </table>
        <div ref={sentinelRef} className="h-10" />
      </div>

      {isLoading && <div className="text-sm text-gray-400">불러오는 중…</div>}
      {!isLoading && sorted.length === 0 && <div className="text-sm text-gray-400">표시할 데이터가 없습니다.</div>}
    </section>
  )
}

