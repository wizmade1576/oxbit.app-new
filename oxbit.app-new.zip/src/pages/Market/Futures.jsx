﻿import React, { useMemo, useState } from 'react'
import Dropdown from '../../components/Dropdown.jsx'
import MarketTabsNav from '../../components/nav/MarketTabsNav.jsx'
import Liquidation from '../../components/Market/Futures/Liquidation.jsx'
import LongShortRatio from '../../components/Market/Futures/LongShortRatio.jsx'
import FundingRate from '../../components/Market/Futures/FundingRate.jsx'
import OpenInterest from '../../components/Market/Futures/OpenInterest.jsx'

const TIME_OPTS = [
  { value: '1h', label: '1시간' },
  { value: '4h', label: '4시간' },
  { value: '12h', label: '12시간' },
  { value: '24h', label: '24시간' },
]

export default function Futures() {
  const [sub, setSub] = useState('liq') // liq | lsr | fr | oi
  const [tf, setTf] = useState('1h')
  const [coin, setCoin] = useState('BTC')

  const coinOpts = useMemo(
    () => ['BTC', 'ETH', 'SOL', 'XRP', 'BNB', 'DOGE', 'SUI', 'ADA', 'ENA', 'MNT'].map((v) => ({ value: v, label: v })),
    []
  )

  return (
    <section className="space-y-0">
      <header>
        <h1 className="hidden md:block text-xl font-semibold text-white">선물</h1>
      </header>
      <MarketTabsNav />
      {/* Sub tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {[
          { key: 'liq', label: '강제청산' },
          { key: 'lsr', label: '롱/숏 비율' },
          { key: 'fr', label: '자금조달비용' },
          { key: 'oi', label: '미결제약정' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setSub(t.key)}
            className={`px-3 py-2 rounded-md text-sm border ${
              sub === t.key ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2">
          <Dropdown value={tf} onChange={setTf} options={TIME_OPTS} labelPrefix="기간" />
          <Dropdown value={coin} onChange={setCoin} options={coinOpts} labelPrefix="코인" />
        </div>
      </div>

      {sub === 'liq' && <Liquidation timeframe={tf} />}
      {sub === 'lsr' && <LongShortRatio coin={coin} />}
      {sub === 'fr' && <FundingRate coin={coin} />}
      {sub === 'oi' && <OpenInterest base="BTC" />}
    </section>
  )
}



