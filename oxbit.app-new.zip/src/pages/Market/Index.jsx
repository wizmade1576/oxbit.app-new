﻿import React from 'react'
import MarketTabsNav from '../../components/nav/MarketTabsNav.jsx'
import { Link } from 'react-router-dom'
import KimpSummary from '../../components/KimpSummary.jsx'

export default function MarketIndex() {
  return (
    <section className="space-y-4">
      <div className="space-y-3">
        <h1 className="text-xl font-bold text-gray-100">마켓</h1>
        <MarketTabsNav />
      </div>

      <div className="space-y-4">
        <div className="rounded-xl border border-white/10 bg-[#0F1114] p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-semibold text-gray-100">김프 섹션</h2>
            <Link to="/market/kimchi" className="text-xs text-[#6BA7FF] hover:underline">전체 보기</Link>
          </div>
          <KimpSummary limit={6} cols={2} />
        </div>
        <div className="rounded-xl border border-white/10 bg-[#0F1114] p-6 text-sm text-gray-300">
          상단 탭에서 세부 마켓 페이지를 선택하세요.
        </div>
      </div>
    </section>
  )
}
