import React from 'react'
import PositionsTabsNav from '../../components/nav/PositionsTabsNav.jsx'
import { supabase } from '../../services/supabase'

export default function PositionsIndex() {
  const [rows, setRows] = React.useState([])
  const [loading, setLoading] = React.useState(false)

  React.useEffect(() => {
    const load = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase
          .from('positions')
          .select('id,nick,symbol,side,lev,qty,entry,mark,pnl_pct,pnl_krw,status,created_at')
          .order('created_at', { ascending: false })
          .limit(50)
        if (error) throw error
        setRows(data || [])
      } catch (e) { console.error(e) }
      finally { setLoading(false) }
    }
    load()
  }, [])

  return (
    <section className="ox-container mx-auto py-6 space-y-6">
      <header>
        <h1 className="text-xl font-semibold text-white">포지션</h1>
        <p className="text-sm text-gray-400">/positions</p>
      </header>
      <PositionsTabsNav />
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-4">
        {loading ? (
          <div className="text-sm text-gray-400">불러오는 중…</div>
        ) : rows.length === 0 ? (
          <div className="text-sm text-gray-400">표시할 데이터가 없습니다.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left text-gray-400">
                  <th className="py-2 px-2">닉네임</th>
                  <th className="px-2">심볼</th>
                  <th className="px-2">포지션</th>
                  <th className="px-2 text-right">레버리지</th>
                  <th className="px-2 text-right">수량</th>
                  <th className="px-2 text-right">진입</th>
                  <th className="px-2 text-right">현재가</th>
                  <th className="px-2 text-right">PnL%</th>
                  <th className="px-2 text-right">PnL(₩)</th>
                  <th className="px-2">상태</th>
                  <th className="px-2">시간</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t border-white/10">
                    <td className="py-2 px-2">{r.nick}</td>
                    <td className="px-2">{r.symbol}</td>
                    <td className="px-2">{r.side}</td>
                    <td className="px-2 text-right">{r.lev || '-'}</td>
                    <td className="px-2 text-right">{isFinite(r.qty) ? r.qty : '-'}</td>
                    <td className="px-2 text-right">{isFinite(r.entry) ? r.entry : '-'}</td>
                    <td className="px-2 text-right">{isFinite(r.mark) ? r.mark : '-'}</td>
                    <td className="px-2 text-right">{isFinite(r.pnl_pct) ? `${r.pnl_pct}%` : '-'}</td>
                    <td className="px-2 text-right">{isFinite(r.pnl_krw) ? Number(r.pnl_krw).toLocaleString() : '-'}</td>
                    <td className="px-2">{r.status || '-'}</td>
                    <td className="px-2">{r.created_at ? new Date(r.created_at).toLocaleString() : '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  )
}

