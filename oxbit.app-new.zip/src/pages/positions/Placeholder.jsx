import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export default function PositionsPlaceholder() {
  const navigate = useNavigate()
  useEffect(() => {
    // focus trap or analytics could go here
  }, [])
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
      <div className="mx-6 max-w-sm rounded-lg border border-zinc-700 bg-[#121418] p-5 text-sm leading-6 text-zinc-200 shadow-lg">
        <h1 className="mb-2 text-base font-semibold">모의투자</h1>
        <p className="mb-4">이 페이지는 준비중입니다. 빠른 시일내에 찾아뵙도록 하겠습니다.</p>
        <div className="flex gap-2">
          <button className="flex-1 rounded bg-white/10 px-3 py-2 hover:bg-white/20" onClick={() => navigate(-1)}>이전으로</button>
          <button className="flex-1 rounded bg-white/10 px-3 py-2 hover:bg-white/20" onClick={() => navigate('/breaking')}>속보 보기</button>
        </div>
      </div>
    </div>
  )
}
