import React from 'react'
import PositionsTabsNav from '../../components/nav/PositionsTabsNav.jsx'

export default function PositionsFearGreed() {
  return (
    <section className="ox-container mx-auto py-6 space-y-6">
      <header>
        <h1 className="text-xl font-semibold text-white">포지션 · 공포/탐욕</h1>
        <p className="text-sm text-gray-400">/positions/feargreed</p>
      </header>
      <PositionsTabsNav />
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-8 text-sm text-gray-300">
        공포/탐욕 지수 화면 템플릿입니다.
      </div>
    </section>
  )
}
