import React from 'react';

function BreakingDetail() {
  return (
    <div>
      <h1>속보 상세 페이지</h1>
      {/* 내용을 여기에 추가하세요 */}
    </div>
  );
}

export default BreakingDetail;