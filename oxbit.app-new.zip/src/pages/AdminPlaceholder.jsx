import React from 'react'

export default function AdminPlaceholder() {
  return (
    <section className="mx-auto max-w-3xl w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-3">
        <h1 className="text-lg font-semibold">관리자 영역 준비중</h1>
        <p className="text-sm text-gray-300">
          관리자 콘솔은 정비를 위해 임시 중단되었습니다. 빠른 시일 내에 새 버전으로 돌아오겠습니다.
        </p>
        <ul className="text-sm text-gray-400 list-disc pl-5">
          <li>게시글/신고/광고/유저 관리 기능 재구성</li>
          <li>권한 및 접근 제어 고도화</li>
        </ul>
      </div>
    </section>
  )
}

