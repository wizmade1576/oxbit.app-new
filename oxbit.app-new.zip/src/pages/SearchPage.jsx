import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

export default function SearchPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const initial = useMemo(() => new URLSearchParams(location.search).get('q') ?? '', [location.search])
  const [query, setQuery] = useState(initial)
  const inputRef = useRef(null)

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') navigate(-1) }
    window.addEventListener('keydown', onKey)
    setTimeout(() => inputRef.current?.focus(), 0)
    return () => window.removeEventListener('keydown', onKey)
  }, [navigate])

  const suggestions = ['XRP', 'UXLINK', 'SOL', 'ETH', '비트코인', '이더리움', 'BTC', 'WLFI', '도지', '폴라즈마']

  const submit = (e) => {
    e.preventDefault()
    const q = query.trim()
    if (q) navigate(`/news?q=${encodeURIComponent(q)}`)
  }

  const selectTag = (tag) => {
    navigate(`/news?q=${encodeURIComponent(tag)}`)
  }

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-white dark:bg-[#0F1114]" role="dialog" aria-modal="true" onClick={() => navigate(-1)}>
      <div className="mx-auto mt-12 w-full max-w-2xl px-4 sm:mt-16 sm:px-6" onClick={(e) => e.stopPropagation()}>
        {/* Close button (top-right) */}
        <div className="relative">
          <button
            aria-label="닫기"
            onClick={() => navigate(-1)}
            className="absolute right-0 -top-8 inline-flex h-9 w-9 items-center justify-center rounded-md text-gray-600 hover:bg-black/10 hover:text-black dark:text-gray-300 dark:hover:bg-white/10 dark:hover:text-white"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
              <path fillRule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
            </svg>
          </button>
        </div>

        {/* Search input centered near top */}
        <div className="mt-6 sm:mt-8">
          <form onSubmit={submit} className="relative">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-300">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                <path fillRule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 4.207 12.042l3.25 3.25a.75.75 0 1 0 1.06-1.06l-3.25-3.25A6.75 6.75 0 0 0 10.5 3.75Zm-5.25 6.75a5.25 5.25 0 1 1 10.5 0 5.25 5.25 0 0 1-10.5 0Z" clipRule="evenodd" />
              </svg>
            </span>
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="검색어를 입력해 주세요."
              className="w-full rounded-xl border pl-10 pr-28 py-3 outline-none focus:ring-2 focus:ring-blue-500 border-black/10 bg-white text-gray-900 placeholder:text-gray-500 dark:border-white/20 dark:bg-white/10 dark:text-gray-100 dark:placeholder:text-gray-400"
            />
            <div className="absolute inset-y-0 right-2 flex items-center gap-2">
              <button type="button" onClick={() => navigate(-1)} className="text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white px-2 py-1">취소</button>
              <button type="submit" className="px-3 py-1.5 rounded-md bg-blue-500 text-white text-sm">검색</button>
            </div>
          </form>
        </div>

        {/* Hashtag suggestions */}
        <div className="mt-4 flex flex-wrap gap-2">
          {suggestions.map((tag) => (
            <button
              key={tag}
              onClick={() => selectTag(tag)}
              className="rounded-full px-3 py-1.5 text-sm bg-black/10 text-gray-700 hover:bg-black/20 dark:bg-white/10 dark:text-gray-200 dark:hover:bg-white/20"
              type="button"
            >
              #{tag}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

