import React, { useEffect, useMemo, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'

export default function CommunityDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const state = location.state || {}

  const basePost = state.post || {
    id,
    nick: '익명',
    time: '방금 전',
    title: `게시글 #${id}`,
    content:
      '모의 게시 페이지입니다. 서비스 연동 전이므로 API/본문/이미지/링크 등 리치 콘텐츠를 고려한 예시 문구입니다.',
    comments: 3,
    likes: 12,
  }

  const [likeCount, setLikeCount] = useState(basePost.likes)
  const [liked, setLiked] = useState(false)
  const [copied, setCopied] = useState(false)
  const [comments, setComments] = useState(() => [
    { id: 'c1', nick: '트레이더K', time: '5분 전', text: '현 시황에선 분할 접근이 맞다 봅니다.' },
    { id: 'c2', nick: '체크러', time: '12분 전', text: '체결강도/고래 활동 지표 조금 줄었네요.' },
    { id: 'c3', nick: '초보개미', time: '1시간 전', text: '좋은 정보 감사합니다!' },
  ])
  const [text, setText] = useState('')

  useEffect(() => {
    if (!copied) return
    const t = setTimeout(() => setCopied(false), 1200)
    return () => clearTimeout(t)
  }, [copied])

  const shareUrl = useMemo(() => (typeof window !== 'undefined' ? window.location.href : ''), [])

  const toggleLike = () => {
    setLiked((v) => !v)
    setLikeCount((n) => (liked ? Math.max(0, n - 1) : n + 1))
  }

  const share = async () => {
    const title = basePost.title
    try {
      if (navigator.share) {
        await navigator.share({ title, url: shareUrl })
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(shareUrl)
        setCopied(true)
      }
    } catch {}
  }

  const addComment = () => {
    const v = text.trim()
    if (!v) return
    setComments((list) => [{ id: 'c' + Date.now(), nick: '익명', time: '지금', text: v }, ...list])
    setText('')
  }

  return (
    <section className="space-y-4">
      <button onClick={() => navigate(-1)} className="px-3 py-1.5 text-sm rounded-md border border-white/10 text-gray-200 hover:bg-white/10">뒤로</button>

      <article className="rounded-xl border border-white/10 bg-[#0F1114] p-4">
        <h1 className="text-lg font-semibold text-white">{basePost.title}</h1>
        <div className="mt-1 text-sm text-gray-400">작성자 {basePost.nick} · {basePost.time}</div>
        <div className="mt-4 text-sm leading-6 text-gray-200 whitespace-pre-wrap">{basePost.content}</div>

        {/* 액션 바 */}
        <div className="mt-4 flex items-center gap-2">
          <button onClick={toggleLike} className={`px-3 py-1.5 rounded-md text-sm border ${liked ? 'bg-rose-600 border-rose-600 text-white' : 'border-white/10 text-gray-200 hover:bg-white/10'}`}>좋아요 {likeCount}</button>
          <button onClick={share} className="px-3 py-1.5 rounded-md text-sm border border-white/10 text-gray-200 hover:bg-white/10">공유하기</button>
          {copied && <span className="text-xs text-emerald-300">링크 복사됨</span>}
        </div>
      </article>

      {/* 댓글 */}
      <section className="rounded-xl border border-white/10 bg-[#0F1114] p-4 space-y-3">
        <h2 className="text-sm text-gray-300">댓글 {comments.length}</h2>

        {/* 입력 */}
        <div className="flex items-start gap-2">
          <textarea value={text} onChange={(e)=>setText(e.target.value)} placeholder="댓글을 입력하세요" className="flex-1 rounded-md bg-white/5 border border-white/10 p-2 text-sm text-gray-100 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#1D6FEA]" rows={3} />
          <button onClick={addComment} className="px-3 py-2 rounded-md bg-[#1D6FEA] text-white text-sm">등록</button>
        </div>

        {/* 목록 */}
        <ul className="space-y-3">
          {comments.map((c) => (
            <li key={c.id} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs text-gray-300">{c.nick.slice(0,1)}</div>
              <div className="min-w-0 flex-1">
                <div className="text-sm text-gray-200">{c.nick} <span className="text-[11px] text-gray-400">· {c.time}</span></div>
                <div className="mt-1 text-sm text-gray-300 whitespace-pre-wrap">{c.text}</div>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </section>
  )
}

