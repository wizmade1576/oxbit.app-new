import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { supabase } from '../services/supabase'

export default function ResetPasswordConfirm() {
  const navigate = useNavigate()
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [ready, setReady] = useState(false)

  useEffect(() => {
    // Ensure the session from recovery link is present
    supabase.auth.getUser().then(({ data }) => {
      setReady(!!data?.user)
    })
  }, [])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    if (password !== confirm) { setError('비밀번호가 일치하지 않습니다'); return }
    if (password.length < 6) { setError('비밀번호는 6자 이상이어야 합니다'); return }
    setSending(true)
    try {
      const { error } = await supabase.auth.updateUser({ password })
      if (error) throw error
      navigate('/login')
    } catch (err) {
      setError(err?.message || '변경에 실패했습니다')
    } finally { setSending(false) }
  }

  return (
    <section className="mx-auto max-w-md w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">새 비밀번호 설정</h2>
          <Link to="/login" className="text-xs text-blue-400 hover:text-blue-300">로그인</Link>
        </div>
        {!ready ? (
          <div className="text-sm text-gray-400">링크를 확인 중입니다…</div>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <div className="space-y-2">
              <label className="text-xs text-gray-300">새 비밀번호</label>
              <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={6} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-gray-300">비밀번호 확인</label>
              <input type="password" value={confirm} onChange={(e)=>setConfirm(e.target.value)} required minLength={6} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            </div>
            {error && <div className="text-sm text-rose-400">{error}</div>}
            <button disabled={sending} className="w-full px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">{sending ? '처리 중…' : '변경하기'}</button>
          </form>
        )}
      </div>
    </section>
  )
}

