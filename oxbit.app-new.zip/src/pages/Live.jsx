﻿import React from 'react'
import LiveChart from '../components/Chart/LiveChart.jsx'
import LiveFeed from '../components/LiveFeed.jsx'
import OnchainCards from '../components/Onchain/OnchainCards.jsx'
import FuturesTrades from '../components/whale/FuturesTrades.jsx'
import FuturesLiquidations from '../components/whale/FuturesLiquidations.jsx'
import SpotBuys from '../components/whale/SpotBuys.jsx'
import SpotSells from '../components/whale/SpotSells.jsx'
import FearGreed from '../components/live/FearGreed.jsx'

export default function Live() {
  const [mode, setMode] = React.useState('live')
  return (
    <div className="space-y-6">
      {/* 라이브 / 고래추적 / 공포탐욕 */}
      <div className="flex items-center gap-2">
        {[
          { key: 'live', label: '라이브' },
          { key: 'whale', label: '고래추적' },
          { key: 'fear', label: '공포/탐욕' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setMode(t.key)}
            className={`px-3 py-2 rounded-md text-sm border ${
              mode === t.key ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'
            }`}
            aria-pressed={mode === t.key}
          >
            {t.label}
          </button>
        ))}
      </div>

      {mode === 'live' ? <LiveChart compact /> : null}

      {mode === 'fear' && (
        <div className="max-w-2xl">
          <FearGreed />
        </div>
      )}

      {mode === 'live' && (
        <div>
          <LiveFeed />
        </div>
      )}

      {mode === 'live' && (<OnchainCards />)}

      {mode === 'whale' && (
        <section className="space-y-3">
          <WhaleTabs />
        </section>
      )}
    </div>
  )
}

function WhaleTabs() {
  const [tab, setTab] = React.useState('futures')
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        {[
          { key: 'futures', label: '선물 고래' },
          { key: 'spot', label: '현물 고래' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-3 py-2 rounded-md text-sm border ${
              tab === t.key ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'
            }`}
            aria-pressed={tab === t.key}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'futures' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <FuturesTrades />
          <FuturesLiquidations />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SpotBuys />
          <SpotSells />
        </div>
      )}
    </div>
  )
}


