import React from 'react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <section className="ox-container mx-auto py-16 text-center">
      <h1 className="text-2xl font-bold mb-2">페이지를 찾을 수 없습니다</h1>
      <p className="text-gray-400 mb-6">요청하신 경로가 존재하지 않습니다.</p>
      <Link to="/" className="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-500">홈으로</Link>
    </section>
  )
}

