﻿import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../store/useAuthStore'
import Recaptcha from '../components/Recaptcha.jsx'
import Modal from '../components/Modal.jsx'

export default function Signup() {
  const navigate = useNavigate()
  const { signUpWithEmail, sendSmsOtp, verifySmsOtp } = useAuthStore()

  // SMS 인증 필요 여부 (true = 필수)
  const REQUIRE_SMS = false

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  const [smsCode, setSmsCode] = useState('')
  const [smsSent, setSmsSent] = useState(false)
  const [smsVerified, setSmsVerified] = useState(!REQUIRE_SMS)
  const [gender, setGender] = useState('')
  const [interest, setInterest] = useState('')
  const [nickname, setNickname] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [cooldown, setCooldown] = useState(0)
  const [agreeTerms, setAgreeTerms] = useState(false)
const [agreePrivacy, setAgreePrivacy] = useState(false)
const [agreeThird, setAgreeThird] = useState(false)
const [captchaToken, setCaptchaToken] = useState('')
const [openTerms, setOpenTerms] = useState(false)
const [openPrivacy, setOpenPrivacy] = useState(false)
const [openThird, setOpenThird] = useState(false)
function openModal(which) {
  setOpenTerms(which === 'terms')
  setOpenPrivacy(which === 'privacy')
  setOpenThird(which === 'third')
}

const normalizedPhone = (p) => p.replace(/\\D/g, '')

  const sendCode = async () => {
    setError(''); setNotice('')
    const ph = normalizedPhone(phone)
    if (!ph) return setError('전화번호를 입력해 주세요')
    try {
      await sendSmsOtp(`+${ph.startsWith('82') ? ph : '82' + ph.replace(/^0/, '')}`)
      setSmsSent(true)
      setNotice('인증번호를 전송했습니다')
    } catch (err) {
      setError(err?.message || '인증번호 전송에 실패했습니다')
    }
  }

  const verifyCode = async () => {
    setError(''); setNotice('')
    const ph = normalizedPhone(phone)
    if (!ph || !smsCode) return setError('전화번호와 인증번호를 입력해 주세요')
    try {
      const ok = await verifySmsOtp(`+${ph.startsWith('82') ? ph : '82' + ph.replace(/^0/, '')}`, smsCode)
      setSmsVerified(!!ok)
      setNotice('전화번호 인증이 완료되었습니다')
    } catch (err) {
      setError(err?.message || '인증번호가 올바르지 않습니다')
    }
  }

  const onCheckGender = (val) => setGender((g) => (g === val ? '' : val))
  const onCheckInterest = (val) => setInterest((i) => (i === val ? '' : val))

  // 쿨다운 타이머
  if (cooldown > 0) {
    setTimeout(() => setCooldown((s) => (s > 0 ? s - 1 : 0)), 1000)
  }

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setNotice('')

    if (!fullName.trim()) return setError('이름을 입력해 주세요')
    if (password !== confirm) return setError('비밀번호가 일치하지 않습니다')
    if (password.length < 6) return setError('비밀번호는 6자 이상이어야 합니다')
    if (REQUIRE_SMS && !smsVerified) return setError('전화번호 인증을 완료해 주세요')
    if (!agreeTerms || !agreePrivacy || !agreeThird) return setError('약관/개인정보/제3자 제공 동의가 필요합니다')
    if (!captchaToken) return setError('reCAPTCHA 인증이 필요합니다')
    if (cooldown > 0) return setError(`${cooldown}초 후 다시 시도해 주세요`)

    const isDev = !!(import.meta?.env?.DEV)

    // reCAPTCHA 서버 검증
    if (!isDev) {
      try {
        const r = await fetch('/api/verify-recaptcha', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ token: captchaToken }),
        })
        const j = await r.json()
        if (!j?.success) return setError('reCAPTCHA 인증 실패')
      } catch (_) {}
    }

    setSending(true)
    try {
      await signUpWithEmail(email, password, {
        full_name: fullName,
        nickname,
        phone: normalizedPhone(phone),
        gender,
        interest,
      })
      setNotice('인증 이메일이 발송되었습니다. 확인해주세요!')
      setTimeout(() => navigate('/login'), 1200)
    } catch (err) {
      if (/rate limit/i.test(String(err?.message))) {
        setCooldown(60)
        setError('이메일 제한입니다. 60초 후 다시 시도해주세요')
      } else {
        setError(err?.message || '회원가입 실패')
      }
    } finally {
      setSending(false)
    }
  }

  return (
    <section className="mx-auto max-w-md w-full">
      <div className="rounded-xl border p-6 space-y-4 border-black/10 bg-white text-gray-900 dark:border-white/10 dark:bg-[#13161A] dark:text-gray-100">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">회원가입</h2>
          <Link to="/login" className="text-xs text-blue-400 hover:text-blue-300">로그인</Link>
        </div>

        <form onSubmit={submit} className="space-y-4">

          {/* 이메일 */}
          <div className="space-y-2">
            <label className="text-xs text-gray-700 dark:text-gray-300">이메일</label>
            <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required placeholder="name@example.com" className="w-full rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 placeholder:text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-100 dark:placeholder:text-gray-400" />
          </div>

          {/* 비밀번호 */}
          <div className="space-y-2">
            <label className="text-xs text-gray-700 dark:text-gray-300">비밀번호</label>
            <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={6} className="w-full rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 dark:border-white/10 dark:bg-white/5 dark:text-gray-100" />
          </div>
          <div className="space-y-2">
            <label className="text-xs text-gray-700 dark:text-gray-300">비밀번호 확인</label>
            <input type="password" value={confirm} onChange={(e)=>setConfirm(e.target.value)} required minLength={6} className="w-full rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 dark:border-white/10 dark:bg-white/5 dark:text-gray-100" />
          </div>

          {/* 이름 */}
          <div className="space-y-2">
            <label className="text-xs text-gray-700 dark:text-gray-300">이름</label>
            <input type="text" value={fullName} onChange={(e)=>setFullName(e.target.value)} required placeholder="홍길동" className="w-full rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 placeholder:text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-100 dark:placeholder:text-gray-400" />
          </div>

          {/* 전화번호 + SMS */}
          <div className="space-y-2">
            <label className="text-xs text-gray-700 dark:text-gray-300">전화번호</label>
            <div className="flex gap-2">
              <input type="tel" value={phone} onChange={(e)=>setPhone(e.target.value)} placeholder="예) 01012345678" className="flex-1 rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 placeholder:text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-100 dark:placeholder:text-gray-400" />
              <button type="button" onClick={sendCode} className="px-3 py-2 text-xs rounded border transition-colors border-black/10 text-gray-700 hover:bg-black/10 dark:border-white/10 dark:text-gray-300 dark:hover:bg-white/5">인증번호</button>
            </div>
            <div className="flex gap-2">
              <input type="text" value={smsCode} onChange={(e)=>setSmsCode(e.target.value)} placeholder="6자리 입력" className="flex-1 rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 placeholder:text-gray-500 dark:border-white/10 dark:bg-white/5 dark:text-gray-100 dark:placeholder:text-gray-400" />
              <button type="button" onClick={verifyCode} className={`px-3 py-2 text-xs rounded border transition-colors ${smsVerified ? 'border-emerald-400 text-emerald-600 dark:text-emerald-300' : 'border-black/10 text-gray-700 hover:bg-black/10 dark:border-white/10 dark:text-gray-300 dark:hover:bg-white/5'}`}>
                {smsVerified ? '완료' : '확인'}
              </button>
            </div>
          </div>

          {/* 성별 */}
          <div className="space-y-1">
            <label className="text-xs text-gray-700 dark:text-gray-300">성별</label>
            <div className="flex items-center gap-4">
              <label className="inline-flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                <input type="checkbox" checked={gender==='male'} onChange={()=>onCheckGender('male')} className="accent-[#1D6FEA]" /> 남성
              </label>
              <label className="inline-flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                <input type="checkbox" checked={gender==='female'} onChange={()=>onCheckGender('female')} className="accent-[#1D6FEA]" /> 여성
              </label>
            </div>
          </div>

          {/* 관심 분야 */}
          <div className="space-y-1">
            <label className="text-xs text-gray-700 dark:text-gray-300">관심분야</label>
            <div className="flex items-center gap-4">
              <label className="inline-flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                <input type="checkbox" checked={interest==='coin'} onChange={()=>onCheckInterest('coin')} className="accent-[#1D6FEA]" /> 코인
              </label>
              <label className="inline-flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                <input type="checkbox" checked={interest==='stock'} onChange={()=>onCheckInterest('stock')} className="accent-[#1D6FEA]" /> 주식
              </label>
              <label className="inline-flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300">
                <input type="checkbox" checked={interest==='both'} onChange={()=>onCheckInterest('both')} className="accent-[#1D6FEA]" /> 코인+주식
              </label>
            </div>
          </div>

          {/* 닉네임 */}
          <div className="space-y-2">
            <label className="text-xs text-gray-700 dark:text-gray-300">닉네임 (선택)</label>
            <input type="text" value={nickname} onChange={(e)=>setNickname(e.target.value)} placeholder="닉네임" className="w-full rounded px-3 py-2 text-sm border border-black/10 bg-white text-gray-900 dark:border-white/10 dark:bg-white/5 dark:text-gray-100" />
          </div>

                              {/* 약관 */}
          <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={agreeTerms} onChange={(e)=>setAgreeTerms(e.target.checked)} className="accent-[#1D6FEA]" />
              <span>이용약관 동의</span>
              <button type="button" onClick={() => openModal('terms')} className="ml-3 text-xs text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300">보기</button>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={agreePrivacy} onChange={(e)=>setAgreePrivacy(e.target.checked)} className="accent-[#1D6FEA]" />
              <span>개인정보처리 동의</span>
              <button type="button" onClick={() => openModal('privacy')} className="ml-3 text-xs text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300">보기</button>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={agreeThird} onChange={(e)=>setAgreeThird(e.target.checked)} className="accent-[#1D6FEA]" />
              <span>제3자 정보 제공 동의 (필수)</span>
              <button type="button" onClick={() => openModal('third')} className="ml-3 text-xs text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300">보기</button>
            </label>
          </div>

          {/* reCAPTCHA */}
          <div className="pt-1">
            <Recaptcha onVerify={(t)=>setCaptchaToken(String(t||''))} />
          </div>

                    {/* 모달 */}
          <Modal open={openTerms} onClose={()=>setOpenTerms(false)} title="이용약관">
            <div className="text-sm leading-relaxed space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              <p>본 약관은 회원이 서비스를 이용함에 있어 회사와 회원 간의 권리·의무 및 책임사항을 규정합니다.</p>
              <div>
                <h3 className="font-semibold">1. 서비스 개요</h3>
                <p>회사는 시장 데이터, 뉴스, 커뮤니티 등 정보를 제공하며, 정보 제공 자체가 투자 자문을 의미하지 않습니다.</p>
              </div>
              <div>
                <h3 className="font-semibold">2. 계정 및 보안</h3>
                <p>회원은 계정 및 비밀번호를 안전하게 관리할 책임이 있습니다. 계정의 부정 사용이 의심될 경우 즉시 통지해야 합니다.</p>
              </div>
              <div>
                <h3 className="font-semibold">3. 금지 행위</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>서비스의 비정상적 접근, 크롤링/스크래핑 등 무단 수집</li>
                  <li>타인의 권리(저작권·상표권 등) 침해</li>
                  <li>허위 정보 게시, 불법·유해 정보 유포</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold">4. 서비스 변경 및 중단</h3>
                <p>회사는 서비스의 품질 향상을 위해 기능 변경·수정·중단을 할 수 있으며, 중대한 변경의 경우 사전 공지합니다.</p>
              </div>
              <div>
                <h3 className="font-semibold">5. 면책</h3>
                <p>서비스에서 제공되는 정보는 참고용이며, 투자 손익에 대한 책임은 이용자 본인에게 있습니다.</p>
              </div>
              <div>
                <h3 className="font-semibold">6. 준거법 및 관할</h3>
                <p>본 약관은 대한민국 법령에 따르며, 분쟁 발생 시 민사소송법상의 관할법원을 전속 관할로 합니다.</p>
              </div>
              <p className="text-xs text-gray-500">시행일: 2025-01-01</p>
            </div>
          </Modal>
          <Modal open={openPrivacy} onClose={()=>setOpenPrivacy(false)} title="개인정보처리방침">
            <div className="text-sm leading-relaxed space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              <div>
                <h3 className="font-semibold">1. 수집 항목</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>필수: 이메일, 비밀번호, 이름, (선택 설정 시) 휴대전화번호</li>
                  <li>선택: 닉네임, 성별, 관심분야, 서비스 이용 중 생성되는 로그·쿠키·기기정보</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold">2. 수집·이용 목적</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>회원가입 및 본인확인, 계정 관리</li>
                  <li>서비스 제공 및 이용 통계, 고객지원</li>
                  <li>보안·부정이용 방지, 공지사항 전달</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold">3. 보유 및 이용기간</h3>
                <p>회원 탈퇴 시 또는 목적 달성 시까지 보관하며, 관계 법령에 따라 필요한 경우 해당 기간 동안 보관합니다.</p>
              </div>
              <div>
                <h3 className="font-semibold">4. 처리 위탁</h3>
                <p>원활한 서비스 제공을 위해 일부 업무를 외부 전문업체에 위탁할 수 있으며, 위탁 시 개인정보 보호를 위해 필요한 사항을 계약에 명시합니다.</p>
              </div>
              <div>
                <h3 className="font-semibold">5. 제3자 제공 동의(필수)</h3>
                <p>회사는 아래 목적 범위에서 개인정보를 제3자에게 제공합니다. 이용자는 서비스 이용을 위해 해당 제공에 필수적으로 동의하여야 합니다.</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>제공받는 자: 결제대행사(PG), 문자발송/인증 대행사, 오류 모니터링/분석 서비스 제공사</li>
                  <li>제공 항목: 이메일, 휴대전화번호(인증 시), 주문/결제 관련 정보, 서비스 로그 일부(오류·성능 분석 목적)</li>
                  <li>제공 목적: 결제 처리 및 환불, 본인확인 및 2단계 인증, 시스템 안정성 확보(오류 분석·보안)</li>
                  <li>보유·이용 기간: 목적 달성 시 또는 관련 법령에 따른 기간까지 보관 후 파기</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold">6. 이용자 권리</h3>
                <p>이용자는 개인정보 열람·정정·삭제·처리정지 등을 언제든지 요청할 수 있습니다. 문의: support@example.com</p>
              </div>
              <div>
                <h3 className="font-semibold">7. 파기 절차 및 방법</h3>
                <p>보유기간 경과 또는 처리 목적 달성 시 지체 없이 안전한 방법으로 파기합니다.</p>
              </div>
              <p className="text-xs text-gray-500">시행일: 2025-01-01</p>
            </div>
          </Modal>
          <Modal open={openThird} onClose={()=>setOpenThird(false)} title="제3자 정보 제공 동의">
            <div className="text-sm leading-relaxed space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              <p>서비스 제공을 위해 아래와 같이 개인정보를 제3자에게 제공합니다. 본 동의는 서비스 이용을 위한 필수 항목입니다.</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>제공받는 자: (주)바른사람들,결제대행사(PG), 문자발송/인증 대행사, 오류 모니터링·분석 서비스 제공사</li>
                <li>제공 항목: 이메일, 휴대전화번호(인증 시), 주문/결제 관련 정보, 서비스 로그 일부(오류·성능 분석 목적)</li>
                <li>제공 목적: 결제 처리 및 환불, 본인확인 및 2단계 인증, 시스템 안정성 확보(오류 분석·보안)</li>
                <li>보유·이용 기간: 목적 달성 시 또는 관련 법령에 따른 보관 기간까지 보관 후 파기</li>
              </ul>
              <p className="text-xs text-gray-500">시행일: 2025-01-01</p>
            </div>
          </Modal>

          {/* 메시지 */}
          {notice && <div className="text-sm text-emerald-400">{notice}</div>}
          {error && <div className="text-sm text-rose-400">{error}</div>}
          {cooldown > 0 && <div className="text-xs text-gray-400">대기시간: {cooldown}초</div>}

          {/* 버튼 */}
          <button disabled={sending || cooldown > 0} className="w-full px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">
            {sending ? '처리중...' : cooldown > 0 ? `대기 중 (${cooldown}s)` : '회원가입'}
          </button>

        </form>
      </div>
    </section>
  )
}






