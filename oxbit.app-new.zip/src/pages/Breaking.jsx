import React, { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { listBreaking, subscribeBreaking, getEnvStatus } from '../features/breaking'

export default function Breaking({ limit = 200 }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('all')
  const [importantOnly, setImportantOnly] = useState(false)

  // 🧩 더미 데이터 20개
  const dummyData = Array.from({ length: 20 }).map((_, i) => ({
    id: i + 1,
    title:
      i % 3 === 0
        ? `BTC 급등, ${30000 + i * 50}달러 돌파`
        : i % 4 === 0
        ? `SEC, 이더리움 ETF 승인 검토 중…시장 기대감↑`
        : `비트코인 변동성 확대, 주요 거래소 입출금 급증`,
    body:
      i % 2 === 0
        ? `오늘 오전 ${9 + i % 5}시 기준 주요 거래소에서 비트코인 가격이 ${30000 + i * 100}달러를 돌파하며 강세를 이어가고 있다. 시장 전문가들은 단기 조정 가능성도 배제할 수 없다고 분석했다.`
        : `미국 증시 강세에 따라 암호화폐 시장도 상승세를 보이고 있다. 특히 기관 투자자의 매수세가 강화되며 BTC와 ETH 모두 반등세를 기록했다.`,
    created_at: new Date(Date.now() - i * 1000 * 60 * 45).toISOString(), // 약 45분 간격
    status: i % 2 === 0 ? 'public' : 'private',
    important: i % 5 === 0,
  }))

  useEffect(() => {
    let active = true
    const env = getEnvStatus()

    async function load() {
      try {
        setLoading(true)
        // Supabase 설정이 없으면 더미 데이터로 대체
        if (!env.hasUrl || !env.hasKey) {
          console.warn('환경변수 누락, 더미 데이터 사용')
          setItems(dummyData)
          return
        }
        const data = await listBreaking({ limit })
        if (!active) return
        setItems(Array.isArray(data) && data.length > 0 ? data : dummyData)
      } catch (e) {
        if (!active) return
        console.error(e)
        setError('데이터를 불러오는 데 실패했습니다. (더미 데이터 표시)')
        setItems(dummyData)
      } finally {
        if (active) setLoading(false)
      }
    }

    load()
    const unsub = subscribeBreaking?.((payload) => {
      const rec = payload?.new || payload?.record || payload
      if (!rec) return
      setItems((prev) => {
        const exists = prev.some((p) => p.id === rec.id)
        const next = exists
          ? prev.map((p) => (p.id === rec.id ? rec : p))
          : [rec, ...prev]
        return next.sort(
          (a, b) => new Date(b.created_at) - new Date(a.created_at)
        )
      })
    })
    return () => {
      try {
        unsub?.()
      } catch {}
      active = false
    }
  }, [limit])

  const filtered = useMemo(() => {
    let data = items
    if (status !== 'all')
      data = data.filter((it) =>
        status === 'public' ? it.status === 'public' : it.status !== 'public'
      )
    if (importantOnly) data = data.filter((it) => !!it.important)
    if (q.trim()) {
      const s = q.trim().toLowerCase()
      data = data.filter(
        (it) =>
          (it.title || '').toLowerCase().includes(s) ||
          (it.body || '').toLowerCase().includes(s)
      )
    }
    return data
  }, [items, status, importantOnly, q])

  const groups = useMemo(() => {
    const by = new Map()
    for (const it of filtered) {
      const d = it.created_at ? new Date(it.created_at) : new Date()
      const key = d.toISOString().slice(0, 10)
      if (!by.has(key)) by.set(key, [])
      by.get(key).push(it)
    }
    return Array.from(by.entries()).sort((a, b) => (a[0] < b[0] ? 1 : -1))
  }, [filtered])

  function fmtHeader(key) {
    const d = new Date(key)
    const today = new Date()
    const isToday = d.toDateString() === today.toDateString()
    const day = new Intl.DateTimeFormat('ko-KR', { dateStyle: 'full' }).format(d)
    return isToday ? `오늘, ${day}` : day
  }

  function timeText(d) {
    const hh = String(d.getHours()).padStart(2, '0')
    const mm = String(d.getMinutes()).padStart(2, '0')
    return `${hh}:${mm}`
  }

  return (
    <div className="mx-auto max-w-5xl px-3 py-6 md:max-w-6xl md:px-4 md:py-8 text-zinc-200">
      {/* 날짜 */}
      <div className="mb-6 flex items-center gap-2 text-sm text-zinc-400">
        <span className="rounded bg-white/5 px-2 py-0.5">오늘</span>
        <span>
          {new Date().toLocaleDateString('ko-KR', { dateStyle: 'full' })}
        </span>
      </div>

      {/* 뉴스 리스트 */}
      <section className="rounded-lg border border-zinc-800 bg-[#0a0c10] shadow-sm">
        {loading ? (
          <p className="p-4 text-zinc-400">불러오는 중…</p>
        ) : error ? (
          <p className="p-4 text-red-400">{error}</p>
        ) : groups.length === 0 ? (
          <p className="p-4 text-zinc-400">표시할 속보가 없습니다.</p>
        ) : (
          <div className="divide-y divide-zinc-800">
            {groups.map(([key, arr]) => (
              <div key={key} className="p-3 md:p-4">
                <div className="mb-3 flex items-center gap-2 text-sm text-zinc-500">
                  <span className="inline-flex items-center gap-1 rounded bg-white/5 px-2 py-0.5">
                    🗓 날짜
                  </span>
                  <span>{fmtHeader(key)}</span>
                </div>
                <ul className="space-y-4">
                  {arr.map((it) => {
                    const d = new Date(it.created_at)
                    return (
                      <li
                        key={it.id}
                        className="rounded-lg border border-zinc-800 bg-[#111317] p-4 hover:border-zinc-700 transition"
                      >
                        <div className="flex items-start gap-3">
                          <div className="mt-0.5 w-12 shrink-0 text-right">
                            <span className="inline-block rounded bg-white/10 px-2 py-0.5 text-xs text-zinc-300">
                              {timeText(d)}
                            </span>
                          </div>

                          <div className="min-w-0 flex-1">
                            <Link
                              to={`/breaking/detail?id=${it.id}`}
                              className="block"
                            >
                              <h3 className="text-[15px] font-semibold leading-snug text-zinc-100 hover:text-blue-400 md:text-base">
                                {it.title}
                                {it.important ? (
                                  <span className="ml-2 align-middle text-xs text-red-400">
                                    🚨중요
                                  </span>
                                ) : null}
                              </h3>
                              {it.body ? (
                                <p className="mt-1 line-clamp-3 text-[13px] text-zinc-400 md:text-sm">
                                  {it.body}
                                </p>
                              ) : null}
                            </Link>

                            <div className="mt-2 flex items-center gap-4 text-xs text-zinc-500">
                              <span>❤️ {Math.floor(Math.random() * 200)}</span>
                              <span>💬 {Math.floor(Math.random() * 50)}</span>
                            </div>
                          </div>

                          <div className="hidden shrink-0 md:block">
                            <Link
                              to={`/breaking/detail?id=${it.id}`}
                              className="rounded bg-blue-600/10 px-3 py-1 text-xs text-blue-400 hover:bg-blue-600/20"
                            >
                              상세
                            </Link>
                          </div>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
