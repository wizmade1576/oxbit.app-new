import React from 'react'

function formatTime(d = new Date()) {
  const hh = String(d.getHours()).padStart(2, '0')
  const mm = String(d.getMinutes()).padStart(2, '0')
  return `${hh}:${mm}`
}

const MOCK = Array.from({ length: 12 }).map((_, i) => ({
  id: `mock-${i + 1}`,
  title: `속보 샘플 #${i + 1} — BTC 급등 · 매수세 유입`,
  body:
    '경제지표 발표, 거래소 입출금, 파생상품 포지션 변동 등 핵심 포인트를 정리한 샘플 본문입니다. #BTC #Binance #Onchain',
  created_at: new Date(Date.now() - i * 1000 * 60 * 7).toISOString(),
  important: i % 5 === 0,
}))

function extractTags(title = '', body = '') {
  const s = `${title} ${body}`
  const arr = s.match(/#[가-힣A-Za-z0-9]+/g) || []
  return Array.from(new Set(arr.map((v) => v.replace(/^#/, '')))).slice(0, 3)
}

export default function BreakingMock() {
  const today = React.useMemo(() => {
    const d = new Date()
    const yyyy = d.getFullYear()
    const mm = String(d.getMonth() + 1).padStart(2, '0')
    const dd = String(d.getDate()).padStart(2, '0')
    const wk = ['일','월','화','수','목','금','토'][d.getDay()]
    return `${yyyy}.${mm}.${dd} (${wk})`
  }, [])

  const [index, setIndex] = React.useState(0)
  React.useEffect(() => {
    const t = setInterval(() => setIndex((i) => (i + 1) % MOCK.length), 2500)
    return () => clearInterval(t)
  }, [])

  const current = MOCK[index]

  return (
    <section className="space-y-4">
      <header className="flex items-baseline justify-between">
        <h1 className="text-xl font-semibold text-white">속보 (Mock)</h1>
        <div className="text-xs text-gray-400">{today}</div>
      </header>

      {/* Top ticker (mock) */}
      <div className="w-full overflow-hidden border border-white/10 rounded-md bg-black/20">
        <div className="whitespace-nowrap py-2 px-3 text-sm flex items-center justify-between">
          <div>
            <span className="font-semibold text-[#1D6FEA] mr-2">속보</span>
            <span className="text-gray-200">{current?.title}</span>
          </div>
          <a href="/breaking" className="text-xs text-gray-400 hover:text-white">더보기</a>
        </div>
      </div>

      {/* List (mock) */}
      <div className="rounded-xl border border-white/10 bg-[#111318] divide-y divide-white/10">
        {MOCK.map((it) => (
          <article key={it.id} className="p-4 hover:bg-white/5 transition-colors">
            <div className="flex items-center justify-between gap-4">
              <h3 className="text-base font-medium text-gray-100 line-clamp-2">
                {it.title}
                {it.important && (
                  <span className="ml-2 align-middle text-[11px] text-rose-300">중요</span>
                )}
              </h3>
              <time className="whitespace-nowrap text-xs text-gray-500">
                {formatTime(new Date(it.created_at))}
              </time>
            </div>
            {it.body && (
              <p className="mt-1 text-sm text-gray-400 leading-relaxed line-clamp-2">{it.body}</p>
            )}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {extractTags(it.title, it.body).map((t) => (
                <span key={t} className="inline-flex items-center rounded-full bg-white/10 px-2 py-1 text-[11px] text-gray-200">#{t}</span>
              ))}
              <span className="ml-auto text-[11px] text-gray-500">모의 데이터</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

