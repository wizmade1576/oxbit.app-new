import React, { useEffect, useMemo, useState } from 'react'

const empty = { date: '', title: '', category: 'event', tags: '', link: '', source: '', desc: '', memo: '' }

export default function AdminSchedule() {
  const [form, setForm] = useState(empty)
  const [list, setList] = useState([])
  const [q, setQ] = useState('')
  const [editing, setEditing] = useState(null)

  const fetchList = () => {
    const params = new URLSearchParams()
    if (q) params.set('q', q)
    params.set('pageSize', '500')
    fetch(`/api/schedule?${params}`)
      .then(r=>r.json()).then(d=> setList(Array.isArray(d.items)? d.items : []))
      .catch(()=> setList([]))
  }
  useEffect(fetchList, [])

  const onSubmit = async (e) => {
    e.preventDefault()
    const body = {
      ...(editing||{}),
      date: form.date,
      day: ['', '일','월','화','수','목','금','토'][new Date(form.date).getDay()] + '요일',
      title: form.title,
      category: form.category,
      tags: form.tags ? form.tags.split(/\s+/).filter(Boolean) : [],
      link: form.link,
      source: form.source,
      desc: form.desc,
      memo: form.memo,
    }
    await fetch('/api/schedule', {
      method: editing ? 'PUT' : 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body)
    })
    setForm(empty); setEditing(null); fetchList()
  }

  const startEdit = (it) => {
    setEditing({ id: it.id })
    setForm({
      date: it.date || '',
      title: it.title || '',
      category: it.category || 'event',
      tags: (it.tags||[]).join(' '),
      link: it.link || '',
      source: it.source || '',
      desc: it.desc || '',
      memo: it.memo || '',
    })
  }

  const remove = async (id) => {
    if (!confirm('삭제하시겠습니까?')) return
    await fetch(`/api/schedule?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
    fetchList()
  }

  return (
    <section className="space-y-6">
      <h1 className="text-lg font-bold">일정 관리</h1>

      <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-3 rounded-xl border border-white/10 bg-[#111318] p-4">
        <div>
          <label className="block text-xs text-gray-400 mb-1">날짜</label>
          <input type="date" value={form.date} onChange={(e)=>setForm({...form, date:e.target.value})} className="w-full rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-sm text-gray-100" required />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">카테고리</label>
          <select value={form.category} onChange={(e)=>setForm({...form, category:e.target.value})} className="w-full rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-sm text-gray-100">
            <option value="major">주요이슈</option>
            <option value="project">프로젝트</option>
            <option value="exchange">거래소</option>
            <option value="event">이벤트</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs text-gray-400 mb-1">제목</label>
          <input value={form.title} onChange={(e)=>setForm({...form, title:e.target.value})} className="w-full rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-gray-100" required />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">태그 (#태그 공백 구분)</label>
          <input value={form.tags} onChange={(e)=>setForm({...form, tags:e.target.value})} className="w-full rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-gray-100" />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-1">출처/링크</label>
          <div className="flex gap-2">
            <input placeholder="source" value={form.source} onChange={(e)=>setForm({...form, source:e.target.value})} className="flex-1 rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-gray-100" />
            <input placeholder="https://" value={form.link} onChange={(e)=>setForm({...form, link:e.target.value})} className="flex-1 rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-gray-100" />
          </div>
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs text-gray-400 mb-1">설명</label>
          <textarea rows={3} value={form.desc} onChange={(e)=>setForm({...form, desc:e.target.value})} className="w-full rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-gray-100" />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs text-gray-400 mb-1">메모</label>
          <textarea rows={2} value={form.memo} onChange={(e)=>setForm({...form, memo:e.target.value})} className="w-full rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-gray-100" />
        </div>
        <div className="md:col-span-2 flex gap-2">
          <button type="submit" className="px-4 py-2 rounded-md bg-[#1D6FEA] text-white text-sm">{editing ? '수정' : '등록'}</button>
          {editing && <button type="button" onClick={()=>{setEditing(null); setForm(empty)}} className="px-3 py-2 rounded-md border border-white/10 text-sm text-gray-200">취소</button>}
        </div>
      </form>

      <div className="flex items-center gap-2">
        <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="검색" className="w-40 rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-sm text-gray-100" />
        <button onClick={fetchList} className="px-3 py-1.5 rounded-md border border-white/10 text-sm text-gray-200 hover:bg-white/10">검색</button>
      </div>

      <div className="rounded-xl border border-white/10 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-black/20 text-gray-400">
            <tr>
              <th className="px-3 py-2 text-left w-36">날짜</th>
              <th className="px-3 py-2 text-left">제목</th>
              <th className="px-3 py-2 text-left w-28">카테고리</th>
              <th className="px-3 py-2 text-right w-32">관리</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {list.map((it)=> (
              <tr key={it.id} className="hover:bg-white/5">
                <td className="px-3 py-2 text-gray-200 whitespace-nowrap">{it.date} ({it.day||''})</td>
                <td className="px-3 py-2 text-gray-100">{it.title}</td>
                <td className="px-3 py-2 text-gray-300 whitespace-nowrap">{it.category}</td>
                <td className="px-3 py-2 text-right whitespace-nowrap">
                  <button onClick={()=>startEdit(it)} className="px-2 py-1 rounded-md border border-white/10 text-xs text-gray-200 hover:bg-white/10 mr-2">수정</button>
                  <button onClick={()=>remove(it.id)} className="px-2 py-1 rounded-md border border-red-500/30 text-xs text-red-300 hover:bg-red-500/10">삭제</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

