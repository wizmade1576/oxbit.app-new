import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuthStore } from '../store/useAuthStore'

export default function ResetPassword() {
  const { resetPasswordForEmail } = useAuthStore()
  const [email, setEmail] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setNotice('')
    setSending(true)
    try {
      // redirectTo는 환경에 맞게 조정 가능
      await resetPasswordForEmail(email, window.location.origin + '/login')
      setNotice('비밀번호 재설정 링크를 이메일로 전송했습니다')
    } catch (err) {
      setError(err?.message || '요청에 실패했습니다')
    } finally { setSending(false) }
  }

  return (
    <section className="mx-auto max-w-md w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">비밀번호 재설정</h2>
          <Link to="/login" className="text-xs text-blue-400 hover:text-blue-300">로그인</Link>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-2">
            <label className="text-xs text-gray-300">이메일</label>
            <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required placeholder="name@example.com" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
          </div>
          {notice && <div className="text-sm text-emerald-400">{notice}</div>}
          {error && <div className="text-sm text-rose-400">{error}</div>}
          <button disabled={sending} className="w-full px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">{sending ? '처리 중…' : '재설정 링크 보내기'}</button>
        </form>
      </div>
    </section>
  )
}

