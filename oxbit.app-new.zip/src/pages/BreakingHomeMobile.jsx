import React from 'react';

function BreakingHomeMobile() {
  return (
    <div>
      <h1>모바일 속보 페이지</h1>
      {/* 모바일 관련 내용을 여기에 추가하세요 */}
    </div>
  );
}

export default BreakingHomeMobile;