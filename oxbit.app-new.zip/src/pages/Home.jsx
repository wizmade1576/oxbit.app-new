﻿import BreakingNews from '../components/BreakingNews.jsx'
import LiveFeed from '../components/LiveFeed.jsx'
import NewsFeed from '../components/NewsFeedNew.jsx'
import SearchInline from '../components/SearchInline.jsx'
import MetricsBar from '../components/MetricsBar.jsx'
import AdBanner from '../components/AdBanner.jsx'
import SignUpPanel from '../components/SignUpPanel.jsx'
import PairsBoard from '../components/PairsBoard.jsx'
import ManagedAd from '../components/ManagedAd.jsx'
import PopularCoins from '../components/PopularCoins.jsx'
import SidebarSchedule from '../components/Market/Schedule/SidebarSchedule.jsx'
import CommunityTopPosts from '../components/CommunityTopPosts.jsx'
import FearGreed from '../components/live/FearGreed.jsx'
import FundingSnapshot from '../components/FundingSnapshot.jsx'
import WhaleSummary from '../components/WhaleSummary.jsx'
import KimpSummary from '../components/KimpSummary.jsx'

export default function Home() {
  return (
    <div className="space-y-6 sm:space-y-8 px-3 md:px-0">
      <SearchInline />
      <AdBanner slot="home-top" />
      <MetricsBar />

      {/* 레이아웃: 모바일 1열 → md 2열 → lg 3열 */}
      <div className="grid gap-4 md:gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Left Content */}
        <div className="lg:col-span-2 space-y-6">
          <section id="breaking" className="space-y-6">
            <BreakingNews />

            {/* 뉴스 피드 영역 */}
            <section id="news">
              <NewsFeed limit={4} />

              {/* 뉴스 하단 광고 */}
              <div className="mt-10">
                <AdBanner slot="home-news-bottom" />
              </div>

              {/* 라이브 피드 */}
              <div className="mt-8 overflow-x-auto home-livefeed -mx-3 px-3 md:mx-0 md:px-0">
                <LiveFeed />
              </div>
              {/* 인기 코인: 변동률 상위 (가로폭 절반) */}
              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <CommunityTopPosts />
                <FearGreed />
              </div>
              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                <FundingSnapshot />
                <WhaleSummary />
              </div>
              {/* Removed: KimpSummary(2-col) + TopMoversSummary row */}
              <div className="mt-6 w-full">
                <KimpSummary />
              </div>
            </section>
          </section>
        </div>

        {/* Right Sidebar (데스크탑) */}
        <div className="hidden lg:block space-y-6">
          {/* 로그인/가입 패널 */}
          <SignUpPanel />

          {/* 실시간 마켓 */}
          <PairsBoard />

          {/* 광고 */}
          <ManagedAd slot="market-bottom" className="mt-3" />
          <SidebarSchedule max={7} />
        </div>
      </div>

      {/* 모바일/태블릿 사이드바 대체영역: 본문 아래로 이동 */}
      <div className="lg:hidden space-y-6">
        <SignUpPanel />
        <PairsBoard />
        <ManagedAd slot="market-bottom" className="mt-3" />
        <SidebarSchedule max={7} />
      </div>
    </div>
  )
}

