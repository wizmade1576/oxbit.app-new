export const formatNumber = (v) => {
  if (v === null || v === undefined || !isFinite(Number(v))) return '-'
  const n = Number(v)
  if (n >= 1_000_000_000) return (n / 1_000_000_000).toFixed(2) + 'B'
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2) + 'M'
  if (n >= 1_000) return (n / 1_000).toFixed(2) + 'K'
  return n.toLocaleString()
}

export const formatCurrency = (v, currency = 'KRW', max = 0) => {
  if (v === null || v === undefined || !isFinite(Number(v))) return '-'
  try {
    return new Intl.NumberFormat('ko-KR', { style: 'currency', currency, maximumFractionDigits: max }).format(Number(v))
  } catch {
    return Number(v).toLocaleString()
  }
}

export const tsToDate = (ts) => new Date(typeof ts === 'number' ? ts : Number(ts))

