// Force dark mode for now (can be reverted later)
(() => {
  try {
    const root = document.documentElement
    root.classList.add('dark')
    localStorage.setItem('theme', 'dark')
  } catch {}
})()
