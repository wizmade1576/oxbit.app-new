import React from 'react'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import MainApp from './App.tsx'

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  )
}

