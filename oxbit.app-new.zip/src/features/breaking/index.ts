export * from './services'
// Resolve directly to existing app pages/components to avoid TS/extension ambiguity
export { default as BreakingList } from '../../pages/Breaking.jsx'
export { default as BreakingDetail } from '../../pages/BreakingDetail.jsx'
export { default as BreakingHomeMobile } from '../../pages/BreakingHomeMobile.jsx'
export { default as BreakingTicker } from '../../components/BreakingTicker.jsx'
export { default as BreakingNewsWidget } from '../../components/BreakingNews.jsx'
export { default as AdminBreakingPage } from '../../admin/pages/Breaking.jsx'
