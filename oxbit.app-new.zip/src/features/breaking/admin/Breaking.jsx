export { default } from '../../../admin/pages/Breaking.jsx'

