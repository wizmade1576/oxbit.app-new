// TypeScript-friendly re-export for breaking services
export * from '../../services/breakingService.js'

