import { supabase } from '../services/supabase'

const isReady = () => !!(import.meta?.env?.VITE_SUPABASE_URL && import.meta?.env?.VITE_SUPABASE_ANON_KEY && !String(import.meta.env.VITE_SUPABASE_URL).includes('example.supabase.co'))

export function canUseSupabase() { return isReady() }

export async function listTable(table, { q = '', page = 1, pageSize = 20, order = { column: 'created_at', ascending: false }, qColumns = ['title','body'] } = {}) {
  if (!isReady()) throw new Error('Supabase not configured')
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1
  let query = supabase.from(table).select('*', { count: 'exact' }).range(from, to)
  if (order?.column) query = query.order(order.column, { ascending: !!order.ascending })
  if (q && q.trim() && Array.isArray(qColumns) && qColumns.length) {
    const term = q.trim()
    const ors = qColumns.map((c) => `${c}.ilike.%${term}%`).join(',')
    query = query.or(ors)
  }
  const { data, error, count } = await query
  if (error) throw error
  return { rows: data || [], total: count || 0 }
}

export async function upsertTable(table, row, pk = 'id') {
  if (!isReady()) throw new Error('Supabase not configured')
  const payload = { ...row }
  if (!payload[pk]) delete payload[pk]
  const { data, error } = await supabase.from(table).upsert(payload).select('*').single()
  if (error) throw error
  return data
}

export async function deleteFromTable(table, id, pk = 'id') {
  if (!isReady()) throw new Error('Supabase not configured')
  const { error } = await supabase.from(table).delete().eq(pk, id)
  if (error) throw error
  return { ok: true }
}

