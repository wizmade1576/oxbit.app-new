// Admin helpers (Supabase)
import { supabase } from '../services/supabase'

// -- Announcements CRUD --
export async function listAnnouncements({ q = '', page = 1, pageSize = 10 } = {}) {
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1
  let query = supabase
    .from('announcements')
    .select('*', { count: 'exact' })
    .order('pinned', { ascending: false })
    .order('created_at', { ascending: false })
    .range(from, to)

  if (q && q.trim()) {
    const term = q.trim()
    query = query.or(`title.ilike.%${term}%,body.ilike.%${term}%`)
  }

  const { data, error, count } = await query
  if (error) throw error
  return { rows: data || [], total: count || 0, page, pageSize }
}

export async function upsertAnnouncement(payload) {
  // payload: { id?, title, body, pinned }
  const row = {
    id: payload.id ?? undefined,
    title: payload.title,
    body: payload.body,
    pinned: !!payload.pinned,
    updated_at: new Date().toISOString(),
  }
  const { data, error } = await supabase
    .from('announcements')
    .upsert(row)
    .select('*')
    .single()
  if (error) throw error
  return data
}

export async function deleteAnnouncement(id) {
  const { error } = await supabase.from('announcements').delete().eq('id', id)
  if (error) throw error
  return { ok: true }
}

// Stubs for other admin areas (to be implemented)
export async function listPosts({ page = 1, q = '' } = {}) { return { rows: [], total: 0, page } }
export async function updatePost(id, patch) { return { ok: true } }
export async function deletePost(id) { return { ok: true } }
export async function listReports({ page = 1 } = {}) { return { rows: [], total: 0, page } }
export async function resolveReport(id, action = 'ignore') { return { ok: true } }
export async function listUsers({ page = 1, q = '' } = {}) { return { rows: [], total: 0, page } }
export async function changeUserRole(userId, role) { return { ok: true } }
export async function listAds() { return { rows: [] } }
export async function upsertAd(payload) { return { ok: true } }
export async function deleteAd(id) { return { ok: true } }
