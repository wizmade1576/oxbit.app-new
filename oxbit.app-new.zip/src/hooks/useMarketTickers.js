import { useQuery } from '@tanstack/react-query'
import { fetchSpotTickers } from '../services/marketService'

export function useMarketTickers({ exchange = 'binance', limit = 10, refetchMs = 60_000 } = {}) {
  const { data, isLoading, isFetching, error } = useQuery({
    queryKey: ['market:tickers', { exchange }],
    queryFn: () => fetchSpotTickers(exchange),
    staleTime: 30_000,
    refetchInterval: refetchMs,
  })
  const list = Array.isArray(data) ? data.slice(0, limit) : []
  return { list, isLoading, isFetching, error }
}

