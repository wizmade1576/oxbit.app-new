import { useQuery } from '@tanstack/react-query'
import { fetchFuturesTrades, fetchFuturesLiquidations, fetchSpotBuys, fetchSpotSells } from '../services/whaleService'

const staleTime = 30_000
const refetchInterval = 60_000

export function useFuturesTrades(params = {}) {
  return useQuery({
    queryKey: ['whale:futures:trades', params],
    queryFn: () => fetchFuturesTrades(params),
    staleTime,
    refetchInterval,
  })
}

export function useFuturesLiquidations(params = {}) {
  return useQuery({
    queryKey: ['whale:futures:liqs', params],
    queryFn: () => fetchFuturesLiquidations(params),
    staleTime,
    refetchInterval,
  })
}

export function useSpotBuys(params = {}) {
  return useQuery({
    queryKey: ['whale:spot:buys', params],
    queryFn: () => fetchSpotBuys(params),
    staleTime,
    refetchInterval,
  })
}

export function useSpotSells(params = {}) {
  return useQuery({
    queryKey: ['whale:spot:sells', params],
    queryFn: () => fetchSpotSells(params),
    staleTime,
    refetchInterval,
  })
}

