import React from 'react'
import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuthStore } from '../store/useAuthStore'
import { supabase } from '../services/supabase'

export default function AdminGuardFixed({ children }) {
  const { user, isAdmin: flagAdmin, init } = useAuthStore()
  const [loading, setLoading] = React.useState(true)
  const [ok, setOk] = React.useState(false)
  const isDev = typeof import.meta !== 'undefined' && !!import.meta.env?.DEV
  const envBypass = String(import.meta?.env?.VITE_ADMIN_NO_LOGIN || '') === '1'
  const loc = useLocation()

  React.useEffect(() => {
    (async () => {
      try {
        if (!user) {
          try { await init() } catch {}
        }
        let allowed = false
        const u = user || (await supabase.auth.getUser())?.data?.user
        if (u && (flagAdmin || u?.app_metadata?.claims?.admin)) {
          allowed = true
        } else if (u) {
          try {
            const { data } = await supabase.from('profiles').select('role').eq('id', u.id).maybeSingle()
            allowed = (data?.role || '').toLowerCase() === 'admin'
          } catch {}
        }
        if (!allowed && (isDev || envBypass)) {
          if (envBypass || localStorage.getItem('ADMIN_BYPASS') === '1') {
            allowed = true
          }
        }
        setOk(!!allowed)
      } finally {
        setLoading(false)
      }
    })()
  }, [user, flagAdmin, init])

  if (loading) return <div className="p-6 text-sm text-gray-400">관리자 권한 확인 중...</div>
  if (!ok) {
    const next = encodeURIComponent(loc.pathname + loc.search)
    return <Navigate to={`/login?next=${next}`} replace />
  }
  return children ? <>{children}</> : <Outlet />
}

