import React from 'react'

export default function AdminDashboard() {
  const cards = [
    { k: 'posts', label: '게시글', value: 0 },
    { k: 'reports', label: '신고', value: 0 },
    { k: 'users', label: '유저', value: 0 },
    { k: 'ads', label: '광고', value: 0 },
  ]
  return (
    <div className="space-y-4">
      <h1 className="text-lg font-semibold">관리자 대시보드</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {cards.map((c) => (
          <div key={c.k} className="rounded-lg border border-white/10 bg-white/5 p-4">
            <div className="text-xs text-gray-400">{c.label}</div>
            <div className="text-2xl font-bold text-white">{c.value}</div>
          </div>
        ))}
      </div>
      <div className="rounded-lg border border-white/10 bg-white/5 p-4 text-sm text-gray-300">
        최근 활동 로그가 여기에 표시됩니다. (연동 예정)
      </div>
    </div>
  )
}

