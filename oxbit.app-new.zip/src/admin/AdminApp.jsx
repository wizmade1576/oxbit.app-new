import React from 'react'
import { supabase } from '../services/supabase'
import { useAuthStore } from '../store/useAuthStore'
import Modal from '../components/Modal.jsx'
import { listAnnouncements, upsertAnnouncement, deleteAnnouncement } from '../supabase/adminService'
import { fetchLatestNews } from '../services/newsService'

function StatCard({ label, value }) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/5 p-4 min-w-[140px]">
      <div className="text-xs text-gray-400">{label}</div>
      <div className="text-2xl font-bold text-white">{value}</div>
    </div>
  )
}

function AdminLogin({ onSuccess }) {
  const { signInWithPassword } = useAuthStore()
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [error, setError] = React.useState('')
  const [loading, setLoading] = React.useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      await signInWithPassword(email, password)
      onSuccess && onSuccess()
    } catch (err) {
      setError(err?.message || '로그인에 실패했습니다')
    } finally { setLoading(false) }
  }

  return (
    <section className="mx-auto max-w-md w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <h1 className="text-lg font-semibold">관리자 로그인</h1>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-2">
            <label className="text-xs text-gray-300">이메일</label>
            <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required placeholder="admin@example.com" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
          </div>
          <div className="space-y-2">
            <label className="text-xs text-gray-300">비밀번호</label>
            <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={6} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
          </div>
          {error && <div className="text-sm text-rose-400">{error}</div>}
          <button disabled={loading} className="w-full px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">{loading ? '처리 중…' : '로그인'}</button>
        </form>
      </div>
    </section>
  )
}

export default function AdminApp() {
  const { user, init, signOut } = useAuthStore()
  const [ready, setReady] = React.useState(false)
  const [isAdmin, setIsAdmin] = React.useState(false)
  const [tab, setTab] = React.useState('home')

  // 공지 상태
  const [annLoading, setAnnLoading] = React.useState(false)
  const [annRows, setAnnRows] = React.useState([])
  const [annTotal, setAnnTotal] = React.useState(0)
  const [annQ, setAnnQ] = React.useState('')
  const [annPage, setAnnPage] = React.useState(1)
  const [annOpen, setAnnOpen] = React.useState(false)
  const [annForm, setAnnForm] = React.useState({ id: null, title: '', body: '', pinned: false })

  // 속보 상태
  const [dash, setDash] = React.useState({ newsCount: 0, breakingCount: 0, annCount: 0 })
  const [latestNews, setLatestNews] = React.useState([])
  const [breakingList, setBreakingList] = React.useState([])
  const [quickOpen, setQuickOpen] = React.useState(false)
  const [quickForm, setQuickForm] = React.useState({ title: '', body: '', important: false, imageUrl: '' })

  const [brLoading, setBrLoading] = React.useState(false)
  const [brRows, setBrRows] = React.useState([])
  const [brTotal, setBrTotal] = React.useState(0)
  const [brQ, setBrQ] = React.useState('')
  const [brPage, setBrPage] = React.useState(1)
  const [brOpen, setBrOpen] = React.useState(false)
  const [brForm, setBrForm] = React.useState({ id: null, title: '', body: '', important: false, imageUrl: '' })

  React.useEffect(() => {
    (async () => {
      try { await init() } catch {}
      setReady(true)
    })()
  }, [init])

  React.useEffect(() => {
    (async () => {
      if (!user) { setIsAdmin(false); return }
      if (user?.app_metadata?.claims?.admin) { setIsAdmin(true); return }
      const { data } = await supabase.from('profiles').select('role').eq('id', user.id).maybeSingle()
      setIsAdmin(String(data?.role || '').toLowerCase() === 'admin')
    })()
  }, [user])

  const loadAnnouncements = React.useCallback(async ({ page = annPage } = {}) => {
    setAnnLoading(true)
    try {
      const from = (page - 1) * 20
      const to = from + 19
      const { data, count } = await supabase
        .from('announcements')
        .select('*', { count: 'exact' })
        .ilike('title', `%${annQ}%`)
        .order('created_at', { ascending: false })
        .range(from, to)
      setAnnRows(Array.isArray(data) ? data : [])
      setAnnTotal(count || 0)
      setAnnPage(page)
    } finally { setAnnLoading(false) }
  }, [annQ, annPage])

  const uploadBreakingImage = React.useCallback(async (file) => {
    if (!file) return null
    try {
      const ext = (file.name.split('.').pop() || 'jpg').toLowerCase()
      const name = `${Date.now()}-${Math.random().toString(36).slice(2,8)}.${ext}`
      const path = `images/${name}`
      const { error: upErr } = await supabase.storage.from('breaking').upload(path, file, { upsert: true, contentType: file.type || 'image/*', cacheControl: '3600' })
      if (upErr) return null
      const { data: pub } = supabase.storage.from('breaking').getPublicUrl(path)
      return pub?.publicUrl || null
    } catch { return null }
  }, [])

  // Edge Function caller for breaking (admin writes)
  const callBreaking = React.useCallback(async (method, path = '', payload) => {
    const { data: sess } = await supabase.auth.getSession()
    const token = sess?.session?.access_token || ''
    const res = await fetch(`/functions/v1/breaking${path}`, {
      method,
      headers: {
        'content-type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: payload ? JSON.stringify(payload) : undefined,
    })
    if (!res.ok) {
      const txt = await res.text().catch(()=> '')
      throw new Error(txt || `HTTP ${res.status}`)
    }
    return res.json()
  }, [])

  const loadBreaking = React.useCallback(async ({ page = brPage } = {}) => {
    setBrLoading(true)
    try {
      const from = (page - 1) * 20
      const to = from + 19
      let query = supabase
        .from('breaking_news')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(from, to)
      const q = brQ.trim()
      if (q) query = query.ilike('title', `%${q}%`)
      const { data, count } = await query
      setBrRows(Array.isArray(data) ? data : [])
      setBrTotal(count || 0)
      setBrPage(page)
    } finally { setBrLoading(false) }
  }, [brQ, brPage])

  React.useEffect(() => {
    if (tab === 'announcements' && isAdmin) loadAnnouncements({ page: 1 })
    if (tab === 'breaking' && isAdmin) loadBreaking({ page: 1 })
  }, [tab, isAdmin, loadAnnouncements, loadBreaking])

  React.useEffect(() => {
    if (tab !== 'home') return
    ;(async () => {
      try {
        const [{ count: bCount }, { count: aCount }] = await Promise.all([
          supabase.from('breaking_news').select('id', { count: 'exact', head: true }),
          supabase.from('announcements').select('id', { count: 'exact', head: true }),
        ])
        setDash((d) => ({ ...d, breakingCount: bCount || 0, annCount: aCount || 0 }))
      } catch {}
      try {
        const news = await fetchLatestNews(8)
        setLatestNews(news || [])
        setDash((d) => ({ ...d, newsCount: (news || []).length }))
      } catch {}
      try {
        const { data } = await supabase
          .from('breaking_news')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(8)
        setBreakingList(Array.isArray(data) ? data : [])
      } catch {}
    })()
  }, [tab])

  const handleSaveAnnouncement = async () => {
    try {
      await upsertAnnouncement(annForm)
      setAnnOpen(false)
      await loadAnnouncements({ page: 1 })
    } catch (e) {
      alert(e.message || '저장에 실패했습니다')
    }
  }

  const handleDeleteAnnouncement = async (id) => {
    if (!confirm('삭제하시겠습니까?')) return
    try {
      await deleteAnnouncement(id)
      await loadAnnouncements({ page: 1 })
    } catch (e) {
      alert(e.message || '삭제에 실패했습니다')
    }
  }

  const reloadBreakingHome = React.useCallback(async () => {
    try {
      const { data } = await supabase
        .from('breaking_news')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(8)
      setBreakingList(Array.isArray(data) ? data : [])
    } catch {}
  }, [])

  const handleEditBreakingHome = async (item) => {
    const next = prompt('속보 제목 수정', item?.title || '')
    if (!next || !next.trim()) return
    await supabase.from('breaking_news').update({ title: next.trim() }).eq('id', item.id)
    await reloadBreakingHome()
  }

  const handleDeleteBreakingHome = async (id) => {
    if (!confirm('삭제하시겠습니까?')) return
    await supabase.from('breaking_news').delete().eq('id', id)
    await reloadBreakingHome()
  }

  if (!ready) return null
  if (!user || !isAdmin) return <AdminLogin onSuccess={() => setIsAdmin(true)} />

  return (
    <div className="min-h-screen bg-[#0F1114] text-gray-200">
      <div className="mx-auto max-w-6xl px-4 py-6 space-y-6">
        <header className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">관리자</h1>
          <div className="flex items-center gap-2">
            <button onClick={()=>setTab('home')} className={`px-3 py-1.5 rounded ${tab==='home'?'bg-white/10':'bg-white/5'} text-sm`}>대시보드</button>
            <button onClick={()=>setTab('breaking')} className={`px-3 py-1.5 rounded ${tab==='breaking'?'bg-white/10':'bg-white/5'} text-sm`}>속보 관리</button>
            <button onClick={()=>setTab('announcements')} className={`px-3 py-1.5 rounded ${tab==='announcements'?'bg-white/10':'bg-white/5'} text-sm`}>공지</button>
            <button onClick={signOut} className="px-3 py-1.5 rounded bg-white/10 text-sm">로그아웃</button>
          </div>
        </header>

        {tab==='home' && (
          <section className="space-y-4">
            <div className="flex gap-3 flex-wrap">
              <StatCard label="뉴스 수" value={dash.newsCount} />
              <StatCard label="속보 수" value={dash.breakingCount} />
              <StatCard label="공지 수" value={dash.annCount} />
            </div>

            <div className="rounded-xl border border-white/10 bg-[#13161A]">
              <div className="p-4 border-b border-white/10 flex items-center justify-between">
                <h2 className="text-sm font-semibold">홈 상단 속보(최근 8건)</h2>
                <div className="flex items-center gap-2">
                  <button onClick={()=>setQuickOpen(true)} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">빠른 등록</button>
                </div>
              </div>
              <div className="divide-y divide-white/10">
                {(breakingList||[]).map((b)=> (
                  <div key={b.id} className="flex items-center justify-between px-4 py-2 text-sm">
                    <div className="flex items-center gap-2">
                      {b.important ? <span className="text-rose-400 font-semibold">중요</span> : null}
                      <span className="text-gray-100">{b.title}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => handleEditBreakingHome(b)} className="px-2 py-1 text-[11px] rounded border border-white/10 hover:bg-white/5">수정</button>
                      <button onClick={() => handleDeleteBreakingHome(b.id)} className="px-2 py-1 text-[11px] rounded border border-white/10 hover:bg-white/5 text-rose-300">삭제</button>
                    </div>
                  </div>
                ))}
                {(breakingList||[]).length===0 && (
                  <div className="p-4 text-sm text-gray-400">등록된 속보가 없습니다.</div>
                )}
              </div>
            </div>
          </section>
        )}

        {quickOpen && (
          <Modal open={quickOpen} onClose={()=>setQuickOpen(false)} title="속보 등록">
            <div className="space-y-3 w-[90vw] max-w-3xl">
              <div className="space-y-1">
                <label className="text-xs text-gray-300">제목</label>
                <input value={quickForm.title} onChange={(e)=>setQuickForm({...quickForm, title:e.target.value})} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-gray-300">본문(선택)</label>
                <textarea value={quickForm.body} onChange={(e)=>setQuickForm({...quickForm, body:e.target.value})} rows={10} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
              </div>
              <label className="inline-flex items-center gap-2 text-sm text-gray-300">
                <input type="checkbox" className="accent-[#1D6FEA]" checked={!!quickForm.important} onChange={(e)=>setQuickForm({...quickForm, important:e.target.checked})} /> 중요 표시
              </label>
              <label className="inline-flex items-center gap-2 text-sm text-gray-300">
                <input type="checkbox" className="accent-[#1D6FEA]" checked readOnly disabled /> 공개
              </label>
              <div className="space-y-1">
                <label className="text-xs text-gray-300">이미지 URL(선택)</label>
                <input value={quickForm.imageUrl} onChange={(e)=>setQuickForm({...quickForm, imageUrl:e.target.value})} placeholder="https://..." className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                <div className="flex items-center gap-2">
                  <input type="file" accept="image/*" onChange={async(e)=>{ const f=e.target.files?.[0]; if(!f) return; const url=await uploadBreakingImage(f); if(url) setQuickForm((s)=>({...s, imageUrl:url})) }} className="text-xs" />
                  {quickForm.imageUrl ? <img src={quickForm.imageUrl} alt="preview" className="h-12 rounded" /> : null}
                </div>
              </div>
              <div className="flex items-center justify-end gap-2">
                <button onClick={()=>setQuickOpen(false)} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">취소</button>
                <button onClick={async()=>{ const title=(quickForm.title||'').trim(); const body=(quickForm.body||'').trim(); if(!title) return; const important=!!quickForm.important; const image_url=(quickForm.imageUrl||'').trim()||null; const status='public'; await callBreaking('POST', '', { title, body: body||null, important, image_url, status }); setQuickOpen(false); setQuickForm({ title:'', body:'', important:false, imageUrl:'' }); try { const { data } = await supabase.from('breaking_news').select('*').order('created_at', { ascending:false }).limit(8); setBreakingList(Array.isArray(data)?data:[]) } catch {} }} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">저장</button>
              </div>
            </div>
          </Modal>
        )}

        {tab==='breaking' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <input value={brQ} onChange={(e)=>setBrQ(e.target.value)} placeholder="제목 검색" className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                <button onClick={()=>loadBreaking({ page:1 })} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">검색</button>
              </div>
              <button onClick={()=>{ setBrForm({ id:null, title:'', body:'', important:false, imageUrl:'' }); setBrOpen(true) }} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">속보추가</button>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#13161A]">
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead className="text-left text-gray-400">
                    <tr>
                      <th className="py-2 px-3">ID</th>
                      <th className="px-3">제목</th>
                      <th className="px-3">중요</th>
                      <th className="px-3">생성일</th>
                      <th className="px-3 text-right">관리</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(brRows || []).map((r)=> (
                      <tr key={r.id} className="border-t border-white/10">
                        <td className="py-2 px-3">{r.id}</td>
                        <td className="px-3 text-gray-100">{r.title}</td>
                        <td className="px-3">{r.important ? '중요' : '-'}</td>
                        <td className="px-3">{new Date(r.created_at).toLocaleString()}</td>
                        <td className="px-3 text-right">
                          <div className="inline-flex items-center gap-2">
                            <button onClick={()=>{ setBrForm({ id:r.id, title:r.title||'', body:r.body||'', important:!!r.important, imageUrl:r.image_url||'' }); setBrOpen(true) }} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">수정</button>
                            <button onClick={async()=>{ if(!confirm('삭제하시겠습니까?')) return; try { await callBreaking('DELETE', `/${r.id}`) } finally { loadBreaking({ page: 1 }) } }} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 text-rose-300">삭제</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(brRows||[]).length===0 && (
                      <tr><td colSpan={5} className="py-4 px-3 text-sm text-gray-400">결과가 없습니다.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2">
              <button disabled={brPage<=1} onClick={()=>loadBreaking({ page: brPage-1 })} className="px-2 py-1 rounded border border-white/10 disabled:opacity-50">이전</button>
              <button disabled={(brRows||[]).length===0} onClick={()=>loadBreaking({ page: brPage+1 })} className="px-2 py-1 rounded border border-white/10">다음</button>
            </div>

            <Modal open={brOpen} onClose={()=>setBrOpen(false)} title={brForm.id ? '속보 수정' : '속보 등록'}>
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs text-gray-300">제목</label>
                  <input value={brForm.title} onChange={(e)=>setBrForm({...brForm, title:e.target.value})} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-gray-300">본문</label>
                  <textarea value={brForm.body || ''} onChange={(e)=>setBrForm({...brForm, body:e.target.value})} rows={8} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                </div>
                <label className="inline-flex items-center gap-2 text-sm text-gray-300">
                  <input type="checkbox" className="accent-[#1D6FEA]" checked={!!brForm.important} onChange={(e)=>setBrForm({...brForm, important:e.target.checked})} /> 중요 표시
                </label>
                <label className="inline-flex items-center gap-2 text-sm text-gray-300">
                  <input type="checkbox" className="accent-[#1D6FEA]" checked readOnly disabled /> 공개
                </label>
                <div className="space-y-1">
                  <label className="text-xs text-gray-300">이미지 URL(선택)</label>
                  <input value={brForm.imageUrl} onChange={(e)=>setBrForm({...brForm, imageUrl:e.target.value})} placeholder="https://..." className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                  <div className="flex items-center gap-2">
                    <input type="file" accept="image/*" onChange={async(e)=>{ const f=e.target.files?.[0]; if(!f) return; const url=await uploadBreakingImage(f); if(url) setBrForm((s)=>({...s, imageUrl:url})) }} className="text-xs" />
                    {brForm.imageUrl ? <img src={brForm.imageUrl} alt="preview" className="h-12 rounded" /> : null}
                  </div>
                </div>
                <div className="text-right">
                  <button onClick={async()=>{ const title=(brForm.title||'').trim(); const body=(brForm.body||'').trim(); if(!title) return; const important=!!brForm.important; const image_url=(brForm.imageUrl||'').trim()||null; const status='public'; if(brForm.id){ await callBreaking('PATCH', `/${brForm.id}`, { title, body: body||null, important, image_url, status }) } else { await callBreaking('POST', '', { title, body: body||null, important, image_url, status }) } setBrOpen(false); await loadBreaking({ page:1 }) }} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">저장</button>
                </div>
              </div>
            </Modal>
          </div>
        )}

        {tab==='announcements' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <input value={annQ} onChange={(e)=>setAnnQ(e.target.value)} placeholder="제목/내용 검색" className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                <button onClick={()=>loadAnnouncements({ page:1 })} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">검색</button>
              </div>
              <button onClick={()=>{ setAnnForm({ id:null, title:'', body:'', pinned:false }); setAnnOpen(true) }} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">새 공지</button>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#13161A]">
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead className="text-left text-gray-400">
                    <tr>
                      <th className="py-2 px-3">ID</th>
                      <th className="px-3">제목</th>
                      <th className="px-3">고정</th>
                      <th className="px-3">작성일</th>
                      <th className="px-3 text-right">관리</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(annRows || []).map((r)=> (
                      <tr key={r.id} className="border-t border-white/10">
                        <td className="py-2 px-3">{r.id}</td>
                        <td className="px-3 text-gray-100">{r.title}</td>
                        <td className="px-3">{r.pinned ? '고정' : '-'}</td>
                        <td className="px-3">{new Date(r.created_at).toLocaleString()}</td>
                        <td className="px-3 text-right">
                          <div className="inline-flex items-center gap-2">
                            <button onClick={()=>{ setAnnForm({ id:r.id, title:r.title||'', body:r.body||'', pinned:!!r.pinned }); setAnnOpen(true) }} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">수정</button>
                            <button onClick={()=>handleDeleteAnnouncement(r.id)} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 text-rose-300">삭제</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {(annRows||[]).length===0 && (
                      <tr><td colSpan={5} className="py-4 px-3 text-sm text-gray-400">결과가 없습니다.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2">
              <button disabled={annPage<=1} onClick={()=>loadAnnouncements({ page: annPage-1 })} className="px-2 py-1 rounded border border-white/10 disabled:opacity-50">이전</button>
              <button disabled={(annRows||[]).length===0} onClick={()=>loadAnnouncements({ page: annPage+1 })} className="px-2 py-1 rounded border border-white/10">다음</button>
            </div>

            <Modal open={annOpen} onClose={()=>setAnnOpen(false)} title={annForm.id ? '공지 수정' : '새 공지'}>
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs text-gray-300">제목</label>
                  <input value={annForm.title} onChange={(e)=>setAnnForm({...annForm, title:e.target.value})} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-gray-300">내용</label>
                  <textarea value={annForm.body} onChange={(e)=>setAnnForm({...annForm, body:e.target.value})} rows={6} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
                </div>
                <label className="inline-flex items-center gap-2 text-sm text-gray-300">
                  <input type="checkbox" checked={!!annForm.pinned} onChange={(e)=>setAnnForm({...annForm, pinned:e.target.checked})} className="accent-[#1D6FEA]" /> 상단 고정
                </label>
                <div className="text-right">
                  <button onClick={handleSaveAnnouncement} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">저장</button>
                </div>
              </div>
            </Modal>
          </div>
        )}
      </div>
    </div>
  )
}
