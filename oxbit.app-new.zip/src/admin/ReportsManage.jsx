import React from 'react'

export default function ReportsManage() {
  const rows = Array.from({ length: 10 }).map((_, i) => ({ id: i + 1, postId: i + 100, reason: '스팸/홍보', reporter: 'user@example.com', at: '1시간 전' }))
  return (
    <div className="space-y-3">
      <h2 className="text-base font-semibold">신고 관리</h2>
      <div className="overflow-x-auto -mx-2">
        <table className="min-w-full text-sm mx-2">
          <thead>
            <tr className="text-left text-gray-400">
              <th className="py-2">ID</th>
              <th>게시글</th>
              <th>사유</th>
              <th>신고자</th>
              <th>시간</th>
              <th className="text-right">처리</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-white/10">
                <td className="py-2">{r.id}</td>
                <td>#{r.postId}</td>
                <td>{r.reason}</td>
                <td>{r.reporter}</td>
                <td>{r.at}</td>
                <td className="text-right space-x-2">
                  <button className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">무시</button>
                  <button className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 text-rose-300">삭제</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

