import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminAds() {
  return (
    <CrudScaffold
      title="광고"
      resourceKey="ads"
      table="ads"
      searchKeys={["title","link"]}
      columns={[
        { key: 'title', label: '제목' },
        { key: 'link', label: '링크' },
        { key: 'active', label: '활성' },
      ]}
      fields={[
        { key: 'title', label: '제목', type: 'text' },
        { key: 'image_url', label: '이미지 URL', type: 'url' },
        { key: 'link', label: '링크', type: 'url' },
        { key: 'active', label: '활성', type: 'checkbox', checkLabel: '활성화' },
      ]}
    />
  )
}
