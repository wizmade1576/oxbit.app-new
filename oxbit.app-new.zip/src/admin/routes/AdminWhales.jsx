import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminWhales() {
  return (
    <CrudScaffold
      title="고래"
      resourceKey="whales"
      searchKeys={["feed","note"]}
      columns={[
        { key: 'feed', label: '피드' },
        { key: 'note', label: '비고' },
        { key: 'enabled', label: '사용' },
      ]}
      fields={[
        { key: 'feed', label: '피드 이름', type: 'text' },
        { key: 'note', label: '비고', type: 'text' },
        { key: 'enabled', label: '사용', type: 'checkbox', checkLabel: '사용' },
      ]}
    />
  )
}

