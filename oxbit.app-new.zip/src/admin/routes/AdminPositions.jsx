import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminPositions() {
  return (
    <CrudScaffold
      title="포지션"
      resourceKey="positions"
      searchKeys={["name","type"]}
      columns={[
        { key: 'name', label: '지표명' },
        { key: 'type', label: '종류' },
        { key: 'active', label: '활성' },
      ]}
      fields={[
        { key: 'name', label: '지표명', type: 'text' },
        { key: 'type', label: '종류', type: 'text' },
        { key: 'active', label: '활성', type: 'checkbox', checkLabel: '활성화' },
      ]}
    />
  )
}

