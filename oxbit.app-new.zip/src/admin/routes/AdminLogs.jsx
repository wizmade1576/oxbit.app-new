import React from 'react'
import { supabase } from '../../services/supabase'
import Card from '../ui/Card.jsx'

const ACTIONS = ['ban','unban','delete','set_role','disable','enable','resend_confirm']

export default function AdminLogs() {
  const [q, setQ] = React.useState('')
  const [action, setAction] = React.useState('')
  const [rows, setRows] = React.useState([])
  const [loading, setLoading] = React.useState(false)
  const [page, setPage] = React.useState(1)
  const pageSize = 20

  const load = React.useCallback(async (opts = {}) => {
    setLoading(true)
    try {
      const search = opts.search ?? q
      const act = opts.action ?? action
      const pageNo = opts.page ?? page
      const { data, error } = await supabase.rpc('admin_list_logs', {
        search: search || null,
        action_filter: act || null,
        page_size: pageSize,
        page_no: pageNo,
      })
      if (error) throw error
      setRows(data || [])
    } catch (e) { console.error(e); setRows([]) }
    finally { setLoading(false) }
  }, [q, action, page])

  React.useEffect(()=>{ load({}) }, [])

  return (
    <div className="space-y-4">
      <Card title="관리 로그" desc="검색/필터로 모더레이션 이력 조회">
        <div className="flex gap-2 items-center mb-3">
          <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="이메일/사유/메모 검색" className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm flex-1" />
          <select value={action} onChange={(e)=>setAction(e.target.value)} className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm">
            <option value="">전체</option>
            {ACTIONS.map(a=> <option key={a} value={a}>{a}</option>)}
          </select>
          <button onClick={()=>{ setPage(1); load({ search: q, action, page: 1 }) }} className="px-3 py-2 text-sm rounded border border-white/10 hover:bg-white/5">검색</button>
        </div>
        <div className="overflow-x-auto -mx-2">
          <table className="min-w-full text-sm mx-2">
            <thead>
              <tr className="text-left text-gray-400">
                <th className="py-2">시간</th>
                <th>대상 이메일</th>
                <th>행위</th>
                <th>사유</th>
                <th>메모</th>
                <th>실행자</th>
              </tr>
            </thead>
            <tbody>
              {loading && (<tr><td className="py-3 text-gray-400" colSpan={6}>불러오는 중…</td></tr>)}
              {!loading && rows.length === 0 && (<tr><td className="py-3 text-gray-400" colSpan={6}>결과가 없습니다</td></tr>)}
              {rows.map((r)=> (
                <tr key={r.id} className="border-t border-white/10">
                  <td className="py-2">{r.created_at ? new Date(r.created_at).toLocaleString() : '-'}</td>
                  <td>{r.user_email || r.user_id || '-'}</td>
                  <td>{r.action}</td>
                  <td className="max-w-[360px] truncate" title={r.reason || ''}>{r.reason || '-'}</td>
                  <td className="max-w-[360px] truncate" title={r.note || ''}>{r.note || '-'}</td>
                  <td>{r.actor_email || r.actor_id || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between mt-3">
          <div className="text-xs text-gray-400">페이지: {page}</div>
          <div className="space-x-2">
            <button disabled={page<=1} onClick={()=>{ const p=Math.max(1,page-1); setPage(p); load({ page: p }) }} className="px-2 py-1 text-xs rounded border border-white/10 disabled:opacity-40">이전</button>
            <button onClick={()=>{ const p=page+1; setPage(p); load({ page: p }) }} className="px-2 py-1 text-xs rounded border border-white/10">다음</button>
          </div>
        </div>
      </Card>
    </div>
  )
}

