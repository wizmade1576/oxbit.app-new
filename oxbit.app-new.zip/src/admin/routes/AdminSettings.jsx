import React from 'react'
import AdminTabsNav from '../components/AdminTabsNav.jsx'

export default function AdminSettings() {
  const [devBypass, setDevBypass] = React.useState(localStorage.getItem('ADMIN_BYPASS') === '1')
  return (
    <section className="ox-container mx-auto py-6 space-y-6">
      <h1 className="text-xl font-semibold text-white">관리자 · 설정</h1>
      <AdminTabsNav />

      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4 text-sm">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-white font-medium">개발용 가드 우회</div>
            <div className="text-gray-400">브라우저 localStorage ADMIN_BYPASS 플래그로 /admin 접근 허용</div>
          </div>
          <button
            onClick={() => {
              const next = !devBypass
              setDevBypass(next)
              if (next) localStorage.setItem('ADMIN_BYPASS','1'); else localStorage.removeItem('ADMIN_BYPASS')
            }}
            className={`px-3 py-2 rounded border ${devBypass ? 'bg-emerald-600/40 border-emerald-500/50 text-white' : 'border-white/10 text-gray-200'}`}
          >{devBypass ? '사용 중' : '비활성'}</button>
        </div>

        <div className="border-t border-white/10 pt-4">
          <div className="text-white font-medium mb-2">환경변수 안내</div>
          <div className="text-gray-300">.env에 VITE_ADMIN_NO_LOGIN=1 설정 시 개발 중 AdminGuard 우회가 가능합니다. 배포 환경에서는 반드시 제거하세요.</div>
        </div>
      </div>
    </section>
  )
}

