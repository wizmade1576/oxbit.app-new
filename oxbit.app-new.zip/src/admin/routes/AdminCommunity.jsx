import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminCommunity() {
  return (
    <CrudScaffold
      title="커뮤니티"
      resourceKey="community"
      searchKeys={["title","author","category"]}
      columns={[
        { key: 'title', label: '제목' },
        { key: 'author', label: '작성자' },
        { key: 'category', label: '카테고리' },
      ]}
      fields={[
        { key: 'title', label: '제목', type: 'text' },
        { key: 'author', label: '작성자', type: 'text' },
        { key: 'category', label: '카테고리', type: 'text' },
        { key: 'body', label: '본문', type: 'textarea', rows: 8 },
      ]}
    />
  )
}
