import React from 'react'
import { supabase } from '../../services/supabase'
import Card from '../ui/Card.jsx'

export default function AdminUsers() {
  const [q, setQ] = React.useState('')
  const [rows, setRows] = React.useState([])
  const [loading, setLoading] = React.useState(false)
  const [page, setPage] = React.useState(1)
  const [total, setTotal] = React.useState(0)
  const [sortBy, setSortBy] = React.useState('created_at')
  const [sortDir, setSortDir] = React.useState('desc')
  const pageSize = 20

  const load = React.useCallback(async (opts = {}) => {
    setLoading(true)
    try {
      const search = opts.search ?? q
      const pageNo = opts.page ?? page
      const { data, error } = await supabase.rpc('admin_list_users', {
        search: search || null,
        page_size: pageSize,
        page_no: pageNo,
        sort_by: sortBy,
        sort_dir: sortDir,
      })
      if (error) throw error
      setRows(data || [])
      const { data: cnt } = await supabase.rpc('admin_count_users', { search: search || null })
      setTotal(cnt || 0)
    } catch (e) {
      console.error(e)
      setRows([])
    } finally { setLoading(false) }
  }, [q, page, sortBy, sortDir])

  React.useEffect(() => { load({}) }, [])

  const requireToken = async () => {
    const { data: session } = await supabase.auth.getSession()
    const token = session?.session?.access_token
    if (!token) throw new Error('로그인이 필요합니다')
    return token
  }

  const changeRole = async (email, role, id) => {
    try {
      const token = await requireToken()
      const r = await fetch('/api/admin-set-role', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify(email ? { email, role } : { id, role })
      })
      const j = await r.json().catch(()=>({}))
      if (!r.ok) throw new Error(j?.error || '작업 실패')
      await load({})
    } catch (e) { console.error(e) }
  }

  const deleteUser = async (id) => {
    if (!confirm('정말 이 사용자를 삭제하시겠습니까?')) return
    try {
      const token = await requireToken()
      const r = await fetch('/api/admin-delete-user', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ id })
      })
      const j = await r.json().catch(()=>({}))
      if (!r.ok) throw new Error(j?.error || '삭제 실패')
      await load({})
    } catch (e) { console.error(e) }
  }

  const toggleBan = async (id, banned_until) => {
    try {
      const token = await requireToken()
      const action = banned_until ? 'unban' : 'ban'
      const reason = action === 'ban' ? (prompt('제한 사유(선택)') || null) : null
      const r = await fetch('/api/admin-ban-user', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ id, action, reason })
      })
      const j = await r.json().catch(()=>({}))
      if (!r.ok) throw new Error(j?.error || '작업 실패')
      await load({})
    } catch (e) { console.error(e) }
  }

  const toggleDisable = async (id, disabled) => {
    try {
      const token = await requireToken()
      const next = !disabled
      const reason = next ? (prompt('비활성화 사유(선택)') || null) : null
      const r = await fetch('/api/admin-disable-user', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ id, disable: next, reason })
      })
      const j = await r.json().catch(()=>({}))
      if (!r.ok) throw new Error(j?.error || '작업 실패')
      await load({})
    } catch (e) { console.error(e) }
  }

  const resendConfirm = async (email) => {
    try {
      const token = await requireToken()
      const note = prompt('안내 메모(선택)') || null
      const r = await fetch('/api/admin-resend-confirm', {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ email, note })
      })
      const j = await r.json().catch(()=>({}))
      if (!r.ok) throw new Error(j?.error || '작업 실패')
      alert('인증 메일을 재발송했습니다')
    } catch (e) { console.error(e) }
  }

  const SortBtn = ({ field, children }) => (
    <button className="underline-offset-2 hover:underline" onClick={()=>{ setSortBy(field); setSortDir(sortDir==='asc'?'desc':'asc'); load({}) }}>
      {children} {sortBy===field ? (sortDir==='asc'?'▲':'▼') : ''}
    </button>
  )

  return (
    <div className="space-y-4">
      <Card title="사용자" desc="검색/제한/비활성화 관리">
        <div className="flex gap-2 items-center mb-3">
          <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="이메일/전화/이름 검색" className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm flex-1" />
          <button onClick={()=>{ setPage(1); load({ search: q, page: 1 }) }} className="px-3 py-2 text-sm rounded border border-white/10 hover:bg-white/5">검색</button>
        </div>
        <div className="overflow-x-auto -mx-2">
          <table className="min-w-full text-sm mx-2">
            <thead>
              <tr className="text-left text-gray-400">
                <th className="py-2">ID</th>
                <th><SortBtn field="full_name">이름</SortBtn></th>
                <th><SortBtn field="phone">전화번호</SortBtn></th>
                <th><SortBtn field="email">이메일</SortBtn></th>
                <th>사용자명</th>
                <th><SortBtn field="role">권한</SortBtn></th>
                <th>비활성화</th>
                <th><SortBtn field="last_sign_in_at">최근 로그인</SortBtn></th>
                <th><SortBtn field="banned_until">제한</SortBtn></th>
                <th>유입경로</th>
                <th>Referrer</th>
                <th>인증</th>
                <th className="text-right">작업</th>
              </tr>
            </thead>
            <tbody>
              {loading && (<tr><td className="py-3 text-gray-400" colSpan={13}>불러오는 중…</td></tr>)}
              {!loading && rows.length === 0 && (<tr><td className="py-3 text-gray-400" colSpan={13}>검색 결과가 없습니다</td></tr>)}
              {rows.map((u) => (
                <tr key={u.id} className="border-t border-white/10">
                  <td className="py-2">{u.id}</td>
                  <td>{u.full_name || '-'}</td>
                  <td>{u.phone || '-'}</td>
                  <td>{u.email || '-'}</td>
                  <td>{u.username || '-'}</td>
                  <td>{u.role}</td>
                  <td>{u.disabled ? 'Y' : '-'}</td>
                  <td>{u.last_sign_in_at ? new Date(u.last_sign_in_at).toLocaleString() : '-'}</td>
                  <td>{u.banned_until ? new Date(u.banned_until).toLocaleString() : '-'}</td>
                  <td>{u.signup_source || '-'}</td>
                  <td className="max-w-[280px] truncate" title={u.signup_referrer || ''}>{u.signup_referrer || '-'}</td>
                  <td>{u.email_confirmed_at || u.phone_confirmed_at ? '인증됨' : '미확인'}</td>
                  <td className="text-right space-x-2">
                    <button onClick={()=>changeRole(u.email, u.role === 'admin' ? 'user' : 'admin', u.id)} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">
                      {u.role === 'admin' ? 'user로 변경' : 'admin으로 변경'}
                    </button>
                    <button onClick={()=>toggleDisable(u.id, u.disabled)} className={`px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 ${u.disabled ? 'text-emerald-300' : 'text-amber-300'}`}>{u.disabled ? '해제' : '비활성화'}</button>
                    <button onClick={()=>toggleBan(u.id, u.banned_until)} className={`px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 ${u.banned_until ? 'text-emerald-300' : 'text-amber-300'}`}>{u.banned_until ? '제한 해제' : '제한'}</button>
                    <button onClick={()=>resendConfirm(u.email)} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">인증 재발송</button>
                    <button onClick={()=>deleteUser(u.id)} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 text-rose-300">삭제</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between mt-3">
          <div className="text-xs text-gray-400">페이지: {page} / {Math.max(1, Math.ceil(total / pageSize))} · 총 {total}명</div>
          <div className="space-x-2">
            <button disabled={page<=1} onClick={()=>{ const p=Math.max(1,page-1); setPage(p); load({ page: p }) }} className="px-2 py-1 text-xs rounded border border-white/10 disabled:opacity-40">이전</button>
            <button disabled={page*pageSize>=total} onClick={()=>{ const p=page+1; setPage(p); load({ page: p }) }} className="px-2 py-1 text-xs rounded border border-white/10 disabled:opacity-40">다음</button>
          </div>
        </div>
      </Card>
    </div>
  )
}

