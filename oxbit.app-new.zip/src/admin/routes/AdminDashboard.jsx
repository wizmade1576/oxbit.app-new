import React from 'react'
import AdminTabsNav from '../components/AdminTabsNav.jsx'
import { countBreaking } from '../lib/adminLocal.js'

export default function AdminDashboard() {
  return (
    <section className="ox-container mx-auto py-6 space-y-6">
      <h1 className="text-xl font-semibold text-white">관리자 · 대시보드</h1>
      <AdminTabsNav />
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-8 text-sm text-gray-300 space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="rounded-lg border border-white/10 bg-white/5 p-4">
            <div className="text-xs text-gray-400">속보</div>
            <div className="text-2xl font-bold text-white">{countBreaking()}</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-white/5 p-4">
            <div className="text-xs text-gray-400">뉴스</div>
            <div className="text-2xl font-bold text-white">0</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-white/5 p-4">
            <div className="text-xs text-gray-400">공지</div>
            <div className="text-2xl font-bold text-white">0</div>
          </div>
        </div>
      </div>
    </section>
  )
}
