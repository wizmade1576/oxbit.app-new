import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminBreaking() {
  return (
    <CrudScaffold
      title="속보"
      resourceKey="breaking_news"
      table="breaking_news"
      searchKeys={["title","body"]}
      columns={[
        { key: 'title', label: '제목' },
        { key: 'body', label: '본문' },
      ]}
      fields={[
        { key: 'title', label: '제목', type: 'text' },
        { key: 'body', label: '본문', type: 'textarea', rows: 8 },
      ]}
    />
  )
}
