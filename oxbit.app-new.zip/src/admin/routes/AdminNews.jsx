import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminNews() {
  return (
    <CrudScaffold
      title="뉴스"
      resourceKey="news"
      table="news"
      searchKeys={["title","summary","body","source"]}
      columns={[
        { key: 'title', label: '제목' },
        { key: 'summary', label: '요약' },
        { key: 'source', label: '출처' },
      ]}
      fields={[
        { key: 'title', label: '제목', type: 'text' },
        { key: 'summary', label: '요약', type: 'text' },
        { key: 'body', label: '본문', type: 'textarea', rows: 8 },
        { key: 'source', label: '출처', type: 'text' },
        { key: 'link', label: '링크', type: 'url' },
      ]}
    />
  )
}
