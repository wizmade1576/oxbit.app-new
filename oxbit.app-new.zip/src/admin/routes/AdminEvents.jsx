import React from 'react'
import CrudScaffold from '../components/CrudScaffold.jsx'

export default function AdminEvents() {
  return (
    <CrudScaffold
      title="이벤트"
      resourceKey="events"
      table="events"
      searchKeys={["title","desc","link"]}
      columns={[
        { key: 'title', label: '제목' },
        { key: 'date', label: '일자' },
        { key: 'link', label: '링크' },
      ]}
      fields={[
        { key: 'title', label: '제목', type: 'text' },
        { key: 'date', label: '일자', type: 'date' },
        { key: 'desc', label: '설명', type: 'textarea', rows: 6 },
        { key: 'link', label: '링크', type: 'url' },
      ]}
    />
  )
}
