import React from 'react'

export default function UsersManage() {
  const [q, setQ] = React.useState('')
  const rows = Array.from({ length: 12 }).map((_, i) => ({ id: i + 1, email: `user${i+1}@example.com`, role: i===0 ? 'admin' : 'user', created_at: '어제' }))

  return (
    <div className="space-y-3">
      <h2 className="text-base font-semibold">유저 관리</h2>
      <div className="flex items-center gap-2">
        <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="이메일 검색" className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
        <button className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">검색</button>
      </div>
      <div className="overflow-x-auto -mx-2">
        <table className="min-w-full text-sm mx-2">
          <thead>
            <tr className="text-left text-gray-400">
              <th className="py-2">ID</th>
              <th>이메일</th>
              <th>권한</th>
              <th>가입일</th>
              <th className="text-right">관리</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((u) => (
              <tr key={u.id} className="border-t border-white/10">
                <td className="py-2">{u.id}</td>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>{u.created_at}</td>
                <td className="text-right space-x-2">
                  <button className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">권한 변경</button>
                  <button className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 text-rose-300">정지</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

