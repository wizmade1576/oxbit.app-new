import React from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import { useAuthStore } from '../store/useAuthStore'
import { supabase } from '../services/supabase'

export default function AdminGuard({ children }) {
  const { user, isAdmin: flagAdmin, init } = useAuthStore()
  const [loading, setLoading] = React.useState(true)
  const [ok, setOk] = React.useState(false)
  const isDev = typeof import.meta !== 'undefined' && !!import.meta.env?.DEV
  const envBypass = String(import.meta?.env?.VITE_ADMIN_NO_LOGIN || '') === '1'

  React.useEffect(() => {
    (async () => {
      try {
        if (!user) {
          try { await init() } catch {}
        }
        let allowed = false
        let reason = 'unknown'
        const u = user || (await supabase.auth.getUser())?.data?.user
        if (u && (flagAdmin || u?.app_metadata?.claims?.admin)) {
          allowed = true
          reason = 'app_metadata.admin'
        } else if (u) {
          try {
            const { data } = await supabase.from('profiles').select('role').eq('id', u.id).maybeSingle()
            allowed = (data?.role || '').toLowerCase() === 'admin'
            reason = allowed ? 'profiles.role=admin' : 'profiles.role!=admin'
          } catch {}
        }
        // Dev/local bypass
        if (!allowed && (isDev || envBypass)) {
          if (envBypass || localStorage.getItem('ADMIN_BYPASS') === '1') {
            allowed = true
            reason = 'DEV_BYPASS'
          }
        }
        if (!allowed && isDev) {
          // eslint-disable-next-line no-console
          console.warn('[AdminGuard] blocked:', { reason })
        }
        setOk(!!allowed)
      } finally {
        setLoading(false)
      }
    })()
  }, [user, flagAdmin, init])

  if (loading) return <div className="p-6 text-sm text-gray-400">������ ���� Ȯ�� �ߡ�</div>
  if (!ok) return <Navigate to="/login?next=/admin" replace />
  return children ? <>{children}</> : <Outlet />
}


