export const breakingMock = Array.from({ length: 8 }).map((_, i) => ({
  id: i + 1,
  title: `속보 샘플 ${i + 1}`,
  body: '시장 변동성 확대 관련 테스트 본문',
  created_at: new Date(Date.now() - i * 3600e3).toISOString(),
  // 중요 여부와 공개 상태(공개/비공개) 추가
  important: i === 0 || i === 3, // 일부만 강조
  status: i % 2 === 0 ? 'public' : 'private',
}))
