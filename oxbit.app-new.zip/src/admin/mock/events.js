export const eventsMock = Array.from({ length: 8 }).map((_, i) => ({
  id: i + 1,
  title: `이벤트 ${i + 1}`,
  date: new Date(Date.now() + i * 86400e3).toISOString().slice(0, 10),
  link: '#',
  status: i % 2 === 0 ? 'public' : 'private',
}))
