export const adsMock = Array.from({ length: 6 }).map((_, i) => ({
  id: i + 1,
  title: `광고 배너 ${i + 1}`,
  link: '#',
  active: i % 2 === 0,
}))

