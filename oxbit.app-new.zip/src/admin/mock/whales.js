export const whalesMock = Array.from({ length: 8 }).map((_, i) => ({
  id: i + 1,
  feed: `거래소${(i % 3) + 1}`,
  note: '대규모 이체 감지',
  enabled: i % 2 === 0,
}))

