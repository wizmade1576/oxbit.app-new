export const usersMock = Array.from({ length: 12 }).map((_, i) => ({
  id: i + 1,
  email: `user${i + 1}@example.com`,
  nickname: `유저${i + 1}`,
  role: i === 0 ? 'admin' : 'user',
}))

