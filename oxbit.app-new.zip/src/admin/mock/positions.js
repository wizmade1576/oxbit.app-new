export const positionsMock = Array.from({ length: 9 }).map((_, i) => ({
  id: i + 1,
  name: `지표 ${i + 1}`,
  type: i % 2 === 0 ? 'lsr' : 'fr',
  active: i % 3 !== 0,
}))

