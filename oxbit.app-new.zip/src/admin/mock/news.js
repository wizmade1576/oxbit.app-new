export const newsMock = Array.from({ length: 10 }).map((_, i) => ({
  id: i + 1,
  title: `뉴스 샘플 ${i + 1}`,
  summary: '요약 문장 예시입니다.',
  source: 'CoinPress',
  created_at: new Date(Date.now() - i * 7200e3).toISOString(),
  status: i % 3 === 0 ? 'private' : 'public',
}))
