export const communityMock = Array.from({ length: 10 }).map((_, i) => ({
  id: i + 1,
  title: `커뮤니티 글 ${i + 1}`,
  author: `작성자${i + 1}`,
  category: i % 2 === 0 ? '이슈' : '자유',
  status: i % 4 === 0 ? 'private' : 'public',
}))
