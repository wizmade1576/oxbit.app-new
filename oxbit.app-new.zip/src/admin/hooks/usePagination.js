// Simple pagination state hook
import { useMemo, useState } from 'react'

export default function usePagination({ total = 0, pageSize = 10, initialPage = 1 } = {}) {
  const [page, setPage] = useState(initialPage)
  const totalPages = useMemo(() => Math.max(1, Math.ceil(total / pageSize)), [total, pageSize])
  const prev = () => setPage((p) => Math.max(1, p - 1))
  const next = () => setPage((p) => Math.min(totalPages, p + 1))
  return { page, setPage, totalPages, prev, next }
}

