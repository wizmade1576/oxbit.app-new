// Drawer state hook (delegates to context)
import { useLayout } from '../layout/LayoutContext.jsx'

export default function useDrawer() {
  const { drawerOpen, setDrawerOpen } = useLayout()
  return { drawerOpen, setDrawerOpen }
}

