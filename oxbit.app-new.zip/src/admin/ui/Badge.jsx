// Small status badge
import React from 'react'

export default function Badge({ children, color='gray' }) {
  const map = {
    gray: 'bg-white/10 text-gray-200 border-white/15',
    green: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
    red: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
    blue: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
    yellow: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  }
  return (
    <span className={`inline-flex px-2 py-0.5 rounded border text-xs ${map[color] || map.gray}`}>{children}</span>
  )
}

