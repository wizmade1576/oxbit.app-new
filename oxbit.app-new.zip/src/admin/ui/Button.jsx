// Reusable Button component
// variants: primary | outline | ghost | danger
// sizes: sm | md
import React from 'react'

export default function Button({ as:Comp='button', variant='primary', size='md', className='', disabled, ...props }) {
  const base = 'inline-flex items-center justify-center rounded-md transition-colors focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed'
  const sizes = size === 'sm' ? 'px-2.5 py-1.5 text-xs' : 'px-3 py-2 text-sm'
  const styles =
    variant === 'primary' ? 'bg-[#2366ff] text-white hover:bg-[#1f57dd]'
    : variant === 'outline' ? 'border border-white/10 text-gray-200 hover:bg-white/10'
    : variant === 'danger' ? 'bg-rose-600 text-white hover:bg-rose-700'
    : 'text-gray-200 hover:text-white'
  return <Comp className={`${base} ${sizes} ${styles} ${className}`} disabled={disabled} {...props} />
}
