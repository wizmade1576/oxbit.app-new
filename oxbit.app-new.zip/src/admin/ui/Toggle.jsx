// Toggle switch
import React from 'react'

export default function Toggle({ checked, onChange, label }) {
  return (
    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
      <span className={`w-10 h-6 rounded-full p-0.5 transition-colors ${checked ? 'bg-emerald-500/70' : 'bg-white/10'}`}>
        <span className={`block h-5 w-5 bg-white rounded-full transition-transform ${checked ? 'translate-x-4' : ''}`} />
      </span>
      {label && <span className="text-sm text-gray-300">{label}</span>}
      <input type="checkbox" className="hidden" checked={checked} onChange={(e)=>onChange?.(e.target.checked)} />
    </label>
  )
}

