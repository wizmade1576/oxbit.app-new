// Empty state placeholder
import React from 'react'

export default function EmptyState({ title='데이터가 없습니다', desc='등록 후 이곳에 표시됩니다.' }) {
  return (
    <div className="py-12 text-center">
      <div className="text-sm font-medium text-gray-200">{title}</div>
      <div className="mt-1 text-xs text-gray-400">{desc}</div>
    </div>
  )
}

