// Error state placeholder
import React from 'react'

export default function ErrorState({ title='오류가 발생했습니다', desc='다시 시도해 주세요.', actionLabel='새로고침', onAction }) {
  return (
    <div className="py-12 text-center space-y-3">
      <div className="text-sm font-semibold text-rose-300">{title}</div>
      <div className="text-xs text-gray-400">{desc}</div>
      {onAction && (
        <button onClick={onAction} className="mt-2 inline-flex px-3 py-1.5 rounded border border-white/10 text-xs text-gray-200 hover:bg-white/10">{actionLabel}</button>
      )}
    </div>
  )
}

