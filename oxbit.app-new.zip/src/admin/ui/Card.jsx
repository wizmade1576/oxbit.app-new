// Simple card container with optional header
import React from 'react'

export default function Card({ title, desc, children, className='' }) {
  return (
    <section className={`rounded-xl border border-white/10 bg-[#13161A] ${className}`}>
      {(title || desc) && (
        <div className="px-4 py-3 border-b border-white/10 backdrop-blur bg-white/5">
          {title && <h3 className="text-sm font-semibold text-white">{title}</h3>}
          {desc && <p className="mt-0.5 text-xs text-gray-400">{desc}</p>}
        </div>
      )}
      <div className="p-4">
        {children}
      </div>
    </section>
  )
}
