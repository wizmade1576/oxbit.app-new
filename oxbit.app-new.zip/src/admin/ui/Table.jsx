// Table with sticky header, zebra rows, hover highlight
// - Provides both X/Y scroll inside a rounded/bordered shell
// - Sticky header pins to the scroll container (not the viewport)
import React from 'react'

export function Table({ children, className='', scrollY=true }) {
  return (
    <div className="rounded-xl border border-white/10">
      <div className={`overflow-auto ${scrollY ? 'max-h-[60vh]' : ''}`}>
        <table className={`min-w-full text-sm ${className}`}>{children}</table>
      </div>
    </div>
  )
}
// Stick to the top of the scroll container
export function THead({ children }) { return <thead className="bg-[#13161A] text-gray-300 sticky top-0 z-20 shadow-sm">{children}</thead> }
export function TR({ children, className='' }) { return <tr className={`divide-x divide-white/10 hover:bg-[#262626]/50 transition-colors ${className}`}>{children}</tr> }
export function TH({ children, className='' }) { return <th className={`px-3 py-2 text-left font-medium ${className}`}>{children}</th> }
export function TD({ children, className='' }) { return <td className={`px-3 py-2 text-[13px] leading-5 ${className}`}>{children}</td> }
export function TBody({ children }) { return <tbody className="divide-y divide-white/10 [&>tr:nth-child(odd)]:bg-white/0 [&>tr:nth-child(even)]:bg-white/[0.02]">{children}</tbody> }
