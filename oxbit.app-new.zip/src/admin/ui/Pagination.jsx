// Pagination with first/prev/next/last controls
import React from 'react'
import Button from './Button.jsx'

const Icon = ({ name }) => {
  const base = 'w-4 h-4'
  switch (name) {
    case 'first':
      return <svg viewBox="0 0 24 24" className={base} fill="none"><path d="M18 6l-6 6 6 6M6 6v12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
    case 'prev':
      return <svg viewBox="0 0 24 24" className={base} fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
    case 'next':
      return <svg viewBox="0 0 24 24" className={base} fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
    case 'last':
      return <svg viewBox="0 0 24 24" className={base} fill="none"><path d="M6 6l6 6-6 6M18 6v12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
    default:
      return null
  }
}

export default function Pagination({ page, totalPages, onPrev, onNext, onFirst, onLast }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <div className="text-gray-400">{page} / {totalPages}</div>
      <div className="flex items-center gap-1.5">
        <Button variant="outline" size="sm" aria-label="처음" onClick={onFirst || (()=>{})} disabled={page <= 1}><Icon name="first" /></Button>
        <Button variant="outline" size="sm" aria-label="이전" onClick={onPrev} disabled={page <= 1}><Icon name="prev" /></Button>
        <Button variant="outline" size="sm" aria-label="다음" onClick={onNext} disabled={page >= totalPages}><Icon name="next" /></Button>
        <Button variant="outline" size="sm" aria-label="마지막" onClick={onLast || (()=>{})} disabled={page >= totalPages}><Icon name="last" /></Button>
      </div>
    </div>
  )
}
