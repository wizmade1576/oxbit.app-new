// Very small toast system for Admin UI
import React, { createContext, useCallback, useContext, useMemo, useState } from 'react'

const ToastCtx = createContext(null)

export function ToastProvider({ children }) {
  const [list, setList] = useState([])
  const dismiss = useCallback((id) => setList((a) => a.filter((t) => t.id !== id)), [])
  const push = useCallback((msg, opts = {}) => {
    const id = Math.random().toString(36).slice(2)
    const item = { id, msg, type: opts.type || 'info', ttl: opts.ttl ?? 3000 }
    setList((a) => [...a, item])
    setTimeout(() => dismiss(id), item.ttl)
    return id
  }, [dismiss])
  const success = useCallback((msg, opts={}) => push(msg, { ...opts, type: 'success' }), [push])
  const error = useCallback((msg, opts={}) => push(msg, { ...opts, type: 'error' }), [push])
  const loading = useCallback((msg, opts={}) => push(msg, { ...opts, type: 'loading', ttl: opts.ttl ?? 3000 }), [push])
  const value = useMemo(() => ({ push, success, error, loading, dismiss }), [push, success, error, loading, dismiss])
  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div className="fixed top-4 right-4 z-[1100] space-y-2">
        {list.map((t) => (
          <div key={t.id} className={`min-w-[220px] max-w-sm px-3 py-2 rounded border text-sm shadow-lg backdrop-blur flex items-center gap-2 ${
            t.type === 'success' ? 'bg-emerald-500/15 text-emerald-200 border-emerald-500/30' :
            t.type === 'error' ? 'bg-rose-500/15 text-rose-200 border-rose-500/30' :
            t.type === 'loading' ? 'bg-white/10 text-gray-200 border-white/15' :
            'bg-white/10 text-gray-200 border-white/15'
          }`}>
            {t.type === 'success' && (<svg viewBox="0 0 24 24" className="w-4 h-4" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>)}
            {t.type === 'error' && (<svg viewBox="0 0 24 24" className="w-4 h-4" fill="none"><path d="M6 6l12 12M18 6l-12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>)}
            {t.type === 'loading' && (<svg className="animate-spin w-4 h-4" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path></svg>)}
            <span className="leading-5">{t.msg}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastCtx)
  if (!ctx) throw new Error('useToast must be used within ToastProvider')
  return ctx
}
