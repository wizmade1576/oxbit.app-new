// Admin UI Modal with overlay fade-in
import React, { useEffect } from 'react'

export default function Modal({ open, title, onClose, onSubmit, children }) {
  useEffect(() => {
    if (!open) return
    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.()
      if (e.key === 'Enter') onSubmit?.()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose, onSubmit])

  if (!open) return null
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl rounded-xl border border-white/10 bg-[#13161A] p-5 shadow-2xl">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-semibold text-gray-100">{title}</h3>
          <button onClick={onClose} className="text-sm text-gray-300 hover:text-white" aria-label="닫기">닫기</button>
        </div>
        <div className="prose prose-invert max-w-none text-sm text-gray-300">{children}</div>
      </div>
    </div>
  )
}
