// SimpleSelect: dark-themed custom select (no native popup)
// props: value, onChange, options (array of string or {label,value}), className
import React, { useEffect, useRef, useState } from 'react'

function toOpt(o){ return typeof o === 'string' ? { label: o, value: o } : o }

export default function SimpleSelect({ value, onChange, options = [], className = '' }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  const list = options.map(toOpt)
  const current = list.find(o => o.value === value) || list[0]

  useEffect(() => {
    const handler = (e) => { if (!ref.current?.contains(e.target)) setOpen(false) }
    window.addEventListener('click', handler)
    return () => window.removeEventListener('click', handler)
  }, [])

  return (
    <div className={`relative ${className}`} ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(v => !v)}
        className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm text-gray-400 flex items-center justify-between"
      >
        <span className="truncate">{current?.label}</span>
        <svg viewBox="0 0 24 24" className={`w-4 h-4 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`} fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full rounded-md border border-white/10 bg-[#0F1114] shadow-lg overflow-hidden">
          <ul className="max-h-60 overflow-auto py-1">
            {list.map((o) => (
              <li key={o.value}>
                <button
                  type="button"
                  onClick={() => { onChange?.(o.value); setOpen(false) }}
                  className={`w-full text-left px-3 py-2 text-sm ${o.value===value ? 'bg-white/10 text-gray-200' : 'text-gray-300 hover:bg-white/5'}`}
                >
                  {o.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

