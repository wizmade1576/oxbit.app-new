// Text input and Search input with label + error helpers
import React from 'react'

export function Input({ className='', ...props }) {
  return <input className={`w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm ${className}`} {...props} />
}

export function SearchInput({ placeholder='검색', value, onChange, className='' }) {
  return (
    <div className={`relative ${className}`}>
      <input
        value={value}
        onChange={(e)=>onChange?.(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-white/5 border border-white/10 rounded pl-9 pr-3 py-2 text-sm"
      />
      <div className="absolute inset-y-0 left-2 flex items-center text-gray-400">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M21 21l-4.3-4.3M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15z" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
      </div>
    </div>
  )
}

export function LabeledInput({ label, error, hint, ...props }) {
  return (
    <div className="space-y-1">
      {label && <label className="text-xs text-gray-300">{label}</label>}
      <Input {...props} className={error ? 'border-rose-500/40 bg-rose-500/5' : undefined} />
      {hint && !error && <p className="text-xs text-gray-500">{hint}</p>}
      {error && <p className="text-xs text-rose-400">{error}</p>}
    </div>
  )
}
