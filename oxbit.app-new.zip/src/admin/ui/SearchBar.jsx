// Search bar with placeholder + debounce + typing spinner
import React, { useEffect, useRef, useState } from 'react'
import { SearchInput } from './Input.jsx'

export default function SearchBar({ value, onChange, placeholder='검색어를 입력하세요', debounceMs=300 }) {
  const [text, setText] = useState(value || '')
  const [typing, setTyping] = useState(false)
  const tRef = useRef(null)

  useEffect(() => { setText(value || '') }, [value])

  useEffect(() => {
    if (!onChange) return
    setTyping(true)
    clearTimeout(tRef.current)
    tRef.current = setTimeout(() => { onChange(text); setTyping(false) }, debounceMs)
    return () => clearTimeout(tRef.current)
  }, [text, onChange, debounceMs])

  return (
    <div className="relative">
      <SearchInput value={text} onChange={setText} placeholder={placeholder} />
      {typing && (
        <div className="absolute inset-y-0 right-2 flex items-center">
          <svg className="animate-spin h-4 w-4 text-gray-400" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path></svg>
        </div>
      )}
    </div>
  )
}
