import React from 'react'
import AdminTabsNav from './AdminTabsNav.jsx'
import Modal from '../../components/Modal.jsx'
import { listItems, upsertItem, removeItem } from '../lib/adminLocal.js'
import { canUseSupabase, listTable, upsertTable, deleteFromTable } from '../../supabase/adminCrud.js'

export default function CrudScaffold({ title, resourceKey, columns, fields, searchKeys = ['title','body'], pageSize = 20, table, pk = 'id' }) {
  const [q, setQ] = React.useState('')
  const [page, setPage] = React.useState(1)
  const [{ items, total }, setData] = React.useState({ items: [], total: 0 })
  const [open, setOpen] = React.useState(false)
  const [form, setForm] = React.useState(Object.fromEntries(fields.map(f => [f.key, f.default ?? (f.type==='checkbox'?false:'')])))
  const [editId, setEditId] = React.useState(null)

  const [useSb] = React.useState(() => canUseSupabase() && !!table)

  const load = React.useCallback(async () => {
    if (useSb) {
      try {
        const { rows, total } = await listTable(table, { q, page, pageSize, qColumns: searchKeys })
        setData({ items: rows, total })
        return
      } catch (e) {
        // fallback to local on failure
      }
    }
    setData(listItems(resourceKey, { q, page, pageSize, searchKeys }))
  }, [useSb, table, resourceKey, q, page, pageSize, searchKeys])

  React.useEffect(() => { load() }, [load])

  const onSave = async () => {
    const row = { ...form, [pk]: editId }
    if (useSb) {
      try { await upsertTable(table, row, pk); } catch (e) { /* noop; let fallback also write locally */ }
    }
    upsertItem(resourceKey, { ...row, id: row[pk] })
    setOpen(false); setForm(Object.fromEntries(fields.map(f => [f.key, f.default ?? (f.type==='checkbox'?false:'')]))); setEditId(null); load()
  }

  const onDelete = async (id) => {
    if (!confirm('삭제하시겠습니까?')) return
    if (useSb) { try { await deleteFromTable(table, id, pk) } catch (e) {} }
    removeItem(resourceKey, id); load()
  }

  const totalPages = Math.max(1, Math.ceil(total / pageSize))

  return (
    <section className="ox-container mx-auto py-6 space-y-6">
      <h1 className="text-xl font-semibold text-white">관리자 · {title}</h1>
      <AdminTabsNav />

      <div className="flex flex-wrap items-center gap-2">
        <input value={q} onChange={(e)=>{ setQ(e.target.value); setPage(1) }} placeholder={`${title} 검색`} className="px-3 py-2 bg-white/5 border border-white/10 rounded text-sm w-64" />
        <button onClick={()=>{ setEditId(null); setForm(Object.fromEntries(fields.map(f => [f.key, f.default ?? (f.type==='checkbox'?false:'')]))); setOpen(true) }} className="ml-auto px-3 py-2 bg-[#1D6FEA] text-white rounded text-sm">추가</button>
      </div>

      <div className="rounded-xl border border-white/10 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-black/30 text-gray-300">
            <tr className="divide-x divide-white/10">
              <th className="px-3 py-2 text-left w-14">ID</th>
              {columns.map((c) => (
                <th key={c.key} className={`px-3 py-2 text-left ${c.thClass||''}`}>{c.label}</th>
              ))}
              <th className="px-3 py-2 text-center w-32">작업</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {items.map((it) => (
              <tr key={it.id} className="divide-x divide-white/5">
                <td className="px-3 py-2">{it.id}</td>
                {columns.map((c) => (
                  <td key={c.key} className="px-3 py-2 text-gray-300">{String(it[c.key] ?? '')}</td>
                ))}
                <td className="px-3 py-2 text-center space-x-2">
                  <button className="px-2 py-1 text-xs border border-white/15 rounded hover:bg-white/10" onClick={()=>{ setEditId(it.id); setForm(Object.fromEntries(fields.map(f => [f.key, it[f.key] ?? (f.type==='checkbox'?false:'')]))); setOpen(true) }}>수정</button>
                  <button className="px-2 py-1 text-xs border border-rose-500/30 text-rose-300 rounded hover:bg-rose-500/10" onClick={()=>onDelete(it.id)}>삭제</button>
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={columns.length + 2} className="px-3 py-8 text-center text-gray-400">데이터가 없습니다.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-sm">
        <div className="text-gray-400">총 {total}건</div>
        <div className="flex items-center gap-2">
          <button disabled={page<=1} onClick={()=>setPage(p=>Math.max(1,p-1))} className="px-2 py-1 rounded border border-white/10 disabled:opacity-40">이전</button>
          <span className="text-gray-300">{page} / {totalPages}</span>
          <button disabled={page>=totalPages} onClick={()=>setPage(p=>Math.min(totalPages,p+1))} className="px-2 py-1 rounded border border-white/10 disabled:opacity-40">다음</button>
        </div>
      </div>

      <Modal open={open} title={editId ? `${title} 수정` : `${title} 추가`} onClose={()=>setOpen(false)}>
        <div className="space-y-3">
          {fields.map((f) => (
            <div key={f.key} className="space-y-1">
              <label className="text-xs text-gray-400">{f.label}</label>
              {f.type === 'textarea' ? (
                <textarea rows={f.rows || 6} value={form[f.key] ?? ''} onChange={(e)=>setForm(s=>({ ...s, [f.key]: e.target.value }))} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded text-sm" />
              ) : f.type === 'checkbox' ? (
                <div className="flex items-center gap-2">
                  <input type="checkbox" checked={!!form[f.key]} onChange={(e)=>setForm(s=>({ ...s, [f.key]: e.target.checked }))} />
                  <span className="text-sm text-gray-300">{f.checkLabel || f.label}</span>
                </div>
              ) : (
                <input type={f.type || 'text'} value={form[f.key] ?? ''} onChange={(e)=>setForm(s=>({ ...s, [f.key]: e.target.value }))} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded text-sm" />
              )}
            </div>
          ))}
          <div className="flex items-center justify-end gap-2">
            <button onClick={()=>setOpen(false)} className="px-3 py-2 text-sm border border-white/10 rounded">취소</button>
            <button onClick={onSave} className="px-3 py-2 text-sm bg-[#1D6FEA] text-white rounded">저장</button>
          </div>
        </div>
      </Modal>
    </section>
  )
}
