import React, { useMemo, useState } from 'react'

export default function AdminPositionForm({ onSubmit, symbol, onSymbolChange, rate = 1350, symbols: symbolsProp }) {
  const [form, setForm] = useState({
    nick: '',
    imageUrl: '',
    symbol: symbol || 'BTCUSDT',
    side: 'Long',
    lev: 10,
    qty: '',
    entry: '',
    mark: '',
    pnlPct: '',
    pnlKrw: '',
    status: '수익',
  })

  // keep external symbol in sync
  React.useEffect(() => {
    setForm((s) => ({ ...s, symbol: symbol || s.symbol }))
  }, [symbol])

  // 기본 심볼 목록 (필요 시 props로 덮어쓰기)
  const defaultSymbols = [
    'BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','BNBUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','OPUSDT','ARBUSDT','SUIUSDT','APTUSDT','LINKUSDT','MATICUSDT','TONUSDT'
  ]
  const symbols = Array.isArray(symbolsProp) && symbolsProp.length ? symbolsProp : defaultSymbols
  const isCustomSymbol = useMemo(() => !symbols.includes(form.symbol), [symbols, form.symbol])

  const handle = (k) => (e) => {
    const v = e?.target?.value
    setForm((s) => ({ ...s, [k]: v }))
  }

  const computedPnlKrw = useMemo(() => {
    const pct = parseFloat(form.pnlPct) || 0
    const entry = parseFloat(form.entry) || 0
    const qty = parseFloat(form.qty) || 0
    if (!pct || !entry || !qty) return ''
    const val = Math.round((pct / 100) * entry * qty * rate)
    return Number.isFinite(val) ? val.toLocaleString() : ''
  }, [form.pnlPct, form.entry, form.qty, rate])

  const submit = (e) => {
    e.preventDefault()
    const payload = {
      nick: form.nick.trim(),
      imageUrl: form.imageUrl.trim(),
      symbol: form.symbol,
      side: form.side,
      lev: form.lev,
      qty: form.qty,
      entry: form.entry,
      mark: form.mark,
      pnlPct: form.pnlPct,
      pnlKrw: form.pnlKrw || computedPnlKrw,
      status: form.status,
    }
    if (!payload.nick || !payload.symbol) return
    onSubmit && onSubmit(payload)
    setForm((s) => ({ ...s, qty: '', entry: '', mark: '', pnlPct: '', pnlKrw: '' }))
  }

  return (
    <form onSubmit={submit} className="grid gap-3 md:grid-cols-2">
      <div className="space-y-1">
        <label className="text-xs text-gray-300">BJ 이름</label>
        <input value={form.nick} onChange={handle('nick')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
      </div>
      <div className="space-y-1">
        <label className="text-xs text-gray-300">프로필 이미지 URL(선택)</label>
        <input value={form.imageUrl} onChange={handle('imageUrl')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
      </div>

      <div className="space-y-1">
        <label className="text-xs text-gray-300">종목(심볼)</label>
        <div className="grid grid-cols-2 gap-3">
          <select
            value={isCustomSymbol ? 'custom' : form.symbol}
            onChange={(e)=>{
              const v = e.target.value
              if (v === 'custom') return // keep custom input focused
              setForm((s)=> ({ ...s, symbol: v }))
              onSymbolChange && onSymbolChange(v)
            }}
            className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm"
          >
            {symbols.map((sym)=> (
              <option key={sym} value={sym}>{sym}</option>
            ))}
            <option value="custom">직접 입력</option>
          </select>
          <input
            value={form.symbol}
            onChange={(e)=>{ handle('symbol')(e); onSymbolChange && onSymbolChange(e.target.value) }}
            placeholder="예: BTCUSDT"
            className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <label className="text-xs text-gray-300">포지션</label>
          <select value={form.side} onChange={handle('side')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm">
            <option>Long</option>
            <option>Short</option>
          </select>
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-300">레버리지(배)</label>
          <input type="number" min={2} max={100} value={form.lev} onChange={(e)=> setForm((s)=> ({ ...s, lev: Number(e.target.value||0) }))} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1">
          <label className="text-xs text-gray-300">수량</label>
          <input value={form.qty} onChange={handle('qty')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-300">진입가</label>
          <input value={form.entry} onChange={handle('entry')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-300">현재가</label>
          <input value={form.mark} onChange={handle('mark')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 md:col-span-2">
        <div className="space-y-1">
          <label className="text-xs text-gray-300">PnL %</label>
          <input value={form.pnlPct} onChange={handle('pnlPct')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-300">PnL(원화)</label>
          <input value={form.pnlKrw} onChange={handle('pnlKrw')} placeholder={computedPnlKrw || ''} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-gray-300">상태</label>
          <select value={form.status} onChange={handle('status')} className="w-full rounded border border-white/10 bg-white/5 px-3 py-2 text-sm">
            <option>수익</option>
            <option>손실</option>
          </select>
        </div>
      </div>

      <div className="md:col-span-2 flex items-center justify-end gap-2 pt-2">
        <button type="button" onClick={()=> setForm((s)=> ({ ...s, qty:'', entry:'', mark:'', pnlPct:'', pnlKrw:'' }))} className="rounded border border-white/10 bg-white/5 px-3 py-2 text-sm hover:bg-white/10">초기화</button>
        <button type="submit" className="rounded bg-[#1D6FEA] px-4 py-2 text-sm text-white hover:brightness-110">추가</button>
      </div>
    </form>
  )
}
