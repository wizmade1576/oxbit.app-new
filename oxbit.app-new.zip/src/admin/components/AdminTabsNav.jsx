import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'

const tabs = [
  { to: '/admin/dashboard', label: '대시보드' },
  { to: '/admin/breaking', label: '속보' },
  { to: '/admin/news', label: '뉴스' },
  { to: '/admin/events', label: '이벤트' },
  { to: '/admin/positions', label: '포지션' },
  { to: '/admin/whales', label: '고래' },
  { to: '/admin/community', label: '커뮤니티' },
  { to: '/admin/ads', label: '광고' },
  { to: '/admin/users', label: '사용자' },
  { to: '/admin/settings', label: '설정' },
]

export default function AdminTabsNav() {
  const { pathname } = useLocation()
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      {tabs.map((t) => (
        <NavLink
          key={t.to}
          to={t.to}
          className={({ isActive }) =>
            `px-3 py-1.5 rounded text-xs border ${
              isActive || pathname.startsWith(t.to)
                ? 'bg-white/10 text-white border-white/20'
                : 'text-gray-300 border-white/10 hover:bg-white/5'
            }`
          }
        >
          {t.label}
        </NavLink>
      ))}
    </div>
  )
}

