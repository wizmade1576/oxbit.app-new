// TradingView widget wrapper with script auto-loader
// - Loads https://s3.tradingview.com/tv.js once
// - Re-renders widget when symbol/height changes
import React, { useEffect, useMemo, useRef, useState } from 'react'

function loadTV() {
  if (typeof window === 'undefined') return Promise.reject()
  if (window.TradingView && window.TradingView.widget) return Promise.resolve()
  if (window.__tvScriptPromise) return window.__tvScriptPromise
  window.__tvScriptPromise = new Promise((resolve, reject) => {
    const s = document.createElement('script')
    s.src = 'https://s3.tradingview.com/tv.js'
    s.async = true
    s.onload = () => resolve()
    s.onerror = reject
    document.head.appendChild(s)
  })
  return window.__tvScriptPromise
}

export default function TradingViewWidget({ symbol = 'BTCUSDT', height = 360 }) {
  const containerId = useMemo(() => `tv_${Math.random().toString(36).slice(2)}`, [])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let cancelled = false
    const mount = async () => {
      try {
        await loadTV()
        if (cancelled) return
        if (window.TradingView && window.TradingView.widget) {
          // Clean previous instance (if any)
          const el = document.getElementById(containerId)
          if (el) el.innerHTML = ''
          new window.TradingView.widget({
            symbol,
            interval: '60',
            container_id: containerId,
            locale: 'kr',
            width: '100%',
            height,
            theme: 'dark',
            hide_top_toolbar: false,
            hide_legend: false,
          })
          setReady(true)
        }
      } catch (_) {
        setReady(false)
      }
    }
    mount()
    return () => { cancelled = true }
  }, [symbol, height, containerId])

  return (
    <div className="rounded-xl border border-white/10 overflow-hidden">
      <div id={containerId} style={{ minHeight: height }} />
      {!ready && (
        <div className="h-[360px] sm:h-[420px] md:h-[480px] flex items-center justify-center bg-[#0F1114] text-gray-400">
          TradingView 차트를 불러오는 중... ({symbol})
        </div>
      )}
    </div>
  )
}
