import React from 'react'
import { NavLink, Outlet } from 'react-router-dom'

const nav = [
  { to: '/admin/dashboard', label: '대시보드' },
  { to: '/admin/posts', label: '게시글 관리' },
  { to: '/admin/reports', label: '신고 관리' },
  { to: '/admin/ads', label: '광고 관리' },
  { to: '/admin/announcements', label: '공지/이벤트' },
  { to: '/admin/users', label: '유저 관리' },
]

export default function AdminLayout() {
  return (
    <div className="min-h-[70vh] grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-4">
      {/* Sidebar */}
      <aside className="hidden lg:block rounded-xl border border-white/10 bg-[#13161A] p-4">
        <div className="mb-3 text-sm font-semibold text-gray-200">관리자</div>
        <nav className="space-y-1">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) => `block px-3 py-2 rounded text-sm ${isActive ? 'bg-white/10 text-white' : 'text-gray-300 hover:bg-white/5'}`}
            >
              {n.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* Main */}
      <section className="space-y-4">
        {/* Top nav for mobile */}
        <div className="lg:hidden rounded-xl border border-white/10 bg-[#13161A] p-3 flex gap-2 flex-wrap">
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} className={({ isActive }) => `px-3 py-1.5 rounded text-xs border ${isActive ? 'bg-white/10 text-white border-white/20' : 'text-gray-300 border-white/10'}`}>{n.label}</NavLink>
          ))}
        </div>
        <div className="rounded-xl border border-white/10 bg-[#13161A] p-4">
          <Outlet />
        </div>
      </section>
    </div>
  )
}

