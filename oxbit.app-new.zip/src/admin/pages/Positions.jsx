import React, { useMemo, useState } from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import Button from '../ui/Button.jsx'
import SearchBar from '../ui/SearchBar.jsx'
import { Table, THead, TR, TH, TBody, TD } from '../ui/Table.jsx'
import Pagination from '../ui/Pagination.jsx'
import EmptyState from '../ui/EmptyState.jsx'
import Modal from '../ui/Modal.jsx'
import useModal from '../hooks/useModal.js'
import usePagination from '../hooks/usePagination.js'
import { positionsMock } from '../mock/positions.js'
import LoadingSkeleton from '../ui/LoadingSkeleton.jsx'
import Badge from '../ui/Badge.jsx'
import Toggle from '../ui/Toggle.jsx'
import { LabeledInput } from '../ui/Input.jsx'
import { useToast } from '../ui/ToastProvider.jsx'

export default function Positions() {
  const toast = useToast()
  const [q, setQ] = useState('')
  const modal = useModal(false)
  const { page, totalPages, prev, next } = usePagination({ total: 5, pageSize: 10 })
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name:'', type:'lsr', active:true })

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase()
    const src = positionsMock
    return term ? src.filter((r) => (r.name || '').toLowerCase().includes(term)) : src
  }, [q])

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <h1 className="text-xl font-semibold text-white">포지션</h1>
        <div className="ml-auto w-full sm:w-64"><SearchBar value={q} onChange={setQ} placeholder="포지션 검색" /></div>
        <Button variant="outline" onClick={()=>{ setLoading(true); setTimeout(()=>setLoading(false), 800) }}>새로고침</Button>
        <Button onClick={()=>{ setForm({ name:'', type:'lsr', active:true }); modal.onOpen() }}>등록</Button>
      </div>

      <Card>
        {loading ? (
          <LoadingSkeleton rows={6} />
        ) : rows.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <Table>
              <THead><TR><TH className="w-14">ID</TH><TH>지표명</TH><TH className="w-24">종류</TH><TH className="w-20">활성</TH></TR></THead>
              <TBody>
                {rows.map((r)=> (
                  <TR key={r.id}>
                    <TD>{r.id}</TD>
                    <TD className="text-gray-200">{r.name}</TD>
                    <TD className="text-gray-400">{r.type}</TD>
                    <TD>{r.active ? <Badge color="green">ON</Badge> : <Badge color="red">OFF</Badge>}</TD>
                  </TR>
                ))}
              </TBody>
            </Table>
            <div className="mt-3"><Pagination page={page} totalPages={totalPages} onPrev={prev} onNext={next} /></div>
          </>
        )}
      </Card>

      <Modal open={modal.open} title="포지션 등록" onClose={modal.onClose}>
        <div className="space-y-3">
          <LabeledInput label="지표명" value={form.name} onChange={(e)=>setForm(s=>({...s, name:e.target.value}))} />
          <LabeledInput label="종류(lsr, fr 등)" value={form.type} onChange={(e)=>setForm(s=>({...s, type:e.target.value}))} />
          <div className="pt-1"><Toggle checked={form.active} onChange={(v)=>setForm(s=>({...s, active:v}))} label="활성화" /></div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={modal.onClose}>취소</Button><Button onClick={()=>{ modal.onClose(); toast.push('포지션이 임시로 저장되었습니다', { type:'success' }) }}>저장</Button></div>
        </div>
      </Modal>
    </AdminLayout>
  )
}
