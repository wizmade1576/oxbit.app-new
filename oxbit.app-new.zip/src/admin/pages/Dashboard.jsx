// Admin Dashboard page sample
import React, { useMemo, useState } from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import Button from '../ui/Button.jsx'
import SearchBar from '../ui/SearchBar.jsx'
import { Table, THead, TR, TH, TBody, TD } from '../ui/Table.jsx'
import Pagination from '../ui/Pagination.jsx'
import EmptyState from '../ui/EmptyState.jsx'
import LoadingSkeleton from '../ui/LoadingSkeleton.jsx'
import Modal from '../ui/Modal.jsx'
import useModal from '../hooks/useModal.js'
import usePagination from '../hooks/usePagination.js'
import { breakingMock } from '../mock/breaking.js'

export default function Dashboard() {
  // State
  const [q, setQ] = useState('')
  const [loading] = useState(false)
  const { page, setPage, totalPages, prev, next } = usePagination({ total: 20, pageSize: 10 })
  const modal = useModal(false)

  // Filtered mock rows
  const rows = useMemo(() => {
    const term = q.trim().toLowerCase()
    const src = breakingMock
    return term ? src.filter((r) => (r.title || '').toLowerCase().includes(term)) : src
  }, [q])

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-xl font-semibold text-white">대시보드</h1>
          <div className="ml-auto w-full sm:w-64">
            <SearchBar value={q} onChange={setQ} placeholder="검색어를 입력하세요" />
          </div>
          <Button onClick={modal.onOpen}>등록</Button>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { k: '속보', v: 128 },
            { k: '뉴스', v: 432 },
            { k: '이벤트', v: 16 },
            { k: '사용자', v: 2450 },
          ].map((it) => (
            <Card key={it.k}>
              <div className="text-xs text-gray-400">{it.k}</div>
              <div className="mt-1 text-2xl font-bold text-white">{it.v.toLocaleString()}</div>
            </Card>
          ))}
        </div>

        {/* Table */}
        <Card title="최근 등록" desc="목데이터 (연동 전)">
          {loading ? (
            <LoadingSkeleton rows={6} />
          ) : rows.length === 0 ? (
            <EmptyState />
          ) : (
            <>
              <Table>
                <THead>
                  <TR>
                    <TH className="w-14">ID</TH>
                    <TH>제목</TH>
                    <TH className="w-40">등록일</TH>
                    <TH className="w-28 text-center">작업</TH>
                  </TR>
                </THead>
                <TBody>
                  {rows.slice(0, 8).map((r) => (
                    <TR key={r.id}>
                      <TD>{r.id}</TD>
                      <TD className="text-gray-200">{r.title}</TD>
                      <TD className="text-gray-400">{new Date(r.created_at).toLocaleString()}</TD>
                      <TD className="text-center">
                        <Button variant="outline" className="px-2 py-1 text-xs">수정</Button>
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
              <div className="mt-3">
                <Pagination page={page} totalPages={totalPages} onPrev={prev} onNext={next} />
              </div>
            </>
          )}
        </Card>

        {/* Modal */}
        <Modal open={modal.open} title="등록" onClose={modal.onClose}>
          <div className="space-y-3">
            <p className="text-sm text-gray-300">여기에 등록 폼을 연결하세요.</p>
            <div className="flex justify-end">
              <Button variant="outline" onClick={modal.onClose}>닫기</Button>
            </div>
          </div>
        </Modal>
      </div>
    </AdminLayout>
  )
}

