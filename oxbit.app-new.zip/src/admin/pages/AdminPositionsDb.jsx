﻿import React from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import AdminPositionForm from '../components/AdminPositionForm.jsx'
import TradingViewWidget from '../components/TradingViewWidget.jsx'
import { supabase } from '../../services/supabase'
import Button from '../ui/Button.jsx'
import { useToast } from '../ui/ToastProvider.jsx'

export default function AdminPositionsDb() {
  const [rows, setRows] = React.useState([])
  const [loading, setLoading] = React.useState(false)
  const [chartSymbol, setChartSymbol] = React.useState('BTCUSDT')
  const toast = useToast()
  const [q, setQ] = React.useState('')
  const [sortBy, setSortBy] = React.useState('created_at')
  const [sortDir, setSortDir] = React.useState('desc')
  const [page, setPage] = React.useState(1)
  const pageSize = 20
  const [hasMore, setHasMore] = React.useState(false)

  const mapFromDb = (r) => ({
    id: r.id,
    nick: r.nick,
    imageUrl: r.image_url || '',
    symbol: r.symbol,
    side: r.side,
    lev: r.lev,
    qty: r.qty,
    entry: r.entry,
    mark: r.mark,
    pnlPct: r.pnl_pct,
    pnlKrw: r.pnl_krw,
    status: r.status,
    created_at: r.created_at,
  })

  const loadRows = async (opts = {}) => {
    setLoading(true)
    try {
      const term = (opts.q ?? q).trim()
      const sBy = opts.sortBy ?? sortBy
      const sAsc = (opts.sortDir ?? sortDir) === 'asc'
      const curPage = opts.page ?? page
      const from = (curPage - 1) * pageSize
      const to = from + pageSize - 1

      let query = supabase
        .from('positions')
        .select('*')

      if (term) {
        // 검색: 닉네임/심볼에 부분 일치
        query = query.or(`nick.ilike.%${term}%,symbol.ilike.%${term}%`)
      }

      query = query.order(sBy, { ascending: sAsc }).range(from, to)

      const { data, error } = await query
      if (error) throw error
      const rowsData = data || []
      setRows(rowsData.map(mapFromDb))
      setHasMore(rowsData.length === pageSize)
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }

  React.useEffect(() => { loadRows({ page: 1 }) }, [])

  const addRow = async (payload) => {
    try {
      if (!payload?.nick?.trim()) { toast.error('닉네임을 입력해 주세요'); return }
      if (!payload?.symbol) { toast.error('심볼을 선택해 주세요'); return }
      if (!payload?.side) { toast.error('포지션을 선택해 주세요'); return }
      const toInt = (v) => {
        if (v == null) return null
        const s = String(v).replace(/x$/i, '')
        const n = parseInt(s, 10)
        return Number.isFinite(n) ? n : null
      }
      const toNum = (v) => {
        const n = parseFloat(String(v))
        return Number.isFinite(n) ? n : null
      }
      const db = {
        nick: payload.nick,
        image_url: payload.imageUrl || null,
        symbol: payload.symbol,
        side: payload.side,
        lev: toInt(payload.lev),
        qty: toNum(payload.qty),
        entry: toNum(payload.entry),
        mark: toNum(payload.mark),
        pnl_pct: toNum(payload.pnlPct),
        pnl_krw: toNum(payload.pnlKrw),
        status: payload.status || null,
      }
      const { data, error } = await supabase.from('positions').insert(db).select().single()
      if (error) throw error
      setRows((a) => [mapFromDb(data), ...a])
      if (payload?.symbol) setChartSymbol(String(payload.symbol))
      toast.success('포지션을 저장했습니다')
    } catch (e) { console.error(e) }
  }

  const removeRow = async (id) => {
    if (!id) return
    if (!confirm('정말 삭제하시겠습니까?')) return
    try {
      const { error } = await supabase.from('positions').delete().eq('id', id)
      if (error) throw error
      setRows((a) => a.filter((r) => r.id !== id))
      toast.success('삭제되었습니다')
    } catch (e) { console.error(e); toast.error(e?.message || '삭제 실패') }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <Card title="차트">
          <TradingViewWidget symbol={chartSymbol} height={420} />
        </Card>

        <Card title="포지션 입력" desc="관리자 수동 입력 (DB 저장)">
          <AdminPositionForm
            onSubmit={addRow}
            symbol={chartSymbol}
            onSymbolChange={setChartSymbol}
          />
        </Card>

        <Card title="최근 포지션">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <input
              value={q}
              onChange={(e)=>setQ(e.target.value)}
              placeholder="닉네임/심볼 검색"
              className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm flex-1 min-w-[200px]"
            />
            <select
              value={`${sortBy}:${sortDir}`}
              onChange={(e)=>{ const [f,d]=e.target.value.split(':'); setSortBy(f); setSortDir(d) }}
              className="bg-white/5 border border-white/10 rounded px-2 py-2 text-sm"
            >
              <option value="created_at:desc">최신순</option>
              <option value="created_at:asc">오래된순</option>
              <option value="symbol:asc">심볼↑</option>
              <option value="symbol:desc">심볼↓</option>
            </select>
            <Button variant="outline" size="sm" onClick={()=>{ setPage(1); loadRows({ q, sortBy, sortDir, page:1 }) }}>검색</Button>
            <Button variant="outline" size="sm" onClick={()=>loadRows({})}>새로고침</Button>
          </div>
          <div className="mb-2 flex items-center justify-between">
            <div className="text-xs text-gray-400">총 {rows.length}건</div>
            <div className="space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={()=>{ const p=Math.max(1, page-1); setPage(p); loadRows({ page:p }) }}
                disabled={page<=1}
              >이전</Button>
              <Button
                variant="outline"
                size="sm"
                onClick={()=>{ const p=page+1; setPage(p); loadRows({ page:p }) }}
                disabled={!hasMore}
              >다음</Button>
            </div>
          </div>
          {loading ? (
            <div className="text-sm text-gray-400">불러오는 중…</div>
          ) : rows.length === 0 ? (
            <div className="text-sm text-gray-400">데이터가 없습니다.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-400">
                    <th className="py-2 px-2">ID</th>
                    <th className="px-2">닉네임</th>
                    <th className="px-2">심볼</th>
                    <th className="px-2">포지션</th>
                    <th className="px-2 text-right">레버리지</th>
                    <th className="px-2 text-right">수량</th>
                    <th className="px-2 text-right">진입</th>
                    <th className="px-2 text-right">현재가</th>
                    <th className="px-2 text-right">PnL%</th>
                    <th className="px-2 text-right">PnL(₩)</th>
                    <th className="px-2">상태</th>
                    <th className="px-2">시간</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr
                      key={r.id}
                      className="border-t border-white/10 hover:bg-white/5 cursor-pointer"
                      onClick={() => setChartSymbol(String(r.symbol || 'BTCUSDT'))}
                      title="행을 클릭하면 위 차트 심볼이 변경됩니다"
                    >
                      <td className="py-2 px-2">{r.id}</td>
                      <td className="px-2">{r.nick}</td>
                      <td className="px-2">{r.symbol}</td>
                      <td className="px-2">{r.side}</td>
                      <td className="px-2 text-right">{r.lev || '-'}</td>
                      <td className="px-2 text-right">{isFinite(r.qty) ? r.qty : '-'}</td>
                      <td className="px-2 text-right">{isFinite(r.entry) ? r.entry : '-'}</td>
                      <td className="px-2 text-right">{isFinite(r.mark) ? r.mark : '-'}</td>
                      <td className="px-2 text-right">{isFinite(r.pnlPct) ? `${r.pnlPct}%` : '-'}</td>
                      <td className="px-2 text-right">{isFinite(r.pnlKrw) ? r.pnlKrw.toLocaleString() : '-'}</td>
                      <td className="px-2">{r.status || '-'}</td>
                      <td className="px-2">{r.created_at ? new Date(r.created_at).toLocaleString() : '-'}</td>
                      <td className="px-2 text-right">
                        <Button variant="outline" size="xs" onClick={(e)=>{ e.stopPropagation(); removeRow(r.id) }}>삭제</Button>
                      </td>
                    </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        </Card>
      </div>
    </AdminLayout>
  )
}
