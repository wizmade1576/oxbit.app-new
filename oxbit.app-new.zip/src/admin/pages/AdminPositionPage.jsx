import React, { useCallback, useMemo, useState, useEffect } from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import TradingViewWidget from '../components/TradingViewWidget.jsx'
import AdminPositionForm from '../components/AdminPositionForm.jsx'
import { Table, THead, TR, TH, TBody, TD } from '../ui/Table.jsx'
import Badge from '../ui/Badge.jsx'
import Button from '../ui/Button.jsx'
import { useToast } from '../ui/ToastProvider.jsx'
import Toggle from '../ui/Toggle.jsx'
import { fetchUsdKrwRate } from '../../services/kimpService.js'
import { fetchUsdtSymbols, defaultSymbols } from '../../services/symbolService.js'
import { supabase } from '../../services/supabase'

export default function AdminPositionPage() {
  const [rows, setRows] = useState([])
  const [chartSymbol, setChartSymbol] = useState('BTCUSDT')
  const toast = useToast()
  const [rate, setRate] = useState(1350)
  const [fixRate, setFixRate] = useState(true)
  const [groupView, setGroupView] = useState(true)
  const [collapsed, setCollapsed] = useState({})
  const [bjFilter, setBjFilter] = useState([])
  const [symbols, setSymbols] = useState(() => (typeof defaultSymbols === 'function' ? defaultSymbols() : ['BTCUSDT']))

  const mapFromDb = (r) => ({
    id: r.id,
    nick: r.nick,
    imageUrl: r.image_url || '',
    symbol: r.symbol,
    side: r.side,
    lev: r.lev ? `${r.lev}x` : '',
    qty: r.qty,
    entry: r.entry,
    mark: r.mark,
    pnlPct: r.pnl_pct,
    pnlKrw: r.pnl_krw,
    rateSnapshot: r.rate_snapshot,
    status: r.status,
    created_at: r.created_at,
  })

  const loadRows = async () => {
    try {
      const { data, error } = await supabase
        .from('positions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200)
      if (error) throw error
      setRows((data || []).map(mapFromDb))
    } catch (e) {
      console.error(e)
    }
  }

  useEffect(() => { loadRows() }, [])

  useEffect(() => { refreshRate() }, [])

  // Load tradable USDT symbols
  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const list = await fetchUsdtSymbols()
        if (!active) return
        if (Array.isArray(list) && list.length) setSymbols(list)
      } catch {}
    })()
    return () => { active = false }
  }, [])

  const refreshRate = async () => {
    try {
      const r = await fetchUsdKrwRate()
      if (isFinite(r) && r > 0) setRate(Math.round(r))
    } catch {}
  }

  const addRow = useCallback(
    (payload) => {
      const id = rows.length + 1
      const item = {
        id,
        nick: payload.nick,
        imageUrl: payload.imageUrl || '',
        symbol: payload.symbol,
        side: payload.side,
        lev: payload.lev,
        qty: payload.qty,
        entry: payload.entry,
        mark: payload.mark,
        pnlPct: payload.pnlPct,
        pnlKrw: payload.pnlKrw,
        rateSnapshot: fixRate ? rate : undefined,
        status: payload.status,
      }
      setRows((a) => [item, ...a])
      toast.success('포지션이 추가되었습니다.')
    },
    [rows, fixRate, rate, toast]
  )

  const removeRow = (id) => setRows((a) => a.filter((r) => r.id !== id))

  const filteredRows = useMemo(() => {
    if (!bjFilter || bjFilter.length === 0) return rows
    return rows.filter((r) => bjFilter.includes(r.nick))
  }, [rows, bjFilter])

  return (
    <AdminLayout>
      <div className="space-y-6">
        <Card title="실시간 차트">
          <TradingViewWidget symbol={chartSymbol} height={420} />
        </Card>

        <Card title="포지션 입력" desc="스트리머 포지션 수동 입력">
          <div className="flex items-center justify-between mb-3 text-sm">
            <div className="flex items-center gap-3">
              <span className="text-gray-400">USDKRW</span>
              <span className="px-2 py-1 rounded border border-white/10 bg-white/5 text-gray-200">
                {rate.toLocaleString()}
              </span>
              <Button variant="outline" size="sm" onClick={refreshRate}>
                환율 새로고침
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Toggle checked={fixRate} onChange={setFixRate} label="환율 고정" />
            </div>
          </div>
          <AdminPositionForm
            onSubmit={addRow}
            symbol={chartSymbol}
            onSymbolChange={setChartSymbol}
            rate={rate}
            symbols={symbols}
          />
        </Card>

        <Card title="포지션 목록" desc="Mock 데이터 미연동">
          <div className="flex items-center justify-between mb-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-gray-400">BJ 필터</span>
              <button
                type="button"
                onClick={() => setBjFilter([])}
                className={(bjFilter.length === 0 ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-300') + ' px-2 py-1 rounded text-xs border border-white/10 hover:bg-white/10'}
              >
                전체
              </button>
              {Array.from(new Set(rows.map((r) => r.nick))).map((nick) => (
                <button
                  key={nick}
                  type="button"
                  onClick={() =>
                    setBjFilter((prev) =>
                      prev.includes(nick) ? prev.filter((x) => x !== nick) : [...prev, nick]
                    )
                  }
                  className={(bjFilter.includes(nick) ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-300') + ' px-2 py-1 rounded text-xs border border-white/10 hover:bg-white/10'}
                >
                  {nick}
                </button>
              ))}
            </div>
            <Toggle checked={groupView} onChange={setGroupView} label="BJ 그룹보기" />
          </div>

          {!groupView && (
            <Table>
              <THead>
                <TR>
                  <TH className="w-14">ID</TH>
                  <TH>닉네임</TH>
                  <TH className="w-28">종목 / 방향 / 레버리지</TH>
                  <TH className="w-24">수량</TH>
                  <TH className="w-28">진입가</TH>
                  <TH className="w-28">현재가</TH>
                  <TH className="w-24">PnL%</TH>
                  <TH className="w-28">PnL(원)</TH>
                  <TH className="w-24">상태</TH>
                  <TH className="w-20 text-center">삭제</TH>
                </TR>
              </THead>
              <TBody>
                {filteredRows.map((r) => (
                  <TR key={r.id}>
                    <TD>{r.id}</TD>
                    <TD>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center text-[10px] text-gray-400">
                          {r.imageUrl ? (
                            <img src={r.imageUrl} alt={r.nick} className="w-full h-full object-cover" />
                          ) : (
                            r.nick?.slice(0, 2) || 'NA'
                          )}
                        </div>
                        <span className="text-gray-200">{r.nick}</span>
                      </div>
                    </TD>
                    <TD className="text-gray-300">{r.symbol} · {r.side} · {r.lev}</TD>
                    <TD className="text-gray-300">{r.qty}</TD>
                    <TD className="text-gray-300">{r.entry}</TD>
                    <TD className="text-gray-300">{r.mark}</TD>
                    <TD className="text-gray-200">{r.pnlPct}</TD>
                    <TD className="text-gray-200">{r.pnlKrw}</TD>
                    <TD><Badge color={r.status === '수익' ? 'green' : 'red'}>{r.status}</Badge></TD>
                    <TD className="text-center">
                      <Button variant="danger" size="sm" onClick={() => removeRow(r.id)}>삭제</Button>
                    </TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          )}

        </Card>
      </div>
    </AdminLayout>
  )
}
