import React, { useState } from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import Toggle from '../ui/Toggle.jsx'
import { supabase } from '../../services/supabase'

export default function Settings() {
  const [bypass, setBypass] = useState(localStorage.getItem('ADMIN_BYPASS') === '1')
  return (
    <AdminLayout>
      <div className="space-y-6">
        <h1 className="text-xl font-semibold text-white">설정</h1>
        <Card title="개발 세션" desc="로컬 개발 용의 설정">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-white">가짜 로그인 허용</div>
              <div className="text-xs text-gray-400">브라우저 LocalStorage의 ADMIN_BYPASS 토글</div>
            </div>
            <Toggle
              checked={bypass}
              onChange={(v)=>{ setBypass(v); if(v) localStorage.setItem('ADMIN_BYPASS','1'); else localStorage.removeItem('ADMIN_BYPASS') }}
            />
          </div>
        </Card>

        <RoleManagerCard />
      </div>
    </AdminLayout>
  )
}

function RoleManagerCard() {
  const [email, setEmail] = useState('')
  const [role, setRole] = useState('admin')
  const [loading, setLoading] = useState(false)
  const [msg, setMsg] = useState('')

  const submit = async (e) => {
    e?.preventDefault?.()
    setMsg(''); setLoading(true)
    try {
      const { data: session } = await supabase.auth.getSession()
      const token = session?.session?.access_token
      if (!token) throw new Error('로그인이 필요합니다')
      const r = await fetch('/api/admin-set-role', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ email, role }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(j?.error || '요청 실패')
      setMsg('권한이 업데이트되었습니다')
    } catch (e) {
      setMsg(String(e?.message || e))
    } finally { setLoading(false) }
  }

  return (
    <Card title="권한 관리" desc="이메일 기준으로 admin/user 전환">
      <form onSubmit={submit} className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-end">
        <div className="flex-1">
          <div className="text-xs text-gray-300 mb-1">이메일</div>
          <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required placeholder="user@example.com" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
        </div>
        <div>
          <div className="text-xs text-gray-300 mb-1">역할</div>
          <select value={role} onChange={(e)=>setRole(e.target.value)} className="bg-white/5 border border-white/10 rounded px-3 py-2 text-sm">
            <option value="admin">admin</option>
            <option value="user">user</option>
          </select>
        </div>
        <button disabled={loading} className="px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">{loading ? '처리 중…' : '권한 변경'}</button>
      </form>
      {msg && <div className="mt-2 text-xs text-gray-300">{msg}</div>}
    </Card>
  )
}

