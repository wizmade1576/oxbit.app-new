﻿import React, { useEffect, useMemo, useState } from 'react'
import { listBreaking, subscribeBreaking, createBreaking, updateBreaking, deleteBreaking } from '../../services/breakingService'

function useToaster() {
  const [toasts, setToasts] = useState([])
  function push(message, tone = 'info') {
    const id = Math.random().toString(36).slice(2)
    setToasts((arr) => [...arr, { id, message, tone }])
    setTimeout(() => setToasts((arr) => arr.filter((t) => t.id !== id)), 2500)
  }
  const view = (
    <div className="pointer-events-none fixed right-4 top-4 z-50 space-y-2">
      {toasts.map((t) => (
        <div key={t.id} className={`pointer-events-auto rounded px-3 py-2 text-sm shadow ${t.tone==='error'?'bg-red-500/20 text-red-200':'bg-zinc-800 text-zinc-100'}`}>{t.message}</div>
      ))}
    </div>
  )
  return { push, view }
}

export default function AdminBreakingPage() {
  const { push, view } = useToaster()
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // filters
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('all')
  const [importantOnly, setImportantOnly] = useState(false)

  // form
  const [form, setForm] = useState({ title: '', body: '', status: 'public', important: false, image_url: '' })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    let active = true
    async function load() {
      try {
        setLoading(true)
        const data = await listBreaking({ limit: 200 })
        if (!active) return
        setItems(Array.isArray(data) ? data : [])
      } catch (e) {
        if (!active) return
        setError(e?.message || '濡쒕뵫 ?ㅻ쪟媛 諛쒖깮?덉뒿?덈떎.')
      } finally {
        if (active) setLoading(false)
      }
    }
    load()
    const unsub = subscribeBreaking((payload) => {
      const rec = payload?.new || payload?.record || payload
      if (!rec) return
      setItems((prev) => {
        const exists = prev.some((p) => p.id === rec.id)
        const next = exists ? prev.map((p) => (p.id === rec.id ? rec : p)) : [rec, ...prev]
        return next.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      })
    })
    return () => { active = false; try { unsub?.() } catch {} }
  }, [])

  const filtered = useMemo(() => {
    let data = items
    if (status !== 'all') data = data.filter((it) => (status === 'public' ? it.status === 'public' : it.status !== 'public'))
    if (importantOnly) data = data.filter((it) => !!it.important)
    if (q.trim()) {
      const s = q.trim().toLowerCase()
      data = data.filter((it) => (it.title||'').toLowerCase().includes(s) || (it.body||'').toLowerCase().includes(s))
    }
    return data
  }, [items, status, importantOnly, q])

  async function handleSave(e) {
    e?.preventDefault()
    if (!form.title.trim()) { push('?쒕ぉ???낅젰?섏꽭??, 'error'); return }
    setSaving(true)
    try {
      await createBreaking({
        title: form.title.trim(),
        body: form.body || '',
        status: form.status || 'public',
        important: !!form.important,
        image_url: form.image_url || null,
      })
      setForm({ title: '', body: '', status: 'public', important: false, image_url: '' })
      push('??λ릺?덉뒿?덈떎')
    } catch (e) {
      push(e?.message || '????ㅽ뙣', 'error')
    } finally {
      setSaving(false)
    }
  }

  async function handleToggleStatus(row) {
    try {
      const next = row.status === 'public' ? 'private' : 'public'
      await updateBreaking(row.id, { status: next })
      push('?곹깭媛 蹂寃쎈릺?덉뒿?덈떎')
    } catch (e) {
      push(e?.message || '蹂寃??ㅽ뙣', 'error')
    }
  }

  async function handleDelete(row) {
    if (!confirm('?뺣쭚 ??젣?섏떆寃좎뒿?덇퉴?')) return
    try {
      await deleteBreaking(row.id)
      push('??젣?섏뿀?듬땲??)
    } catch (e) {
      push(e?.message || '??젣 ?ㅽ뙣', 'error')
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      {view}
      <header className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold">?띾낫 愿由?/h1>
      </header>

      <section className="grid gap-6 lg:grid-cols-[1.2fr_2fr]">
        {/* Write form */}
        <form onSubmit={handleSave} className="space-y-3 rounded-lg border border-zinc-800 bg-zinc-900 p-4">
          <div>
            <label className="mb-1 block text-sm text-zinc-300">?쒕ぉ</label>
            <input value={form.title} onChange={(e)=>setForm((f)=>({...f,title:e.target.value}))} className="w-full rounded border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-zinc-500" placeholder="?쒕ぉ" />
          </div>
          <div>
            <label className="mb-1 block text-sm text-zinc-300">蹂몃Ц</label>
            <textarea value={form.body} onChange={(e)=>setForm((f)=>({...f,body:e.target.value}))} rows={6} className="w-full resize-y rounded border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-zinc-500" placeholder="?댁슜" />
          </div>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm text-zinc-300">
              <input type="checkbox" checked={form.important} onChange={(e)=>setForm((f)=>({...f,important:e.target.checked}))} /> 以묒슂
            </label>
            <select value={form.status} onChange={(e)=>setForm((f)=>({...f,status:e.target.value}))} className="rounded border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm">
              <option value="public">怨듦컻</option>
              <option value="private">鍮꾧났媛?/option>
            </select>
          </div>
          <div>
            <label className="mb-1 block text-sm text-zinc-300">?대?吏 URL(?좏깮)</label>
            <input value={form.image_url} onChange={(e)=>setForm((f)=>({...f,image_url:e.target.value}))} className="w-full rounded border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-zinc-500" placeholder="https://..." />
          </div>
          <div className="flex items-center justify-end gap-2">
            <button type="button" onClick={()=>setForm({ title:'', body:'', status:'public', important:false, image_url:'' })} className="rounded bg-white/5 px-3 py-2 text-sm hover:bg-white/10">珥덇린??/button>
            <button disabled={saving} className="rounded bg-white/10 px-3 py-2 text-sm hover:bg-white/20 disabled:opacity-60">{saving?'???以묅?:'???}</button>
          </div>
        </form>

        {/* List + filters */}
        <section className="rounded-lg border border-zinc-800 bg-zinc-900">
          <div className="flex flex-wrap items-center gap-3 border-b border-zinc-800 p-3">
            <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="寃???쒕ぉ/蹂몃Ц)" className="w-56 rounded border border-zinc-700 bg-zinc-950 px-3 py-1.5 text-sm outline-none focus:border-zinc-500" />
            <select value={status} onChange={(e)=>setStatus(e.target.value)} className="rounded border border-zinc-700 bg-zinc-950 px-3 py-1.5 text-sm">
              <option value="all">?꾩껜</option>
              <option value="public">怨듦컻</option>
              <option value="private">鍮꾧났媛?/option>
            </select>
            <label className="flex items-center gap-2 text-sm text-zinc-300">
              <input type="checkbox" checked={importantOnly} onChange={(e)=>setImportantOnly(e.target.checked)} /> 以묒슂留?            </label>
            <div className="ml-auto text-xs text-zinc-400">?쒖떆 {filtered.length}嫄?/div>
          </div>
          {loading ? (
            <p className="p-4">遺덈윭?ㅻ뒗 以묅?/p>
          ) : error ? (
            <p className="p-4 text-red-400">{error}</p>
          ) : filtered.length === 0 ? (
            <p className="p-4 text-zinc-400">?쒖떆???곗씠?곌? ?놁뒿?덈떎.</p>
          ) : (
            <ul className="divide-y divide-zinc-800">
              {filtered.map((it) => (
                <li key={it.id} className="flex items-start gap-3 p-3 hover:bg-white/5">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{it.title}</span>
                      {it.important ? <span className="rounded bg-red-500/20 px-1.5 py-0.5 text-[10px] text-red-200">以묒슂</span> : null}
                      <span className="text-xs text-zinc-500">{it.created_at ? new Date(it.created_at).toLocaleString() : ''}</span>
                    </div>
                    {it.body ? <p className="mt-1 line-clamp-2 text-xs text-zinc-400">{it.body}</p> : null}
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <button onClick={()=>handleToggleStatus(it)} className="rounded bg-white/10 px-2 py-1 text-xs hover:bg-white/20">{it.status==='public'?'鍮꾧났媛쒕줈':'怨듦컻濡?}</button>
                    <button onClick={()=>handleDelete(it)} className="rounded bg-red-500/20 px-2 py-1 text-xs text-red-200 hover:bg-red-500/30">??젣</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </section>
    </div>
  )
}


