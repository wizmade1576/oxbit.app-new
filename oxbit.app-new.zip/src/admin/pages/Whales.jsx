import React, { useMemo, useState } from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import Button from '../ui/Button.jsx'
import SearchBar from '../ui/SearchBar.jsx'
import { Table, THead, TR, TH, TBody, TD } from '../ui/Table.jsx'
import Pagination from '../ui/Pagination.jsx'
import EmptyState from '../ui/EmptyState.jsx'
import Modal from '../ui/Modal.jsx'
import useModal from '../hooks/useModal.js'
import usePagination from '../hooks/usePagination.js'
import { whalesMock } from '../mock/whales.js'
import LoadingSkeleton from '../ui/LoadingSkeleton.jsx'
import Badge from '../ui/Badge.jsx'
import Toggle from '../ui/Toggle.jsx'
import { LabeledInput } from '../ui/Input.jsx'
import { useToast } from '../ui/ToastProvider.jsx'

export default function Whales() {
  const toast = useToast()
  const [q, setQ] = useState('')
  const modal = useModal(false)
  const { page, totalPages, prev, next } = usePagination({ total: 3, pageSize: 10 })
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ feed:'', note:'', enabled:true })

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase()
    const src = whalesMock
    return term ? src.filter((r) => (r.feed || '').toLowerCase().includes(term)) : src
  }, [q])

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <h1 className="text-xl font-semibold text-white">고래</h1>
        <div className="ml-auto w-full sm:w-64"><SearchBar value={q} onChange={setQ} placeholder="고래 피드 검색" /></div>
        <Button variant="outline" onClick={()=>{ setLoading(true); setTimeout(()=>setLoading(false), 800) }}>새로고침</Button>
        <Button onClick={()=>{ setForm({ feed:'', note:'', enabled:true }); modal.onOpen() }}>등록</Button>
      </div>

      <Card>
        {loading ? (
          <LoadingSkeleton rows={6} />
        ) : rows.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <Table>
              <THead><TR><TH className="w-14">ID</TH><TH>피드</TH><TH>비고</TH><TH className="w-20">사용</TH></TR></THead>
              <TBody>
                {rows.map((r)=> (
                  <TR key={r.id}>
                    <TD>{r.id}</TD>
                    <TD className="text-gray-200">{r.feed}</TD>
                    <TD className="text-gray-300">{r.note}</TD>
                    <TD>{r.enabled ? <Badge color="green">ON</Badge> : <Badge color="red">OFF</Badge>}</TD>
                  </TR>
                ))}
              </TBody>
            </Table>
            <div className="mt-3"><Pagination page={page} totalPages={totalPages} onPrev={prev} onNext={next} /></div>
          </>
        )}
      </Card>

      <Modal open={modal.open} title="고래 피드 등록" onClose={modal.onClose}>
        <div className="space-y-3">
          <LabeledInput label="피드 이름" value={form.feed} onChange={(e)=>setForm(s=>({...s, feed:e.target.value}))} />
          <LabeledInput label="비고" value={form.note} onChange={(e)=>setForm(s=>({...s, note:e.target.value}))} />
          <div className="pt-1"><Toggle checked={form.enabled} onChange={(v)=>setForm(s=>({...s, enabled:v}))} label="사용" /></div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={modal.onClose}>취소</Button><Button onClick={()=>{ modal.onClose(); toast.push('고래 피드가 임시로 저장되었습니다', { type:'success' }) }}>저장</Button></div>
        </div>
      </Modal>
    </AdminLayout>
  )
}
