import React, { useMemo, useState } from 'react'
import AdminLayout from '../layout/AdminLayout.jsx'
import Card from '../ui/Card.jsx'
import Button from '../ui/Button.jsx'
import SearchBar from '../ui/SearchBar.jsx'
import { Table, THead, TR, TH, TBody, TD } from '../ui/Table.jsx'
import Pagination from '../ui/Pagination.jsx'
import EmptyState from '../ui/EmptyState.jsx'
import Modal from '../ui/Modal.jsx'
import useModal from '../hooks/useModal.js'
import usePagination from '../hooks/usePagination.js'
import { communityMock } from '../mock/community.js'
import LoadingSkeleton from '../ui/LoadingSkeleton.jsx'
import { LabeledInput } from '../ui/Input.jsx'
import { useToast } from '../ui/ToastProvider.jsx'
import Badge from '../ui/Badge.jsx'

export default function Community() {
  const toast = useToast()
  const [q, setQ] = useState('')
  const modal = useModal(false)
  const { page, totalPages, prev, next } = usePagination({ total: 5, pageSize: 10 })
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ title:'', author:'', category:'' })

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase()
    const src = communityMock
    return term ? src.filter((r) => (r.title || '').toLowerCase().includes(term)) : src
  }, [q])

  return (
    <AdminLayout>
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <h1 className="text-xl font-semibold text-white">커뮤니티</h1>
        <div className="ml-auto w-full sm:w-64"><SearchBar value={q} onChange={setQ} placeholder="커뮤니티 검색" /></div>
        <Button variant="outline" onClick={()=>{ setLoading(true); setTimeout(()=>setLoading(false), 800) }}>새로고침</Button>
        <Button onClick={()=>{ setForm({ title:'', author:'', category:'' }); modal.onOpen() }}>등록</Button>
      </div>

      <Card>
        {loading ? (
          <LoadingSkeleton rows={6} />
        ) : rows.length === 0 ? (
          <EmptyState />
        ) : (
          <>
            <Table>
              <THead><TR><TH className="w-14">ID</TH><TH>제목</TH><TH className="w-28">작성자</TH><TH className="w-28">카테고리</TH><TH className="w-24">상태</TH></TR></THead>
              <TBody>
                {rows.map((r)=> (
                  <TR key={r.id}>
                    <TD>{r.id}</TD>
                    <TD className="text-gray-200 underline-offset-2 hover:underline cursor-pointer">{r.title}</TD>
                    <TD className="text-gray-400">{r.author}</TD>
                    <TD className="text-gray-400">{r.category}</TD>
                    <TD><Badge color={r.status==='public'?'green':'gray'}>{r.status==='public'?'공개':'비공개'}</Badge></TD>
                  </TR>
                ))}
              </TBody>
            </Table>
            <div className="mt-3"><Pagination page={page} totalPages={totalPages} onPrev={prev} onNext={next} /></div>
          </>
        )}
      </Card>

      <Modal open={modal.open} title="커뮤니티 등록" onClose={modal.onClose}>
        <div className="space-y-3">
          <LabeledInput label="제목" value={form.title} onChange={(e)=>setForm(s=>({...s, title:e.target.value}))} />
          <LabeledInput label="작성자" value={form.author} onChange={(e)=>setForm(s=>({...s, author:e.target.value}))} />
          <LabeledInput label="카테고리" value={form.category} onChange={(e)=>setForm(s=>({...s, category:e.target.value}))} />
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={modal.onClose}>취소</Button><Button onClick={()=>{ modal.onClose(); toast.push('커뮤니티 글이 임시로 저장되었습니다', { type:'success' }) }}>저장</Button></div>
        </div>
      </Modal>
    </AdminLayout>
  )
}
