import React from 'react'
import Modal from '../components/Modal.jsx'

export default function AdsManage() {
  const [open, setOpen] = React.useState(false)
  const [editing, setEditing] = React.useState(null)
  const ads = Array.from({ length: 4 }).map((_, i) => ({ id: i + 1, slot: i % 2 ? 'home-top' : 'market-bottom', title: `배너 ${i + 1}`, active: i % 2 === 0 }))

  const edit = (a) => { setEditing(a); setOpen(true) }

  return (
    <div className="space-y-3">
      <h2 className="text-base font-semibold">광고 관리</h2>
      <div className="overflow-x-auto -mx-2">
        <table className="min-w-full text-sm mx-2">
          <thead>
            <tr className="text-left text-gray-400">
              <th className="py-2">ID</th>
              <th>슬롯</th>
              <th>제목</th>
              <th>상태</th>
              <th className="text-right">관리</th>
            </tr>
          </thead>
          <tbody>
            {ads.map((a) => (
              <tr key={a.id} className="border-t border-white/10">
                <td className="py-2">{a.id}</td>
                <td>{a.slot}</td>
                <td>{a.title}</td>
                <td>{a.active ? '노출' : '중지'}</td>
                <td className="text-right space-x-2">
                  <button onClick={()=>edit(a)} className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5">수정</button>
                  <button className="px-2 py-1 text-xs rounded border border-white/10 hover:bg-white/5 text-rose-300">삭제</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal open={open} onClose={()=>setOpen(false)} title="배너 수정">
        <div className="space-y-2">
          <label className="text-xs text-gray-300">제목</label>
          <input defaultValue={editing?.title} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
          <div className="pt-2 text-right">
            <button onClick={()=>setOpen(false)} className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">저장</button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

