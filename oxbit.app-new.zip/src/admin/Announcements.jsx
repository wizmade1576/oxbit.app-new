import React from 'react'

export default function Announcements() {
  const [title, setTitle] = React.useState('')
  const [body, setBody] = React.useState('')
  const [list, setList] = React.useState([])

  const submit = (e) => {
    e.preventDefault()
    setList((prev) => [{ id: Date.now(), title, body, at: '방금 전' }, ...prev])
    setTitle(''); setBody('')
  }

  return (
    <div className="space-y-4">
      <h2 className="text-base font-semibold">공지/이벤트</h2>
      <form onSubmit={submit} className="space-y-2">
        <input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="제목" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
        <textarea value={body} onChange={(e)=>setBody(e.target.value)} placeholder="내용" rows={5} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
        <div className="text-right">
          <button className="px-3 py-2 text-xs rounded border border-white/10 hover:bg-white/5">등록</button>
        </div>
      </form>
      <div className="space-y-2">
        {list.map((n) => (
          <div key={n.id} className="rounded-lg border border-white/10 bg-white/5 p-3">
            <div className="text-sm font-medium text-gray-100">{n.title}</div>
            <div className="text-xs text-gray-400">{n.at}</div>
            <div className="mt-1 text-sm text-gray-300 whitespace-pre-wrap">{n.body}</div>
          </div>
        ))}
        {list.length === 0 && <div className="text-sm text-gray-400">등록된 공지 없음</div>}
      </div>
    </div>
  )
}

