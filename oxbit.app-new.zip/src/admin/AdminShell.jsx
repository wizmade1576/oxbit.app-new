import React from 'react'
import { Outlet } from 'react-router-dom'
import { ToastProvider } from './ui/ToastProvider.jsx'

// AdminShell ensures Admin pages can use useToast at top-level
export default function AdminShell() {
  return (
    <ToastProvider>
      <Outlet />
    </ToastProvider>
  )
}

