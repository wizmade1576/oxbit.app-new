import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'

function Icon({ name, className = 'w-4 h-4' }) {
  const stroke = 'currentColor'
  switch (name) {
    case 'dashboard':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M3 13h8V3H3v10Zm10 8h8V3h-8v18ZM3 21h8v-6H3v6Z" stroke={stroke} strokeWidth="1.8"/></svg>
    case 'flash':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M13 2 3 14h7v8l11-14h-8l0-6Z" stroke={stroke} strokeWidth="1.8" strokeLinejoin="round"/></svg>
    case 'news':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M4 5h12M4 9h12M4 13h8M17 5h3v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5" stroke={stroke} strokeWidth="1.8" strokeLinecap="round"/></svg>
    case 'event':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M7 2v3M17 2v3M3 8h18M5 6h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" stroke={stroke} strokeWidth="1.8" strokeLinecap="round"/></svg>
    case 'positions':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M4 18l6-6 4 4 6-6" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
    case 'whales':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M3 12c2 3 6 5 9 5 6 0 9-4 9-7-2 1-4 1-6 0-2-1-3-3-3-5-2 2-3 4-3 6-1 0-3 0-6 1Z" stroke={stroke} strokeWidth="1.8" strokeLinecap="round"/></svg>
    case 'community':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M3 7a4 4 0 1 0 8 0 4 4 0 0 0-8 0Zm10 0h8M7 14c-3 0-5 2-5 4v2h10v-2c0-2-2-4-5-4Zm10 2a3 3 0 1 0 0-6" stroke={stroke} strokeWidth="1.8" strokeLinecap="round"/></svg>
    case 'ads':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M3 5h18v14H3zM6 9h6M6 13h10" stroke={stroke} strokeWidth="1.8" strokeLinecap="round"/></svg>
    case 'users':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M12 12a4 4 0 1 0-0.001-8.001A4 4 0 0 0 12 12ZM4 20a8 8 0 1 1 16 0v1H4v-1Z" stroke={stroke} strokeWidth="1.8"/></svg>
    case 'settings':
      return <svg viewBox="0 0 24 24" className={className} fill="none"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm8-3a8 8 0 0 1-.2 1.8l2 1.6-2 3.4-2.3-1a8 8 0 0 1-3.1 1.8l-.4 2.4h-4l-.4 2.4A8 8 0 0 1 6.3 19l-2.3 1-2-3.4 2-1.6A8 8 0 0 1 3 12c0-.6.07-1.2.2-1.8L1.2 8.6l2-3.4L5.5 6A8 8 0 0 1 8.6 4.2L9 1.8h4l.4 2.4A8 8 0 0 1 17.7 6l2.3-1 2 3.4-2 1.6c.13.58.2 1.19.2 1.8Z" stroke={stroke} strokeWidth="1.6"/></svg>
    default:
      return null
  }
}

const NAV = [
  { to: '/admin', label: '대시보드', icon: 'dashboard' },
  { to: '/admin/breaking', label: '속보', icon: 'flash' },
  { to: '/admin/news', label: '뉴스', icon: 'news' },
  { to: '/admin/events', label: '이벤트', icon: 'event' },
  { to: '/admin/positions', label: '포지션', icon: 'positions' },
  { to: '/admin/whales', label: '고래', icon: 'whales' },
  { to: '/admin/community', label: '커뮤니티', icon: 'community' },
  { to: '/admin/ads', label: '광고', icon: 'ads' },
  { to: '/admin/users', label: '사용자', icon: 'users' },
  { to: '/admin/logs', label: '로그', icon: 'news' },
  { to: '/admin/settings', label: '설정', icon: 'settings' },
]

export default function Sidebar({ onNavigate }) {
  const { pathname } = useLocation()
  return (
    <aside className="hidden md:flex md:flex-col w-64 shrink-0 h-screen sticky top-0 border-r border-white/10 bg-[#0F1114]">
      <div className="h-14 px-4 flex items-center border-b border-white/10">
        <span className="text-sm font-semibold text-white">관리자 패널</span>
      </div>
      <nav className="p-2 space-y-1 overflow-y-auto">
        {NAV.map((n) => {
          const isActive = pathname === n.to || (n.to !== '/admin' && pathname.startsWith(n.to))
          const disabled = n.disabled
          return (
            <NavLink
              key={n.to}
              to={disabled ? '#' : n.to}
              end={n.to === '/admin'}
              aria-current={isActive ? 'page' : undefined}
              onClick={disabled ? undefined : onNavigate}
              className={({ isActive: cur }) =>
                [
                  'group flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors',
                  disabled
                    ? 'opacity-40 cursor-not-allowed'
                    : (cur || isActive)
                    ? 'bg-white/10 text-white'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white',
                ].join(' ')
              }
            >
              <Icon name={n.icon} className="w-4 h-4 text-gray-300 group-hover:text-white" />
              <span className="truncate">{n.label}</span>
            </NavLink>
          )
        })}
      </nav>
      <div className="mt-auto p-3">
        <div className="px-3 py-2 rounded-md bg-white/5 border border-white/10 text-xs text-gray-300">
          상태: <span className="text-emerald-400">정상</span>
        </div>
      </div>
    </aside>
  )
}
