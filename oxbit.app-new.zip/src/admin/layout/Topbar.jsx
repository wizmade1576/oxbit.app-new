﻿// Topbar with dynamic title, mobile menu button, avatar placeholder, current time
import React from 'react'
import { useLocation } from 'react-router-dom'
import { useLayout } from './LayoutContext.jsx'

function usePageTitle() {
  const { pathname } = useLocation()
  if (pathname === '/admin' || pathname === '/admin/dashboard') return '대시보드'
  if (pathname.startsWith('/admin/news')) return '뉴스'
  if (pathname.startsWith('/admin/events')) return '이벤트'
  if (pathname.startsWith('/admin/community')) return '커뮤니티'
  if (pathname.startsWith('/admin/ads')) return '광고'
  if (pathname.startsWith('/admin/users')) return '사용자'
  return 'Admin Console'
}

function useClock() {
  const [now, setNow] = React.useState(() => new Date())
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  const hh = String(now.getHours()).padStart(2, '0')
  const mm = String(now.getMinutes()).padStart(2, '0')
  const ss = String(now.getSeconds()).padStart(2, '0')
  return `${hh}:${mm}:${ss}`
}

export default function Topbar() {
  const title = usePageTitle()
  const time = useClock()
  const { setDrawerOpen } = useLayout()

  return (
    <header className="h-14 sticky top-0 z-40 border-b border-white/10 bg-[#0F1114]/95 backdrop-blur">
      <div className="h-full px-3 md:px-6 flex items-center gap-3">
        <button
          className="md:hidden p-2 rounded hover:bg-white/10"
          onClick={() => setDrawerOpen(true)}
          aria-label="Open menu"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-gray-200">
            <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        <div className="text-sm font-semibold text-white truncate">{title}</div>

        <div className="ml-auto flex items-center gap-3">
          <span className="hidden sm:inline text-xs text-gray-400">{time}</span>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-[10px] text-gray-200">
              AD
            </div>
            <span className="hidden sm:inline text-xs text-gray-300">admin</span>
          </div>
        </div>
      </div>
    </header>
  )
}

