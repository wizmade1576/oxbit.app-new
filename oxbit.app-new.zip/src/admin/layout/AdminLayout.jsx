// AdminLayout: Sidebar + Topbar + Content + Mobile Drawer
import React from 'react'
import { LayoutProvider } from './LayoutContext.jsx'
import Sidebar from './Sidebar.jsx'
import Topbar from './Topbar.jsx'
import MobileDrawer from './MobileDrawer.jsx'
import { ToastProvider } from '../ui/ToastProvider.jsx'

export default function AdminLayout({ children }) {
  return (
    <LayoutProvider>
      <ToastProvider>
        <div className="admin-dark min-h-screen bg-[#0F1114] text-gray-200">
          <div className="md:flex">
            <Sidebar />
            <div className="flex-1 min-w-0">
              <Topbar />
              <main className="p-4 md:p-6 space-y-6">{children}</main>
            </div>
          </div>
          <MobileDrawer />
        </div>
      </ToastProvider>
    </LayoutProvider>
  )
}
