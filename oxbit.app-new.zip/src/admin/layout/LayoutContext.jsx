// Admin layout context: manages sidebar open state for mobile drawer
import React, { createContext, useContext, useMemo, useState } from 'react'

const LayoutCtx = createContext(null)

export function LayoutProvider({ children }) {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const value = useMemo(() => ({ drawerOpen, setDrawerOpen }), [drawerOpen])
  return <LayoutCtx.Provider value={value}>{children}</LayoutCtx.Provider>
}

export function useLayout() {
  const ctx = useContext(LayoutCtx)
  if (!ctx) throw new Error('useLayout must be used within LayoutProvider')
  return ctx
}

