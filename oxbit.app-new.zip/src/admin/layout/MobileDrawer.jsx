// Mobile drawer menu for small screens
import React from 'react'
import Sidebar from './Sidebar.jsx'
import { useLayout } from './LayoutContext.jsx'

export default function MobileDrawer() {
  const { drawerOpen, setDrawerOpen } = useLayout()
  return (
    <div className={`md:hidden fixed inset-0 z-50 ${drawerOpen ? '' : 'pointer-events-none'}`}>
      <div
        className={`absolute inset-0 bg-black/60 transition-opacity ${drawerOpen ? 'opacity-100' : 'opacity-0'}`}
        onClick={() => setDrawerOpen(false)}
      />
      <div
        className={`absolute top-0 left-0 h-full w-72 bg-[#0F1114] border-r border-white/10 transform transition-transform ${drawerOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <Sidebar onNavigate={() => setDrawerOpen(false)} />
      </div>
    </div>
  )
}

