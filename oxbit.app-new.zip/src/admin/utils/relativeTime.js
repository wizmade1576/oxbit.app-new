// relativeTime: returns a short Korean relative time like "방금 전", "10분 전", "3시간 전", "2일 전"
export function relativeTime(input) {
  try {
    const d = typeof input === 'string' ? new Date(input) : input
    const now = new Date()
    const diff = Math.max(0, now - d)
    const sec = Math.floor(diff / 1000)
    if (sec < 10) return '방금 전'
    if (sec < 60) return `${sec}초 전`
    const min = Math.floor(sec / 60)
    if (min < 60) return `${min}분 전`
    const hr = Math.floor(min / 60)
    if (hr < 24) return `${hr}시간 전`
    const day = Math.floor(hr / 24)
    if (day < 7) return `${day}일 전`
    const wk = Math.floor(day / 7)
    if (wk < 5) return `${wk}주 전`
    const mon = Math.floor(day / 30)
    if (mon < 12) return `${mon}개월 전`
    const yr = Math.floor(day / 365)
    return `${yr}년 전`
  } catch {
    return '-'
  }
}

