﻿import React from 'react'
import LoginPromoCard from './LoginPromoCard.jsx'
import PairsBoard from './PairsBoard.jsx'
import ManagedAd from './ManagedAd.jsx'
import SidebarSchedule from './Market/Schedule/SidebarSchedule.jsx'

function RightSidebar() {
  return (
    <aside
      className="hidden lg:block lg:sticky lg:top-20 w-full lg:w-[360px] max-h-[calc(100vh-8rem)] overflow-y-auto bg-transparent z-10 border-l border-black/5 dark:border-white/5 transform-gpu will-change-transform"
      style={{ backfaceVisibility: 'hidden' }}
    >
      <div className="flex flex-col gap-4 p-3">
        {/* 로그인 프로모션 카드 */}
        <LoginPromoCard className="backdrop-blur-md border border-black/10 dark:border-white/10 bg-white/70 dark:bg-[#14171c]/70" />

        {/* 실시간마켓 */}
        <PairsBoard limit={60} />
        <ManagedAd slot="market-bottom" className="mt-3" />
        <SidebarSchedule max={7} />
      </div>
    </aside>
  )
}

export default React.memo(RightSidebar)



