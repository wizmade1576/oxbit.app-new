import { useNavigate } from 'react-router-dom'

export default function Hero() {
  const navigate = useNavigate()
  const tags = ['BTC', 'ETH', 'SOL', 'XRP', '도지', '버츄얼']
  return (
    <section className="relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-[#0F1114] to-[#151922] p-6 sm:p-8">
      <div className="space-y-4">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">실시간 크립토 뉴스 · 속보</h1>
        <p className="text-gray-400 text-sm sm:text-base">시장에서 중요한 헤드라인과 속보를 한 곳에서 빠르게 확인하세요.</p>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => navigate('/breaking')} className="px-4 py-2 text-sm rounded-md bg-[#1D6FEA] text-white hover:opacity-95">속보 보러가기</button>
          <button onClick={() => navigate('/news')} className="px-4 py-2 text-sm rounded-md bg-white/10 text-gray-100 hover:bg-white/20">뉴스 보러가기</button>
        </div>
        <div className="flex flex-wrap gap-2 pt-2">
          {tags.map((t) => (
            <button key={t} onClick={() => navigate(`/news?q=${encodeURIComponent(t)}`)} className="text-xs rounded-full bg-white/10 px-2.5 py-1 hover:bg-white/20">
              #{t}
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}

