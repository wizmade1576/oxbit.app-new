import React, { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'

function NavItem({ to, children, compact = false }) {
  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) =>
        `${compact ? 'px-1 py-0.5 text-base' : 'px-3 py-2 text-sm'} font-medium ${isActive ? 'text-white' : 'text-zinc-300 hover:text-white'}`
      }
    >
      {children}
    </NavLink>
  )
}

function SearchIcon({ className = 'h-5 w-5' }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  )
}

export default function HeaderWithTheme() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)

  function onSearchSubmit(e) {
    e.preventDefault()
    const query = (q || '').trim()
    if (query) navigate(`/search?q=${encodeURIComponent(query)}`)
    setOpen(false)
  }

  function handleLogoClick(e) {
    if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(max-width: 768px)').matches) {
      e.preventDefault()
      navigate('/breaking')
    }
  }

  return (
    <header className="sticky top-0 z-40 border-b border-zinc-800 bg-[#0F1114]/95 backdrop-blur">
      {/* 모바일은 높이를 조금 늘려 탭을 더 아래로 배치 */}
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:h-14">
        {/* Left: 로고 + 모바일 탭을 한 줄로 배치 */}
        <div className="flex flex-1 items-end gap-2 md:items-center md:gap-6">
          <Link to="/" onClick={handleLogoClick} className="text-lg font-semibold text-white">
            Oxbit.app
          </Link>

          {/* 모바일 탭: 로고 오른쪽에 붙여 배치 */}
          <nav className="flex items-end gap-1 md:hidden">
            <NavItem to="/breaking" compact>속보</NavItem>
            <span className="text-zinc-600">|</span>
            <NavItem to="/news" compact>뉴스룸</NavItem>
          </nav>

          {/* 데스크탑 네비 */}
          <nav className="hidden items-center gap-1 md:flex">
            <NavItem to="/breaking">속보</NavItem>
            <NavItem to="/news">뉴스룸</NavItem>
            <NavItem to="/market">마켓</NavItem>
            <NavItem to="/live">실시간포지션</NavItem>
            <NavItem to="/community">커뮤니티</NavItem>
            <NavItem to="/mock">모의투자</NavItem>
          </nav>
        </div>

        {/* Right: 검색(돋보기) + 로그인 */}
        <div className="relative flex items-center gap-3">
          {/* 데스크탑/모바일 공통: 돋보기 아이콘으로 검색 오버레이 토글 */}
          <button
            type="button"
            className="p-0 text-zinc-200"
            onClick={() => setOpen((v) => !v)}
            aria-label="검색 열기"
          >
            <SearchIcon />
          </button>
          {open && (
            <div className="absolute right-0 top-12 z-50 w-[85vw] max-w-sm rounded border border-zinc-700 bg-[#0F1114] p-2 shadow-lg">
              <form onSubmit={onSearchSubmit} className="flex items-center gap-2">
                <input
                  autoFocus
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="검색(제목/내용)"
                  className="flex-1 rounded border border-zinc-700 bg-zinc-950 px-3 py-1.5 text-sm text-zinc-200 placeholder-zinc-500 outline-none focus:border-zinc-500"
                />
                <button className="rounded bg-white/10 px-3 py-1.5 text-sm hover:bg-white/20">검색</button>
              </form>
            </div>
          )}

          <Link to="/login" className="px-0 py-0 text-sm text-zinc-200 md:rounded md:bg-white/10 md:px-3 md:py-1.5 md:hover:bg-white/20">
            로그인
          </Link>
        </div>
      </div>
    </header>
  )
}
