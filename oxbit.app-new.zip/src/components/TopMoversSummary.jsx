import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchSpotTickers } from '../services/marketService.js'

export default function TopMoversSummary({ limit = 8 }) {
  const [tab, setTab] = React.useState('up')
  const { data = [], isLoading } = useQuery({
    queryKey: ['market:top-movers', 'binance'],
    queryFn: () => fetchSpotTickers('binance'),
    staleTime: 60_000,
    refetchInterval: 120_000,
  })

  const movers = React.useMemo(() => {
    const arr = Array.isArray(data) ? data.filter((r) => Number.isFinite(r.changePct)) : []
    arr.sort((a, b) => (tab === 'up' ? b.changePct - a.changePct : a.changePct - b.changePct))
    return arr.slice(0, limit)
  }, [data, tab, limit])

  return (
    <section className="rounded-xl border border-white/10 bg-[#13161A] p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {[
            { k: 'up', label: '급등' },
            { k: 'down', label: '급락' },
          ].map((t) => (
            <button
              key={t.k}
              onClick={() => setTab(t.k)}
              className={`px-2.5 py-1 rounded text-xs border ${tab === t.k ? 'bg-white/10 text-white border-white/20' : 'text-gray-300 border-white/10 hover:bg-white/5'}`}
            >
              {t.label}
            </button>
          ))}
        </div>
        {isLoading && <span className="text-xs text-gray-400">업데이트 중</span>}
      </div>
      <ul className="grid grid-cols-1 gap-2">
        {(isLoading ? Array.from({ length: limit }) : movers).map((it, idx) => (
          <li key={isLoading ? idx : it.symbol} className="rounded-lg bg-white/5 border border-white/10 px-3 py-2 flex items-center justify-between">
            {isLoading ? (
              <div className="w-full animate-pulse">
                <div className="h-4 w-1/3 bg-white/10 rounded mb-1" />
                <div className="h-3 w-2/3 bg-white/10 rounded" />
              </div>
            ) : (
              <>
                <div className="min-w-0 flex items-center gap-2">
                  <span className="text-[11px] text-gray-400 w-5 text-center">#{idx + 1}</span>
                  <div className="text-sm font-medium text-gray-100 truncate max-w-[120px]">{it.base}</div>
                </div>
                <div className={`text-sm font-semibold ${it.changePct >= 0 ? 'text-rose-400' : 'text-blue-400'}`}>{it.changePct.toFixed(2)}%</div>
              </>
            )}
          </li>
        ))}
      </ul>
    </section>
  )
}

