import React from 'react'
import { useQuery } from '@tanstack/react-query'

function useFearGreed() {
  return useQuery({
    queryKey: ['fearGreed', 7],
    queryFn: async () => {
      const res = await fetch('https://api.alternative.me/fng/?limit=7')
      if (!res.ok) throw new Error('Network error')
      const json = await res.json()
      const arr = Array.isArray(json?.data) ? json.data : []
      return arr.map((d) => ({
        value: Number(d.value),
        label: String(d.value_classification || ''),
        ts: Number(d.timestamp) * 1000,
      }))
    },
    staleTime: 60_000,
    refetchInterval: 300_000,
  })
}

function classify(n) {
  if (!isFinite(n)) return { text: 'N/A', emoji: '–' }
  if (n <= 24) return { text: '극단적 공포', emoji: '😱' }
  if (n <= 44) return { text: '공포', emoji: '😟' }
  if (n <= 55) return { text: '중립', emoji: '😐' }
  if (n <= 74) return { text: '탐욕', emoji: '🤑' }
  return { text: '극단적 탐욕', emoji: '🚀' }
}

function Bars({ values = [], loading }) {
  if (loading) {
    return (
      <div className="grid grid-cols-7 gap-1 h-16 items-end">
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} className="bg-white/10 rounded-sm animate-pulse" style={{ height: `${20 + (i % 5) * 10}%` }} />
        ))}
      </div>
    )
  }
  const nums = values.map((v) => (isFinite(v) ? v : 0))
  const max = Math.max(1, ...nums)
  const min = Math.min(...nums)
  const span = Math.max(1, max - min)
  return (
    <div className="grid grid-cols-7 gap-1 h-16 items-end">
      {nums.map((v, i) => {
        const pct = ((v - min) / span) * 100
        const h = Math.max(8, Math.round(pct))
        const tone = v >= 56 ? 'bg-emerald-400/70' : v >= 45 ? 'bg-gray-300/70' : 'bg-rose-400/70'
        return <div key={i} className={`${tone} rounded-sm hover:bg-white/80 hover:scale-[1.01] transition-all`} style={{ height: `${h}%` }} title={`${v}`} />
      })}
    </div>
  )
}

export default function FearGreed() {
  const { data = [], isLoading, isError, refetch, isFetching } = useFearGreed()
  const today = data[0]
  const cls = classify(today?.value)
  const values = [...data].reverse().map((d) => d.value)

  return (
    <section className="rounded-xl border border-white/10 bg-[#13161A] p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm text-gray-300">공포 · 탐욕 지수</h3>
        <button onClick={() => refetch()} disabled={isFetching} className="text-xs px-2 py-1 rounded border border-white/10 text-gray-300 hover:bg-white/5 disabled:opacity-50">새로고침</button>
      </div>

      {isError ? (
        <div className="space-y-2">
          <div className="text-sm text-rose-300">불러오기 실패</div>
          <button onClick={() => refetch()} className="px-3 py-1.5 rounded-md text-sm border border-white/10 text-gray-200 hover:bg-white/10">다시 시도</button>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-3">
            <div className="text-3xl font-bold text-white">{isLoading ? '-' : today?.value ?? '-'}</div>
            <div className="text-sm text-gray-300">{isLoading ? '로딩 중…' : `${cls.emoji} ${cls.text}`}</div>
          </div>
          <Bars values={values} loading={isLoading} />
        </>
      )}
    </section>
  )
}

