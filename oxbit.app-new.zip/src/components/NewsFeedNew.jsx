﻿import { useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { fetchLatestNews, fetchNewsDetail } from '../services/newsService'

export default function NewsFeed({ limit = 12 }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const rowRef = useRef(null)
  const [canLeft, setCanLeft] = useState(false)
  const [canRight, setCanRight] = useState(false)

  const location = useLocation()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const q = useMemo(
    () => new URLSearchParams(location.search).get('q')?.toLowerCase() ?? '',
    [location.search]
  )

  const { data, isLoading } = useQuery({
    queryKey: ['news', { limit: 12 }],
    queryFn: () => fetchLatestNews(12),
    staleTime: 60_000,
    refetchInterval: 60_000,
  })
  useEffect(() => { setItems(data || []) }, [data])
  useEffect(() => { setLoading(isLoading) }, [isLoading])

  const filtered = useMemo(
    () => (q ? items.filter((n) => n.title?.toLowerCase().includes(q)) : items),
    [items, q]
  )

  const updateScrollState = () => {
    const el = rowRef.current
    if (!el) return
    const { scrollLeft, clientWidth, scrollWidth } = el
    setCanLeft(scrollLeft > 0)
    setCanRight(scrollLeft + clientWidth < scrollWidth - 1)
  }
  useEffect(() => {
    updateScrollState()
    const onResize = () => updateScrollState()
    window.addEventListener('resize', onResize)
    const el = rowRef.current
    if (el) el.addEventListener('scroll', updateScrollState)
    return () => {
      window.removeEventListener('resize', onResize)
      if (el) el.removeEventListener('scroll', updateScrollState)
    }
  }, [filtered.length])

  const scrollByX = (dx) => {
    const el = rowRef.current
    if (!el) return
    el.scrollBy({ left: dx, behavior: 'smooth' })
  }

  const timeLabel = (iso) => {
    try {
      const d = new Date(iso)
      const hh = String(d.getHours()).padStart(2, '0')
      const mm = String(d.getMinutes()).padStart(2, '0')
      return `${hh}:${mm}`
    } catch { return '-' }
  }

  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between">
        <h2 className="text-lg sm:text-xl font-extrabold text-gray-900 dark:text-gray-100">실시간 가장 빠른 암호화폐 뉴스</h2>
        {q && <div className="text-sm text-gray-400">검색어: “{q}”</div>}
      </div>

      {loading && <div className="text-sm text-gray-400">불러오는 중…</div>}

      {/* 모바일/태블릿: 가로 스크롤 */}
      <div className="relative md:hidden">
        {canLeft && <div className="pointer-events-none absolute left-0 top-0 h-full w-8 bg-gradient-to-r from-white dark:from-[#0F1114] to-transparent" />}
        {canRight && <div className="pointer-events-none absolute right-0 top-0 h-full w-8 bg-gradient-to-l from-white dark:from-[#0F1114] to-transparent" />}

        <button
          type="button"
          onClick={() => scrollByX(-320)}
          className={`absolute left-1 top-1/2 -translate-y-1/2 z-10 rounded-full p-2 transition ${canLeft ? 'opacity-100' : 'opacity-0 pointer-events-none'} bg-black/10 text-gray-600 hover:bg-black/20 dark:bg-white/10 dark:text-gray-200 dark:hover:bg-white/20`}
          aria-label="이전"
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5"><path d="M15.53 4.53a.75.75 0 0 0-1.06-1.06l-8 8a.75.75 0 0 0 0 1.06l8 8a.75.75 0 1 0 1.06-1.06L8.06 12l7.47-7.47Z"/></svg>
        </button>
        <button
          type="button"
          onClick={() => scrollByX(320)}
          className={`absolute right-1 top-1/2 -translate-y-1/2 z-10 rounded-full p-2 transition ${canRight ? 'opacity-100' : 'opacity-0 pointer-events-none'} bg-black/10 text-gray-600 hover:bg-black/20 dark:bg-white/10 dark:text-gray-200 dark:hover:bg-white/20`}
          aria-label="다음"
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5"><path d="M8.47 19.47a.75.75 0 1 0 1.06 1.06l8-8a.75.75 0 0 0 0-1.06l-8-8a.75.75 0 1 0-1.06 1.06L15.94 12l-7.47 7.47Z"/></svg>
        </button>

        <div ref={rowRef} className="flex gap-4 overflow-x-auto pr-2 snap-x snap-mandatory scroll-smooth" style={{ scrollbarWidth: 'none' }}>
          {filtered.slice(0, limit).map((n) => (
            <article
              key={n.id}
              onMouseEnter={() => queryClient.prefetchQuery({ queryKey: ['newsDetail', { id: n.id }], queryFn: () => fetchNewsDetail({ id: n.id }) })}
              onClick={() => navigate(`/news/detail?id=${encodeURIComponent(n.id)}`)}
              className="snap-start w-[280px] shrink-0 rounded-xl border overflow-hidden shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg cursor-pointer border-black/10 bg-white hover:border-black/20 dark:border-white/10 dark:bg-[#0f1114] dark:hover:border-white/20"
            >
              {n.image && <img src={n.image} alt="" className="h-36 w-full object-cover" />}
              <div className="p-4">
                <div className="mb-2 text-[11px] text-gray-500 dark:text-gray-400">{n.source} · {timeLabel(n.published_at)}</div>
                <h3 className="text-[15px] font-semibold leading-snug text-gray-900 dark:text-gray-100 line-clamp-2">{n.title}</h3>
                {n.description && <p className="mt-2 text-sm text-gray-600 dark:text-gray-300/90 line-clamp-2">{n.description}</p>}
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* 데스크톱: 4열 그리드 */}
      <div className="hidden md:grid grid-cols-2 lg:grid-cols-4 gap-4">
        {filtered.slice(0, limit).map((n) => (
          <article
            key={n.id}
            onMouseEnter={() => queryClient.prefetchQuery({ queryKey: ['newsDetail', { id: n.id }], queryFn: () => fetchNewsDetail({ id: n.id }) })}
            onClick={() => navigate(`/news/detail?id=${encodeURIComponent(n.id)}`)}
            className="rounded-xl border overflow-hidden shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg cursor-pointer border-black/10 bg-white hover:border-black/20 dark:border-white/10 dark:bg-[#0f1114] dark:hover:border-white/20"
          >
            {n.image && <img src={n.image} alt="" className="h-40 w-full object-cover" />}
            <div className="p-4">
              <div className="mb-2 text-[11px] text-gray-500 dark:text-gray-400">{n.source} · {timeLabel(n.published_at)}</div>
              <h3 className="text-[15px] font-semibold leading-snug text-gray-900 dark:text-gray-100 line-clamp-2">{n.title}</h3>
              {n.description && <p className="mt-2 text-sm text-gray-600 dark:text-gray-300/90 line-clamp-2">{n.description}</p>}
            </div>
          </article>
        ))}
      </div>

      {!loading && filtered.length === 0 && (
        <div className="text-sm text-gray-400">표시할 뉴스가 없습니다.</div>
      )}
    </section>
  )
}
