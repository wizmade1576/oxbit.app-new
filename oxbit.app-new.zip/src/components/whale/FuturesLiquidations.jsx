import React from 'react'
import { Card, ScrollableTable, formatNumber, formatCurrency } from '../common/TableCard.jsx'
import { useFuturesLiquidations } from '../../hooks/useWhaleQueries'

export default function FuturesLiquidations() {
  const { data = [], isLoading } = useFuturesLiquidations()
  const rows = data.length ? data : [
    { time: '12:00:40', ex: 'Binance', side: 'Long', price: 986900000, amount: 52000000 },
    { time: '11:59:32', ex: 'Bybit', side: 'Short', price: 987300000, amount: 22000000 },
  ]

  return (
    <Card title="선물 고래 청산 내역">
      <ScrollableTable
        loading={isLoading && rows.length === 0}
        columns={[
          { key: 'time', label: '시간', align: 'left' },
          { key: 'ex', label: '거래소', align: 'left' },
          { key: 'side', label: '방향', align: 'center' },
          { key: 'price', label: '가격', align: 'right' },
          { key: 'amount', label: '규모(원)', align: 'right' },
        ]}
        rows={rows}
        rowClass={(r) => (r.side === 'Long' ? 'text-emerald-300' : 'text-rose-300')}
        format={{ price: formatNumber, amount: formatCurrency }}
      />
    </Card>
  )
}

