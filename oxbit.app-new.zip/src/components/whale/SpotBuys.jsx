import React from 'react'
import { Card, ScrollableTable, formatNumber, formatCurrency } from '../common/TableCard.jsx'
import { useSpotBuys } from '../../hooks/useWhaleQueries'

export default function SpotBuys() {
  const { data = [], isLoading } = useSpotBuys()
  const rows = data.length ? data : [
    { time: '12:01:14', ex: 'Upbit', coin: 'BTC', price: 98765432, qty: 1.2, amount: 118518518 },
    { time: '12:00:50', ex: 'Bithumb', coin: 'ETH', price: 4987654, qty: 15, amount: 74814810 },
  ]

  return (
    <Card title="현물 고래 매수 내역">
      <ScrollableTable
        loading={isLoading && rows.length === 0}
        columns={[
          { key: 'time', label: '시간', align: 'left' },
          { key: 'ex', label: '거래소', align: 'left' },
          { key: 'coin', label: '코인', align: 'left' },
          { key: 'price', label: '가격', align: 'right' },
          { key: 'qty', label: '수량', align: 'right' },
          { key: 'amount', label: '금액(원)', align: 'right' },
        ]}
        rows={rows}
        rowClass={() => 'text-emerald-300'}
        format={{ price: formatNumber, qty: (v) => v.toLocaleString(), amount: formatCurrency }}
      />
    </Card>
  )
}

