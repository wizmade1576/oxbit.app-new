import React from 'react'
import { Card, ScrollableTable, formatNumber, formatCurrency } from '../common/TableCard.jsx'
import { useSpotSells } from '../../hooks/useWhaleQueries'

export default function SpotSells() {
  const { data = [], isLoading } = useSpotSells()
  const rows = data.length ? data : [
    { time: '12:00:31', ex: 'Coinone', coin: 'XRP', price: 857, qty: 22000, amount: 18854000 },
    { time: '11:59:58', ex: 'Korbit', coin: 'DOGE', price: 192, qty: 120000, amount: 23040000 },
  ]

  return (
    <Card title="현물 고래 매도 내역">
      <ScrollableTable
        loading={isLoading && rows.length === 0}
        columns={[
          { key: 'time', label: '시간', align: 'left' },
          { key: 'ex', label: '거래소', align: 'left' },
          { key: 'coin', label: '코인', align: 'left' },
          { key: 'price', label: '가격', align: 'right' },
          { key: 'qty', label: '수량', align: 'right' },
          { key: 'amount', label: '금액(원)', align: 'right' },
        ]}
        rows={rows}
        rowClass={() => 'text-rose-300'}
        format={{ price: formatNumber, qty: (v) => v.toLocaleString(), amount: formatCurrency }}
      />
    </Card>
  )
}

