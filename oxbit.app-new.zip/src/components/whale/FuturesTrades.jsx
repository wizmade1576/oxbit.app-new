import React from 'react'
import { Card, ScrollableTable, formatNumber, formatCurrency } from '../common/TableCard.jsx'
import { useFuturesTrades } from '../../hooks/useWhaleQueries'

export default function FuturesTrades() {
  const { data = [], isLoading } = useFuturesTrades()
  const rows = data.length ? data : [
    { time: '12:01:10', ex: 'Binance', side: 'Long', price: 987654321, qty: 12.3, amount: 150000000 },
    { time: '12:00:55', ex: 'Bybit', side: 'Short', price: 987100000, qty: 2.1, amount: 3000000 },
    { time: '12:00:20', ex: 'OKX', side: 'Long', price: 986800000, qty: 0.85, amount: 1200000 },
  ]

  return (
    <Card title="선물 고래 체결 내역">
      <ScrollableTable
        loading={isLoading && rows.length === 0}
        columns={[
          { key: 'time', label: '시간', align: 'left' },
          { key: 'ex', label: '거래소', align: 'left' },
          { key: 'side', label: '방향(Long/Short)', align: 'center' },
          { key: 'price', label: '가격', align: 'right' },
          { key: 'qty', label: '수량', align: 'right' },
          { key: 'amount', label: '규모(원)', align: 'right' },
        ]}
        rows={rows}
        rowClass={(r) => (r.side === 'Long' ? 'text-emerald-300' : 'text-rose-300')}
        format={{ price: formatNumber, qty: (v) => v.toLocaleString(), amount: formatCurrency }}
      />
    </Card>
  )
}

