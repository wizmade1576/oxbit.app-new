import React, { useMemo } from 'react'

export default function LiveFeed({ compact = false }) {
  const data = useMemo(
    () => [
      {
        name: '박호두',
        avatar: '/avatars/parkhodu.png',
        youtube: true,
        symbol: 'BTCUSDT',
        side: 'Short',
        leverage: 50,
        qty: -1,
        pnl_usd: 2209,
        pnl_rate: 100.44,
        entry: 110004,
        price: 107794.3,
        liq: 118337,
        pnl_krw: '3,200만원',
        status: '수익',
      },
      {
        name: '코인연구자',
        avatar: 'https://i.pravatar.cc/64?img=32',
        youtube: true,
        symbol: 'ETHUSDT',
        side: 'Long',
        leverage: 20,
        qty: 5,
        pnl_usd: -320,
        pnl_rate: -3.8,
        entry: 3850.2,
        price: 3798.7,
        liq: 3450,
        pnl_krw: '-420만원',
        status: '손실',
      },
      {
        name: '암호여신',
        avatar: 'https://i.pravatar.cc/64?img=45',
        youtube: false,
        symbol: 'SOLUSDT',
        side: 'Short',
        leverage: 10,
        qty: -40,
        pnl_usd: 1290,
        pnl_rate: 6.2,
        entry: 192.1,
        price: 186.7,
        liq: 215,
        pnl_krw: '170만원',
        status: '수익',
      },
    ],
    []
  )

  const isProfit = (usd) => Number(usd) >= 0
  const sideColor = (side) => (side?.toLowerCase() === 'long' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' : 'bg-rose-500/15 text-rose-300 border-rose-500/30')
  const statusColor = (s) => (s === '수익' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' : 'bg-rose-500/15 text-rose-300 border-rose-500/30')
  const fmt = (n, d = 0) => (isFinite(n) ? Number(n).toLocaleString(undefined, { maximumFractionDigits: d }) : '-')

  return (
    <section className="rounded-md border border-white/10 bg-[#0F1114]/80 shadow-md">
      <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 border-b border-white/10">
        <h2 className="text-sm sm:text-base font-semibold text-gray-100">지금 현재, 인플루언서들의 포지션은?</h2>
        <a href="/live" className="text-xs text-blue-400 hover:text-blue-300">자세히 보기 →</a>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-[840px] w-full table-fixed text-[13px] text-gray-200">
          <thead className="bg-black/20 text-gray-400 text-xs">
            <tr className="divide-x divide-white/5">
              <th className="px-2.5 py-2 text-left font-medium w-40">BJ</th>
              <th className="px-2.5 py-2 text-left font-medium w-40">포지션</th>
              <th className="px-2.5 py-2 text-right font-medium w-20">수량</th>
              <th className="px-2.5 py-2 text-right font-medium w-32">P&L(달러)</th>
              <th className="px-2.5 py-2 text-right font-medium w-24">진입가</th>
              <th className="px-2.5 py-2 text-right font-medium w-24">현재가</th>
              <th className="px-2.5 py-2 text-right font-medium w-24">청산가</th>
              <th className="px-2.5 py-2 text-right font-medium w-40">P&L(원화)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {data.map((row, idx) => (
              <tr key={idx} className="hover:bg-white/5 transition-colors">
                <td className="px-2.5 py-2">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={row.avatar}
                      alt={row.name}
                      className="w-7 h-7 rounded-full object-cover"
                      onError={(e) => { e.currentTarget.src = 'https://i.pravatar.cc/64?img=12' }}
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="font-semibold text-gray-100 truncate leading-none">{row.name}</span>
                        {row.youtube && (
                          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-red-500" fill="currentColor" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6zm11-3c0-2.5-.2-4-1-5-.9-1-2-1-5-1H9c-3 0-4.1 0-5 1-.8 1-1 2.5-1 5s.2 4 1 5c.9 1 2 1 5 1h6c3 0 4.1 0 5-1 .8-1 1-2.5 1-5z"/></svg>
                        )}
                      </div>
                      <div className="text-[11px] text-gray-400 leading-none mt-0.5">{row.symbol}</div>
                    </div>
                  </div>
                </td>
                <td className="px-2.5 py-2">
                  <div className="inline-flex items-center gap-1.5">
                    <span className={`px-1.5 py-0.5 rounded border text-[11px] font-semibold ${sideColor(row.side)}`}>{row.side}</span>
                    <span className="px-1.5 py-0.5 rounded bg-white/10 text-[11px] text-gray-200 border border-white/10">{row.leverage}x</span>
                  </div>
                </td>
                <td className="px-2.5 py-2 text-right">{fmt(row.qty)}</td>
                <td className="px-2.5 py-2 text-right">
                  <div className={`font-semibold ${isProfit(row.pnl_usd) ? 'text-emerald-300' : 'text-rose-300'}`}>
                    ${fmt(row.pnl_usd)} <span className="text-[11px] ml-1">({fmt(row.pnl_rate, 2)}%)</span>
                  </div>
                </td>
                <td className="px-2.5 py-2 text-right">{fmt(row.entry, 2)}</td>
                <td className="px-2.5 py-2 text-right">{fmt(row.price, 2)}</td>
                <td className="px-2.5 py-2 text-right">{fmt(row.liq, 2)}</td>
                <td className="px-2.5 py-2 text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    <span className={`font-semibold ${isProfit(row.pnl_usd) ? 'text-emerald-300' : 'text-rose-300'}`}>{row.pnl_krw}</span>
                    <span className={`px-1.5 py-0.5 rounded border text-[11px] font-semibold ${statusColor(row.status)}`}>{row.status}</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
