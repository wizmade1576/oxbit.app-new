import React from 'react'
import { NavLink } from 'react-router-dom'

function Item({ to, label }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex flex-1 items-center justify-center py-2 text-xs ${isActive ? 'text-white' : 'text-zinc-400 hover:text-white'}`
      }
      end
    >
      {label}
    </NavLink>
  )
}

function Icon({ d }) {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d={d} />
    </svg>
  )
}

export default function MobileBottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-zinc-800 bg-[#0F1114] px-2 md:hidden">
      <div className="flex">
        {/* 1. 모의투자 (페이지로 이동) */}
        <NavLink to="/mock" className={({isActive})=>`flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs ${isActive?'text-white':'text-zinc-400 hover:text-white'}`} end>
          <Icon d="M12 20l9-5-9-5-9 5 9 5z M12 12l9-5-9-5-9 5 9 5z" />
          <span>모의투자</span>
        </NavLink>
          {/* 2. 속보 */}
          <NavLink to="/breaking" className={({isActive})=>`flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs ${isActive?'text-white':'text-zinc-400 hover:text-white'}`} end>
            <Icon d="M3 3h18M3 9h18M3 15h18M3 21h18" />
            <span>속보</span>
          </NavLink>
          {/* 3. 마켓 */}
          <NavLink to="/market" className={({isActive})=>`flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs ${isActive?'text-white':'text-zinc-400 hover:text-white'}`} end>
            <Icon d="M3 17h4V7H3v10zm7 0h4V3h-4v14zm7 0h4V11h-4v6z" />
            <span>마켓</span>
          </NavLink>
          {/* 4. 실시간포지션 */}
          <NavLink to="/live" className={({isActive})=>`flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs ${isActive?'text-white':'text-zinc-400 hover:text-white'}`} end>
            <Icon d="M2 12h20 M12 2v20" />
            <span>실시간포지션</span>
          </NavLink>
        {/* 5. 커뮤니티 */}
        <NavLink to="/community" className={({isActive})=>`flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs ${isActive?'text-white':'text-zinc-400 hover:text-white'}`} end>
            <Icon d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2 M12 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75" />
            <span>커뮤니티</span>
        </NavLink>
      </div>
    </nav>
  )
}
