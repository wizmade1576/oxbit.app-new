﻿import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'

const mainTabs = [
  { key: 'stock', to: '/market/stock', label: '스톡' },
  { key: 'coin', to: '/market/spot-kr', label: '암호화폐', match: ['/market/spot-kr','/market/spot-global'] },
  { key: 'futures', to: '/market/futures', label: '선물' },
  { key: 'kimchi', to: '/market/kimchi', label: '김프' },
  { key: 'schedule', to: '/market/schedule', label: '일정' },
]

export default function MarketTabsNav() {
  const { pathname } = useLocation()
  const isCoin = pathname.startsWith('/market/spot-')
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1 sm:gap-2">
        {mainTabs.map((t) => {
          const active = t.match ? t.match.some((m) => pathname.startsWith(m)) : pathname.startsWith(t.to)
          return (
            <NavLink
              key={t.to}
              to={t.to}
              className={() =>
                `px-3 py-2 rounded-md text-sm border ${
                  active ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'
                }`
              }
            >
              {t.label}
            </NavLink>
          )
        })}
      </div>

      {isCoin && (
        <div className="flex flex-wrap gap-1 sm:gap-2">
          <NavLink
            to="/market/spot-kr"
            className={({ isActive }) =>
              `px-2.5 py-1.5 rounded-md text-xs border ${
                isActive ? 'bg-white/10 text-white border-white/20' : 'border-white/10 text-gray-300 hover:bg-white/5'
              }`
            }
          >
            현물(국내)
          </NavLink>
          <NavLink
            to="/market/spot-global"
            className={({ isActive }) =>
              `px-2.5 py-1.5 rounded-md text-xs border ${
                isActive ? 'bg-white/10 text-white border-white/20' : 'border-white/10 text-gray-300 hover:bg-white/5'
              }`
            }
          >
            현물(글로벌)
          </NavLink>
        </div>
      )}
    </div>
  )
}



