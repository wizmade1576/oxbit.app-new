﻿import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'

const tabs = [
  { to: '/positions', label: '개요' },
  { to: '/positions/live', label: '실시간포지션' },
  { to: '/positions/whales', label: '고래' },
  { to: '/positions/feargreed', label: '공포/탐욕' },
]

export default function PositionsTabsNav() {
  const { pathname } = useLocation()
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      {tabs.map((t) => (
        <NavLink
          key={t.to}
          to={t.to}
          className={({ isActive }) =>
            `px-3 py-2 rounded-md text-sm border ${
              isActive || pathname === t.to
                ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white'
                : 'border-white/10 text-gray-300 hover:bg-white/10'
            }`
          }
        >
          {t.label}
        </NavLink>
      ))}
    </div>
  )
}
