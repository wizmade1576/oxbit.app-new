﻿import React from 'react'

// Lightweight, locally manageable ad slot.
// Admin 연결 전까지는 localStorage로 간단히 교체 가능:
// localStorage.setItem('ox:ad:market-bottom', JSON.stringify({
//   imageUrl: 'https://via.placeholder.com/336x280?text=AD',
//   linkUrl: 'https://example.com',
//   alt: '광고 배너'
// }))
export default function ManagedAd({ slot = 'default', className = '' }) {
  let cfg = null
  try {
    const raw = localStorage.getItem(`ox:ad:${slot}`)
    if (raw) cfg = JSON.parse(raw)
  } catch {}

  if (cfg?.imageUrl) {
    const content = (
      <img
        src={cfg.imageUrl}
        alt={cfg.alt || '광고'}
        className="h-full w-full object-cover rounded-md"
        loading="lazy"
      />
    )
    return (
      <div className={`w-full ${className}`} aria-label={`ad-slot-${slot}`}>
        {cfg.linkUrl ? (
          <a href={cfg.linkUrl} target="_blank" rel="noopener noreferrer" className="block">
            {content}
          </a>
        ) : content}
      </div>
    )
  }

  // Placeholder (sidebar friendly): 336x280 / 300x250 대응
  return (
    <div className={`w-full ${className}`} aria-label={`ad-slot-${slot}`}>
      <div className="relative w-full h-[150px] md:h-[150px] rounded-md border border-white/10 bg-white/5 flex items-center justify-center text-xs text-gray-300">
        <span className="absolute top-1 left-2 rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-gray-300">광고</span>
        <span className="opacity-80">300×250 / 336×280 (placeholder)</span>
      </div>
    </div>
  )
}

