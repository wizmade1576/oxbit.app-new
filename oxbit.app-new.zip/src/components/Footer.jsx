export default function Footer() {
  return (
    <footer className="border-t border-white/10 mt-8">
      <div className="ox-container py-6 text-sm text-gray-400 flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <div>© {new Date().getFullYear()} Oxbit.app. All rights reserved.</div>
        <div className="flex gap-4">
          <a href="#" className="hover:text-white">약관</a>
          <a href="#" className="hover:text-white">회사정보</a>
          <a href="#" className="hover:text-white">Twitter</a>
        </div>
      </div>
    </footer>
  )
}

