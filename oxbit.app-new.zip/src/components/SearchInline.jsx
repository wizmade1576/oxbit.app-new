import { useNavigate } from 'react-router-dom'
import { useState } from 'react'

export default function SearchInline() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const tags = ['XRP', 'UXLINK', 'SOL', 'ETH', '버츄얼', '에테나', 'BTC', 'WLFI', '도지', '플라즈마']

  const submit = (e) => {
    e.preventDefault()
    const query = q.trim()
    if (query) navigate(`/news?q=${encodeURIComponent(query)}`)
  }

  return (
    <section className="ox-container px-0">
      <div className="rounded-full border border-white/20 bg-white/5 px-4 py-2 flex items-center gap-3">
        <span className="text-gray-300">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
            <path fillRule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 4.207 12.042l3.25 3.25a.75.75 0 1 0 1.06-1.06l-3.25-3.25A6.75 6.75 0 0 0 10.5 3.75Zm-5.25 6.75a5.25 5.25 0 1 1 10.5 0 5.25 5.25 0 0 1-10.5 0Z" clipRule="evenodd" />
          </svg>
        </span>
        <form onSubmit={submit} className="flex-1">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="검색어를 입력해 주세요."
            className="w-full bg-transparent outline-none text-gray-100 placeholder:text-gray-400"
          />
        </form>
        <button onClick={submit} className="px-3 py-1.5 text-sm rounded-md bg-[#1D6FEA] text-white">검색</button>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-sm text-gray-400">
        <span className="mr-1">인기 코인</span>
        {tags.map((t) => (
          <button key={t} onClick={() => navigate(`/news?q=${encodeURIComponent(t)}`)} className="rounded-full bg-white/10 px-3 py-1 text-gray-200 hover:bg-white/20">#{t}</button>
        ))}
      </div>
    </section>
  )
}

