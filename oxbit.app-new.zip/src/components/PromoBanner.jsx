export default function PromoBanner() {
  // 레퍼럴 프로모션은 더 이상 표시하지 않습니다.
  return null
}
