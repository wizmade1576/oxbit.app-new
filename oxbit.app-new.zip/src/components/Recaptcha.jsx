import React from 'react'

// Lightweight reCAPTCHA wrapper.
// If VITE_RECAPTCHA_SITE_KEY is provided, tries to render v2 widget.
// Otherwise falls back to a simple checkbox (dev only).
export default function Recaptcha({ onVerify }) {
  const siteKey = (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_RECAPTCHA_SITE_KEY) || ''
  const [ok, setOk] = React.useState(false)

  React.useEffect(() => {
    if (!siteKey) return
    const id = 'recaptcha-script'
    if (!document.getElementById(id)) {
      const s = document.createElement('script')
      s.id = id
      s.src = 'https://www.google.com/recaptcha/api.js'
      s.async = true
      s.defer = true
      document.body.appendChild(s)
    }
    const timer = setInterval(() => {
      if (window.grecaptcha && window.grecaptcha.render) {
        clearInterval(timer)
        try {
          const el = document.getElementById('recaptcha-widget')
          if (el && !el.dataset.rendered) {
            el.dataset.rendered = '1'
            window.grecaptcha.render('recaptcha-widget', {
              sitekey: siteKey,
              callback: (token) => {
                setOk(true)
                onVerify && onVerify(token)
              },
            })
          }
        } catch (_) {}
      }
    }, 300)
    return () => clearInterval(timer)
  }, [siteKey, onVerify])

  if (!siteKey) {
    return (
      <label className="inline-flex items-center gap-2 text-xs text-gray-300">
        <input type="checkbox" checked={ok} onChange={(e)=>{ setOk(e.target.checked); if(e.target.checked) onVerify && onVerify('dev-ok') }} className="accent-[#1D6FEA]" />
        로봇이 아닙니다 (개발용)
      </label>
    )
  }

  return <div id="recaptcha-widget" className="g-recaptcha" />
}

