import React, { useMemo } from 'react'

export default function CommunityTopPosts({ limit = 5 }) {
  const top = useMemo(
    () => [
      { id: 1, rank: 1, cat: '이슈',        time: '19시간 전', title: 'BTC 급락 후 반등, 심리 지지/저항 레벨 정리', comments: 132 },
      { id: 2, rank: 2, cat: '자유',        time: '18시간 전', title: '체감 유동성/거래량 지표 공유',                 comments: 89 },
      { id: 3, rank: 3, cat: '이벤트',      time: '17시간 전', title: '[이벤트] 신규 가입 보너스 + 초대 보상',       comments: 67 },
      { id: 4, rank: 4, cat: '인플루언서',  time: '16시간 전', title: '선물 포지션/고래 흐름(주간)',                 comments: 41 },
      { id: 5, rank: 5, cat: '자유',        time: '15시간 전', title: '김치 프리미엄 가이드: 국내/해외 가격차',      comments: 58 },
    ].slice(0, limit),
    [limit]
  )

  return (
    <section className="rounded-xl border border-white/10 bg-[#13161A] p-4">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-100">커뮤니티 인기글 1~5</h3>
        <a href="/community" className="text-xs text-blue-400 hover:text-blue-300">전체보기</a>
      </div>
      <ul className="space-y-1">
        {top.map((p) => (
          <li key={p.id} className="group flex items-center gap-3 rounded-md px-2 py-2 hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-6 shrink-0 text-center font-bold text-gray-300 group-hover:text-white">{p.rank}</div>
            <span className="shrink-0 px-2 py-0.5 rounded-full text-[11px] border border-white/10 text-gray-300">{p.cat}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm text-gray-100 group-hover:text-white">{p.title}</div>
              <div className="text-[11px] text-gray-400">{p.time}</div>
            </div>
            <div className="shrink-0 text-xs text-gray-400">댓글 {p.comments}</div>
          </li>
        ))}
      </ul>
    </section>
  )
}

