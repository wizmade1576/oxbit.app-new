﻿import React, { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { KR_EXCHANGES, GLOBAL_EXCHANGES, fetchUsdKrwRate, buildKimpRows } from '../services/kimpService'
import Dropdown from './Dropdown.jsx'

export default function KimpTab() {
  const [kr, setKr] = useState('upbit')
  const [gl, setGl] = useState('binance')
  const [autoFx, setAutoFx] = useState(true)
  const [customFx, setCustomFx] = useState(1350)

  // Advanced options removed from UI. Keep sane defaults in logic.

  const krOptions = useMemo(
    () => Object.entries(KR_EXCHANGES).map(([k, v]) => ({ value: k, label: v.label, icon: v.icon })),
    []
  )
  const glOptions = useMemo(
    () => Object.entries(GLOBAL_EXCHANGES).map(([k, v]) => ({ value: k, label: v.label, icon: v.icon })),
    []
  )

  const { data: rate = 1350 } = useQuery({
    queryKey: ['fx:usdkrw'],
    queryFn: fetchUsdKrwRate,
    staleTime: 5 * 60_000,
  })

  // Load persisted exchange selections and FX preference
  React.useEffect(() => {
    try {
      const sKr = localStorage.getItem('kimp:kr')
      const sGl = localStorage.getItem('kimp:gl')
      const sAuto = localStorage.getItem('kimp:autoFx')
      const sFx = localStorage.getItem('kimp:customFx')
      if (sKr && KR_EXCHANGES[sKr]) setKr(sKr)
      if (sGl && GLOBAL_EXCHANGES[sGl]) setGl(sGl)
      if (sAuto === '0') setAutoFx(false)
      if (sFx && isFinite(Number(sFx))) setCustomFx(Number(sFx))
    } catch {}
  }, [])
  React.useEffect(() => { try { localStorage.setItem('kimp:kr', kr) } catch {} }, [kr])
  React.useEffect(() => { try { localStorage.setItem('kimp:gl', gl) } catch {} }, [gl])
  React.useEffect(() => { try { localStorage.setItem('kimp:autoFx', autoFx ? '1' : '0') } catch {} }, [autoFx])
  React.useEffect(() => { try { localStorage.setItem('kimp:customFx', String(customFx)) } catch {} }, [customFx])
  // (no-op persists for removed controls)

  const effectiveRate = autoFx ? rate : customFx

  const glList = React.useMemo(() => ['binance','coinbase','okx','bybit','bitget'], [])

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ['kimp:rows', { kr, gl, rate: effectiveRate }],
    queryFn: () => buildKimpRows({
      kr,
      gl,
      rate: effectiveRate,
      glList,
      useMedian: true,
      calibrateBy: 'BTC',
    }),
    staleTime: 20_000,
    refetchInterval: 60_000,
  })

  // filter & sort
  const [q, setQ] = useState('')
  const [metric, setMetric] = useState('kimp') // 'kimp' | 'diff' | 'base'
  const [dir, setDir] = useState('desc') // asc | desc

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase()
    if (!s) return rows
    return rows.filter((r) => r.base?.toLowerCase().includes(s))
  }, [rows, q])

  const sorted = useMemo(() => {
    const arr = [...filtered]
    arr.sort((a, b) => {
      const av = metric === 'kimp' ? a.kimpPct : metric === 'diff' ? a.diffKr : a.base
      const bv = metric === 'kimp' ? b.kimpPct : metric === 'diff' ? b.diffKr : b.base
      if (metric === 'base') return String(av).localeCompare(String(bv))
      const ax = isFinite(av) ? av : -Infinity
      const bx = isFinite(bv) ? bv : -Infinity
      return ax - bx
    })
    if (dir === 'desc') arr.reverse()
    return arr
  }, [filtered, metric, dir])

  // Top list + pin favorites
  const [topN, setTopN] = useState(0) // 0 = all
  const [pinned, setPinned] = useState(() => new Set())
  const togglePin = (base) =>
    setPinned((s) => {
      const n = new Set(s)
      n.has(base) ? n.delete(base) : n.add(base)
      return n
    })

  const displayed = useMemo(() => {
    const pins = sorted.filter((r) => pinned.has(r.base))
    const rest = sorted.filter((r) => !pinned.has(r.base))
    const merged = [...pins, ...rest]
    return topN > 0 ? merged.slice(0, topN) : merged
  }, [sorted, pinned, topN])

  const arrow = (key) => (metric === key ? (dir === 'asc' ? '▲' : '▼') : '')

  // Persist selected exchanges
  React.useEffect(() => {
    try {
      const sKr = localStorage.getItem('kimp:kr')
      const sGl = localStorage.getItem('kimp:gl')
      if (sKr && KR_EXCHANGES[sKr]) setKr(sKr)
      if (sGl && GLOBAL_EXCHANGES[sGl]) setGl(sGl)
    } catch {}
  }, [])
  React.useEffect(() => { try { localStorage.setItem('kimp:kr', kr) } catch {} }, [kr])
  React.useEffect(() => { try { localStorage.setItem('kimp:gl', gl) } catch {} }, [gl])

  return (
    <section className="space-y-0">
      {/* Header: sticky */}
      <div className="sticky top-6 md:top-16 z-50 bg-[#0F1114]/90 backdrop-blur border-b border-white/5">
        <div className="ox-container px-0 py-0 md:py-1 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <Dropdown value={kr} onChange={setKr} options={krOptions} labelPrefix="국내 거래소" />
            <span className="text-gray-500">vs</span>
            <Dropdown value={gl} onChange={setGl} options={glOptions} labelPrefix="해외 거래소" />
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-gray-300">
              <span className="hidden sm:inline">USD→KRW</span>
              <label className="inline-flex items-center gap-1">
                <input type="checkbox" checked={autoFx} onChange={(e)=>setAutoFx(e.target.checked)} /> 자동
              </label>
              <div className={`inline-flex items-center gap-1 rounded border border-white/10 px-2 py-1 ${autoFx ? 'opacity-60 pointer-events-none' : ''}`}>
                <button className="px-1 text-gray-300 hover:text-white" onClick={() => setCustomFx((v)=>Math.max(1, Math.round(v-1)))}>-</button>
                <input
                  type="number"
                  value={Number(effectiveRate).toFixed(2)}
                  onChange={(e)=>setCustomFx(Number(e.target.value) || 0)}
                  className="w-20 bg-transparent text-gray-100 text-xs focus:outline-none"
                />
                <button className="px-1 text-gray-300 hover:text-white" onClick={() => setCustomFx((v)=>Math.round(v+1))}>+</button>
              </div>
            </div>

            <div className="hidden sm:block text-xs text-gray-400">
              암호화폐 총 {sorted.length.toLocaleString()}개
            </div>

            <div className="flex items-center gap-2">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="BTC, 비트코인, 비트"
                className="w-36 sm:w-56 rounded-md border border-white/10 bg-white/5 px-2 py-1.5 text-sm text-gray-100 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-[#1D6FEA]"
              />
            </div>
          </div>
        </div>
        {/* Advanced controls removed by request */}
      </div>

      {/* Desktop table */}
      <div className="hidden md:block">
        <div className="rounded-xl border border-white/10 overflow-y-auto overflow-x-visible bg-[#0F1114] max-h-[70vh] pb-2">
          <table className="min-w-[880px] w-full text-sm">
            <thead className="sticky top-0 z-10 bg-[#0F1114] text-gray-400">
              <tr className="divide-x divide-white/5">
                <th className="px-3 py-2 text-left w-12">#</th>
                <th className="px-3 py-2 text-left">이름</th>
                <th className="px-3 py-2 text-right">현재가</th>
                <th className="px-3 py-2 text-right cursor-pointer" onClick={() => setMetric('kimp')}>김프 {arrow('kimp')}</th>
                <th className="px-3 py-2 text-right cursor-pointer" onClick={() => setMetric('diff')}>가격차(KRW) {arrow('diff')}</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/10">
              {displayed.map((r) => (
                <tr key={r.base} className="hover:bg-white/5 transition-colors">
                  <td className="px-3 py-2 text-gray-500">
                    <button
                      type="button"
                      onClick={() => togglePin(r.base)}
                      className={`inline-flex items-center justify-center w-6 h-6 rounded ${
                        pinned.has(r.base) ? 'text-yellow-300' : 'text-gray-400 hover:text-gray-200'
                      }`}
                    >
                      ★
                    </button>
                  </td>

                  <td className="px-3 py-2 text-gray-100 font-medium">{r.base}</td>
                  <td className="px-3 py-2 text-right">
                    <div className="text-gray-100 font-semibold">{r.krPrice?.toLocaleString() ?? '-'}</div>
                    <div className="text-[11px] text-gray-400">{r.usPrice ? Math.round(r.usPrice).toLocaleString() : '-'} KRW</div>
                  </td>
                  <td className={`px-3 py-2 text-right font-bold ${r.kimpPct >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                    {isFinite(r.kimpPct) ? r.kimpPct.toFixed(2) : '-'}%
                  </td>
                  <td className={`px-3 py-2 text-right ${r.diffKr >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                    {r.diffKr ? Math.round(r.diffKr).toLocaleString() : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile card */}
      <div className="md:hidden grid grid-cols-1 gap-3">
        {displayed.map((r, i) => (
          <div key={r.base} className="rounded-xl border border-white/10 bg-[#111318] p-4">
            <div className="flex items-center justify-between">
              <div className="font-semibold text-gray-100">{i + 1}. {r.base}</div>
              <button
                type="button"
                onClick={() => togglePin(r.base)}
                className={`w-7 h-7 rounded inline-flex items-center justify-center ${
                  pinned.has(r.base) ? 'text-yellow-300' : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                ★
              </button>
            </div>

            <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
              <div className="rounded-lg bg-white/5 p-2">
                <div className="text-xs text-gray-400">{KR_EXCHANGES[kr]?.label} (KRW)</div>
                <div className="text-gray-100 font-medium">{r.krPrice?.toLocaleString() ?? '-'}</div>
              </div>

              <div className="rounded-lg bg-white/5 p-2">
                <div className="text-xs text-gray-400">{GLOBAL_EXCHANGES[gl]?.label} (KRW)</div>
                <div className="text-gray-100 font-medium">{r.usPrice ? Math.round(r.usPrice).toLocaleString() : '-'}</div>
              </div>
            </div>

            <div className="mt-2 text-xs text-gray-300">
              가격 차이: {r.diffKr ? Math.round(r.diffKr).toLocaleString() : '-'} KRW
            </div>
          </div>
        ))}
      </div>

      {isLoading && <div className="text-sm text-gray-400">불러오는 중...</div>}
      {!isLoading && sorted.length === 0 && (
        <div className="text-sm text-gray-400">표시할 데이터가 없습니다.</div>
      )}
    </section>
  )
}




