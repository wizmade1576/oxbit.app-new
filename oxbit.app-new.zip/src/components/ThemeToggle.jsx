// Show the toggle UI but keep it non-functional (dark mode fixed)
export default function ThemeToggle() {
  const isDark = true
  const onClick = (e) => {
    e.preventDefault()
  }

  return (
    <button
      type="button"
      onClick={onClick}
      aria-disabled="true"
      className="p-2 rounded-md text-gray-300 hover:bg-white/10 hover:text-white cursor-not-allowed"
      title="다크 모드 고정"
    >
      <span className="relative inline-block w-5 h-5">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className={`absolute inset-0 w-5 h-5 transition-all duration-300 ${isDark ? 'opacity-0 scale-50 rotate-90' : 'opacity-100 scale-100 rotate-0'}`}
        >
          <path d="M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z" />
          <path fillRule="evenodd" d="M12 1.5a.75.75 0 0 1 .75.75v2a.75.75 0 1 1-1.5 0v-2A.75.75 0 0 1 12 1.5Zm0 17a.75.75 0 0 1 .75.75v2a.75.75 0 1 1-1.5 0v-2a.75.75 0 0 1 .75-.75Zm10.5-6a.75.75 0 0 1-.75.75h-2a.75.75 0 0 1 0-1.5h2a.75.75 0 0 1 .75.75Zm-17 0a.75.75 0 0 1-.75.75h-2a.75.75 0 1 1 0-1.5h2a.75.75 0 0 1 .75.75Zm12.903 7.153a.75.75 0 0 1-1.06 1.06l-1.414-1.414a.75.75 0 1 1 1.06-1.06l1.414 1.414Zm-10.607-10.607a.75.75 0 0 1-1.06 1.06L4.322 8.752a.75.75 0 0 1 1.06-1.06l1.414 1.414Zm10.607-1.414a.75.75 0 0 1 0 1.06L16.989 8.76a.75.75 0 0 1-1.06-1.06l1.414-1.414a.75.75 0 0 1 1.06 0ZM7.34 18.338a.75.75 0 0 1-1.06 0L4.867 16.93a.75.75 0 1 1 1.06-1.06l1.414 1.414a.75.75 0 0 1 0 1.06Z" clipRule="evenodd" />
        </svg>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="currentColor"
          className={`absolute inset-0 w-5 h-5 transition-all duration-300 ${isDark ? 'opacity-100 scale-100 rotate-0' : 'opacity-0 scale-50 -rotate-90'}`}
        >
          <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 1 0 9.79 9.79Z" />
        </svg>
      </span>
    </button>
  )
}

