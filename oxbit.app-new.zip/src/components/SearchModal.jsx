import React, { useEffect, useRef, useState } from 'react'

export default function SearchModal({
  open,
  onClose,
  onSearch,
  initialQuery = '',
  suggestions = ['XRP', 'UXLINK', 'SOL', 'ETH', '버츄얼', '에테나', 'BTC', 'WLFI', '도지', '플라즈마'],
}) {
  const [query, setQuery] = useState(initialQuery)
  const inputRef = useRef(null)

  useEffect(() => {
    if (!open) return
    const onKey = (e) => { if (e.key === 'Escape') onClose?.() }
    window.addEventListener('keydown', onKey)
    setTimeout(() => inputRef.current?.focus(), 0)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])

  useEffect(() => {
    if (!open) setQuery(initialQuery)
  }, [open, initialQuery])

  if (!open) return null

  const submit = (e) => {
    e.preventDefault()
    const q = query.trim()
    if (q) onSearch?.(q)
    onClose?.()
  }

  const selectTag = (tag) => {
    onSearch?.(tag)
    onClose?.()
  }

  return (
    <div className="fixed inset-0 z-[60] bg-[#0F1114]/95" role="dialog" aria-modal="true" onClick={() => onClose?.()}>
      {/* 닫기(X) 버튼 */}
      <button
        aria-label="닫기"
        onClick={(e) => { e.stopPropagation(); onClose?.() }}
        className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-md text-gray-300 hover:bg-white/10 hover:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
          <path fillRule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
        </svg>
      </button>

      {/* 콘텐츠 래퍼: 중앙 상단 */}
      <div className="mx-auto mt-12 w-full max-w-2xl px-4 sm:mt-16 sm:px-6" onClick={(e) => e.stopPropagation()}>
        {/* 검색 입력 */}
        <form onSubmit={submit} className="relative">
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-300">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
              <path fillRule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 4.207 12.042l3.25 3.25a.75.75 0 1 0 1.06-1.06l-3.25-3.25A6.75 6.75 0 0 0 10.5 3.75Zm-5.25 6.75a5.25 5.25 0 1 1 10.5 0 5.25 5.25 0 0 1-10.5 0Z" clipRule="evenodd" />
            </svg>
          </span>
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="검색어를 입력하세요."
            className="w-full rounded-xl border border-white/20 bg-white/10 pl-10 pr-28 py-3 text-gray-100 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="absolute inset-y-0 right-2 flex items-center gap-2">
            <button type="button" onClick={() => onClose?.()} className="text-gray-300 hover:text-white px-2 py-1">취소</button>
            <button type="submit" className="px-3 py-1.5 rounded-md bg-blue-500 text-white text-sm">검색</button>
          </div>
        </form>

        {/* 해시태그 추천 */}
        <div className="mt-4 flex flex-wrap gap-2">
          {suggestions.map((tag) => (
            <button
              key={tag}
              onClick={() => selectTag(tag)}
              className="rounded-full bg-white/10 px-3 py-1.5 text-sm text-gray-200 hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-blue-500"
              type="button"
            >
              #{tag}
            </button>
          ))}
        </div>

        {/* 레퍼럴 프로모션 배너 제거됨 */}
      </div>
    </div>
  )
}
