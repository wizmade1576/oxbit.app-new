import React from 'react'
import { useFuturesTrades, useFuturesLiquidations, useSpotBuys, useSpotSells } from '../hooks/useWhaleQueries.js'

function sumAmount(list) {
  return (Array.isArray(list) ? list : []).reduce((acc, r) => acc + (Number(r.amount) || 0), 0)
}

export default function WhaleSummary() {
  const ft = useFuturesTrades()
  const fl = useFuturesLiquidations()
  const sb = useSpotBuys()
  const ss = useSpotSells()

  // Fallback to mock when no data
  const mock = (v) => (v && Number.isFinite(v) && v > 0 ? v : 0)
  const futBuy = mock(sumAmount(ft.data)) || 12_500_000
  const futLiq = mock(sumAmount(fl.data)) || 6_200_000
  const spotBuy = mock(sumAmount(sb.data)) || 4_800_000
  const spotSell = mock(sumAmount(ss.data)) || 5_300_000

  const Item = ({ label, value, tone }) => (
    <div className="rounded-lg bg-white/5 border border-white/10 p-3">
      <div className="text-xs text-gray-400">{label}</div>
      <div className={`text-sm font-semibold ${tone}`}>{new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW', maximumFractionDigits: 0 }).format(value)}</div>
    </div>
  )

  return (
    <section className="rounded-xl border border-white/10 bg-[#13161A] p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm text-gray-300">고래 요약 (최근 1h)</h3>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Item label="선물 체결 합계" value={futBuy} tone="text-emerald-300" />
        <Item label="선물 청산 합계" value={futLiq} tone="text-rose-300" />
        <Item label="현물 매수 합계" value={spotBuy} tone="text-emerald-300" />
        <Item label="현물 매도 합계" value={spotSell} tone="text-rose-300" />
      </div>
    </section>
  )
}

