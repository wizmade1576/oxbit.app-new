import { useState } from 'react'
import PairsBoard from './PairsBoard.jsx'

const tabs = [
  { key: 'spot', label: '코인' },
  { key: 'kimchi', label: '김프' },
  { key: 'futures', label: '선물' },
]

export default function MarketTabs() {
  const [active, setActive] = useState('spot')
  return (
    <section className="space-y-3">
      <h2 className="text-lg font-semibold">마켓</h2>
      <div className="flex gap-2">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setActive(t.key)}
            className={`px-3 py-2 rounded-md text-sm border ${active === t.key ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'}`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="border border-white/10 rounded-md p-4 bg-black/20 min-h-[200px]">
        {active === 'spot' && (
          <div className="max-w-[720px]">
            <PairsBoard limit={30} exchange="binance" />
          </div>
        )}
        {active === 'kimchi' && <div>김프 프리미엄 뷰(준비중)</div>}
        {active === 'futures' && <div>선물 마켓 뷰(준비중)</div>}
      </div>
    </section>
  )
}

