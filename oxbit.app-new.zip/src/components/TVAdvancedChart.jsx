import React, { useEffect, useRef } from 'react'

// TradingView Advanced Chart wrapper
// Props: symbol (e.g., 'OANDA:NAS100USD', 'FOREXCOM:SPX500', 'TVC:DXY', 'BINANCE:BTCUSDT', 'CRYPTOCAP:BTC.D')
export default function TVAdvancedChart({ symbol = 'BINANCE:BTCUSDT', interval = '15', height = 520 }) {
  const idRef = useRef(`tv_${Math.random().toString(36).slice(2)}`)

  // load tv.js once
  useEffect(() => {
    if (window.TradingView) return
    const s = document.createElement('script')
    s.src = 'https://s3.tradingview.com/tv.js'
    s.async = true
    document.body.appendChild(s)
    return () => { try { document.body.removeChild(s) } catch {} }
  }, [])

  // create widget when tv.js ready or when symbol changes
  useEffect(() => {
    let mounted = true
    function create() {
      if (!mounted || !window.TradingView) return
      // clear previous content
      const el = document.getElementById(idRef.current)
      if (!el) return
      el.innerHTML = ''
      /* global TradingView */
      new window.TradingView.widget({
        container_id: idRef.current,
        autosize: true,
        symbol,
        interval,
        timezone: 'Asia/Seoul',
        theme: 'dark',
        style: '1',
        locale: 'kr',
        toolbar_bg: '#0F1114',
        hide_top_toolbar: false,
        hide_legend: false,
        enable_publishing: false,
        allow_symbol_change: false,
        withdateranges: true,
        studies: [],
      })
    }
    if (window.TradingView) create()
    else {
      const t = setInterval(() => {
        if (window.TradingView) { clearInterval(t); create() }
      }, 200)
      return () => clearInterval(t)
    }
    return () => { mounted = false }
  }, [symbol, interval])

  return (
    <div style={{ height }} className="w-full">
      <div id={idRef.current} style={{ width: '100%', height: '100%' }} />
    </div>
  )
}

