import React, { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { listBreaking, subscribeBreaking } from '../services/breakingService'

// 사용자용 속보 리스트: Supabase에서 불러오고 Realtime 반영
export default function BreakingNews({ limit = 50, compact = false }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let active = true
    async function load() {
      try {
        setLoading(true)
        const data = await listBreaking({ limit, status: 'public' })
        if (!active) return
        setItems(Array.isArray(data) ? data : [])
      } catch (e) {
        if (!active) return
        setError(e?.message || '로딩 오류가 발생했습니다.')
      } finally {
        if (active) setLoading(false)
      }
    }
    load()

    const unsub = subscribeBreaking((payload) => {
      if (!active) return
      const rec = payload?.new || payload?.record || payload
      if (!rec || rec.status !== 'public') return
      setItems((prev) => {
        const exists = prev.some((p) => p.id === rec.id)
        const next = exists ? prev.map((p) => (p.id === rec.id ? rec : p)) : [rec, ...prev]
        return next
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
          .slice(0, limit)
      })
    })

    return () => {
      active = false
      try { unsub?.() } catch {}
    }
  }, [limit])

  const content = useMemo(() => {
    if (loading) return <p className="p-4">불러오는 중…</p>
    if (error) return <p className="p-4 text-red-400">{error}</p>
    if (!items.length) return <p className="p-4 text-zinc-400">표시할 속보가 없습니다.</p>

    return (
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4">속보</h1>
        <p className="text-sm text-gray-500 mb-2">{new Date().toLocaleDateString()}</p>
        {items.map((item) => (
          <div key={item.id} className="mb-4 p-4 rounded bg-zinc-800 shadow-sm">
            <div className="flex items-center mb-2">
              <span className="text-sm bg-gray-200 px-2 py-1 rounded">{new Date(item.created_at).toLocaleTimeString()}</span>
              <h2 className="ml-3 font-semibold">{item.title}
                {item.important ? <span className="ml-2 align-middle text-xs text-red-400">중요</span> : null}
              </h2>
            </div>
            <p className="text-sm text-gray-700">{item.body && !compact ? item.body : null}</p>
            <div className="mt-2 flex items-center">
              {item.tags && item.tags.map(tag => (
                <span key={tag} className="mr-2 px-3 py-1 bg-blue-100 text-blue-800 text-xs rounded">{tag}</span>
              ))}
              <Link
                to={`/breaking/detail?id=${item.id}`}
                className="ml-auto px-3 py-1 bg-blue-500 text-white text-xs rounded"
              >
                Quick Order
              </Link>
            </div>
          </div>
        ))}
      </div>
    )
  }, [items, loading, error, compact])

  return (
    <section className="rounded-lg border border-zinc-800 bg-zinc-900">
      <header className="flex items-center justify-between border-b border-zinc-800 px-4 py-3">
        <h2 className="text-lg font-semibold">속보</h2>
        <Link to="/breaking" className="text-sm text-zinc-400 hover:text-white">
          더보기
        </Link>
      </header>
      {content}
    </section>
  )
}

