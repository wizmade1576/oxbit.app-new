import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchSpotTickers } from '../services/marketService'

export default function PopularCoins({ limit = 8 }) {
  const { data = [], isLoading } = useQuery({
    queryKey: ['popular:top-movers'],
    queryFn: () => fetchSpotTickers('binance'),
    staleTime: 30000,
    refetchInterval: 60000,
  })

  const movers = React.useMemo(() => {
    const arr = Array.isArray(data) ? [...data] : []
    arr.sort((a, b) => (isFinite(b.changePct) ? b.changePct : -Infinity) - (isFinite(a.changePct) ? a.changePct : -Infinity))
    return arr.slice(0, limit)
  }, [data, limit])

  return (
    <section className="rounded-xl border p-3 border-black/10 bg-white dark:border-white/10 dark:bg-[#0F1114]">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">인기 코인</h3>
        {isLoading && <span className="text-xs text-gray-500 dark:text-gray-400">업데이트 중</span>}
      </div>
      <div>
        <ol className="space-y-2">
          {movers.map((it, idx) => (
            <li key={it.symbol}>
              <div className="rounded-lg border px-3 py-2 border-black/10 bg-black/5 dark:border-white/10 dark:bg-black/10">
                <div className="flex items-center gap-3">
                  <span className="w-6 text-[11px] text-gray-500 dark:text-gray-400 text-center">#{idx + 1}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">{it.base}</div>
                      <div className={`text-xs font-medium ${isFinite(it.changePct) && it.changePct >= 0 ? 'text-red-500 dark:text-red-400' : 'text-blue-600 dark:text-blue-400'}`}>{isFinite(it.changePct) ? `${it.changePct.toFixed(2)}%` : '-'}</div>
                    </div>
                    <div className="text-[12px] text-gray-600 dark:text-gray-300">{isFinite(it.last) ? `$${Number(it.last).toLocaleString()}` : '-'}</div>
                  </div>
                </div>
              </div>
            </li>
          ))}
          {!movers.length && (
            <li className="text-sm text-gray-500 dark:text-gray-400">표시할 항목이 없습니다.</li>
          )}
        </ol>
      </div>
    </section>
  )
}

