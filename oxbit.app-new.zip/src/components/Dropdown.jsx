﻿import React, { useEffect, useMemo, useRef, useState } from 'react'

/**
 * Dark, fully custom dropdown (no native <select>)
 * - Keyboard: ArrowUp/Down to move, Enter to select, Esc/Tab to close
 * - Mouse: click to open/close, click option to select
 * - Closes on outside click and on blur
 * - Options: [{ value, label, icon }]
 */
export default function Dropdown({
  value,
  onChange,
  options = [],
  buttonClassName = '',
  menuClassName = '',
  optionClassName = '',
  placeholder = '선택',
  labelPrefix,
}) {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(-1)
  const btnRef = useRef(null)
  const menuRef = useRef(null)

  const idxByValue = useMemo(
    () => options.findIndex((o) => o.value === value),
    [options, value]
  )
  const current = idxByValue >= 0 ? options[idxByValue] : null

  const close = () => {
    setOpen(false)
    setActive(-1)
  }

  useEffect(() => {
    function onDocClick(e) {
      if (!open) return
      const t = e.target
      if (btnRef.current?.contains(t)) return
      if (menuRef.current?.contains(t)) return
      close()
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [open])

  useEffect(() => {
    if (!open) return
    setActive(idxByValue >= 0 ? idxByValue : 0)
  }, [open, idxByValue])

  const onKey = (e) => {
    if (!open) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault()
        setOpen(true)
      }
      return
    }
    if (e.key === 'Escape' || e.key === 'Tab') {
      e.preventDefault(); close(); return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setActive((i) => Math.min(options.length - 1, i + 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setActive((i) => Math.max(0, (i < 0 ? 0 : i - 1)))
    } else if (e.key === 'Enter') {
      e.preventDefault()
      if (active >= 0 && options[active]) {
        onChange?.(options[active].value)
        close()
      }
    }
  }

  useEffect(() => {
    if (!open) return
    const el = menuRef.current?.querySelector('[data-active="true"]')
    el?.scrollIntoView({ block: 'nearest' })
  }, [active, open])

  return (
    <div className="relative z-50 inline-block text-left">
      <button
        type="button"
        ref={btnRef}
        onClick={() => setOpen((v) => !v)}
        onKeyDown={onKey}
        className={[
          'inline-flex items-center gap-2 rounded-md border border-white/10 bg-[#0F1114] text-gray-100 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1D6FEA]',
          'shadow-sm hover:bg-white/5',
          buttonClassName,
        ].join(' ')}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        {labelPrefix && (
          <span className="hidden sm:inline text-xs text-gray-400">{labelPrefix}</span>
        )}
        {current?.icon && (
          <img src={current.icon} alt="" className="w-4 h-4 rounded-sm" />
        )}
        <span className="truncate">{current?.label || placeholder}</span>
        <svg viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-gray-400">
          <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.939l3.71-3.71a.75.75 0 111.06 1.062l-4.24 4.24a.75.75 0 01-1.06 0L5.25 8.29a.75.75 0 01-.02-1.08z" clipRule="evenodd"/>
        </svg>
      </button>

      {open && (
        <div
          ref={menuRef}
          className={[
            'absolute z-[100] mt-2 w-48 origin-top-right rounded-md border border-white/10 bg-[#0F1114] shadow-xl',
            'max-h-72 overflow-auto focus:outline-none',
            menuClassName,
          ].join(' ')}
          role="listbox"
          tabIndex={-1}
        >
          {options.map((o, i) => {
            const isActive = i === active
            const isSelected = o.value === value
            return (
              <button
                type="button"
                key={o.value}
                data-active={isActive}
                className={[
                  'w-full flex items-center gap-2 px-3 py-2 text-left text-sm',
                  isActive ? 'bg-white/10 text-white' : 'text-gray-200 hover:bg-white/5',
                  isSelected ? 'font-semibold' : 'font-normal',
                  optionClassName,
                ].join(' ')}
                onMouseEnter={() => setActive(i)}
                onClick={() => { onChange?.(o.value); close() }}
                role="option"
                aria-selected={isSelected}
              >
                {o.icon && <img src={o.icon} alt="" className="w-4 h-4 rounded-sm" />}
                <span className="truncate">{o.label}</span>
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}


