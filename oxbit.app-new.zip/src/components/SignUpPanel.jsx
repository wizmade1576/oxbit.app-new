﻿import React from 'react'
import LoginPromoCard from './LoginPromoCard.jsx'

export default function SignUpPanel() {
  return (
    <aside className="border border-white/10 rounded-xl bg-black/20 p-5">
      <LoginPromoCard message={'실시간 속보·뉴스를 가장 빠르게\n\nOxbit.app에 로그인하고 다양한 서비스와 혜택을 누리세요!'} />
    </aside>
  )
}
