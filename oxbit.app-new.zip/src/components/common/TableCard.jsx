import React from 'react'

export function Card({ title, children }) {
  return (
    <div className="rounded-xl border border-white/10 bg-[#0F1114]/80 backdrop-blur p-3 sm:p-4">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-200">{title}</h3>
      </div>
      {children}
    </div>
  )
}

export function ScrollableTable({ loading, columns, rows, rowClass, format = {} }) {
  return (
    <div className="relative">
      <div className="max-h-96 overflow-auto rounded-md border border-white/5">
        <table className="w-full text-xs sm:text-sm">
          <thead className="sticky top-0 bg-black/40 text-gray-400 backdrop-blur">
            <tr className="divide-x divide-white/5">
              {columns.map((c) => (
                <th key={c.key} className={`px-3 py-2 ${alignCls(c.align)}`}>{c.label}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {loading ? (
              [...Array(8)].map((_, i) => (
                <tr key={i} className="animate-pulse">
                  {columns.map((c) => (
                    <td key={c.key} className={`px-3 py-2 ${alignCls(c.align)}`}>
                      <div className="h-3 rounded bg-white/10" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              rows.map((r, i) => (
                <tr key={i} className={rowClass ? rowClass(r) : ''}>
                  {columns.map((c) => (
                    <td key={c.key} className={`px-3 py-2 ${alignCls(c.align)}`}>
                      {renderCell(r[c.key], c.key, format)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export function renderCell(value, key, format) {
  const fmt = format[key]
  return fmt ? fmt(value) : value
}

export function alignCls(align) {
  switch (align) {
    case 'right':
      return 'text-right'
    case 'center':
      return 'text-center'
    default:
      return 'text-left'
  }
}

export function formatNumber(v) {
  if (typeof v !== 'number' || !isFinite(v)) return '-'
  if (v >= 1_000_000_000) return (v / 1_000_000_000).toFixed(2) + 'B'
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(2) + 'M'
  if (v >= 1_000) return (v / 1_000).toFixed(2) + 'K'
  return v.toLocaleString()
}

export function formatCurrency(v) {
  if (typeof v !== 'number' || !isFinite(v)) return '-'
  try {
    return new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW', maximumFractionDigits: 0 }).format(v)
  } catch {
    return v.toLocaleString()
  }
}

