import React from 'react'
import { useQuery } from '@tanstack/react-query'

function useFundingLongShort(symbol = 'BTC') {
  return useQuery({
    queryKey: ['funding:l/s', symbol],
    // NOTE: Replace with real API later. Mocking for snapshot UI.
    queryFn: async () => {
      const base = symbol.toUpperCase()
      // pseudo-random but stable-ish per symbol
      const seed = base.charCodeAt(0) + Date.now() / 600000
      const rnd = (n) => Math.abs(Math.sin(seed * n))
      const longRatio = 40 + Math.round(rnd(1) * 60) // 40~100
      const shortRatio = Math.max(0, 100 - longRatio)
      const funding = (rnd(2) * 0.08 - 0.04) // -0.04% ~ +0.04%
      return { base, longRatio, shortRatio, funding }
    },
    staleTime: 60_000,
    refetchInterval: 120_000,
  })
}

export default function FundingSnapshot() {
  const [tab, setTab] = React.useState('BTC')
  const { data, isLoading, refetch, isFetching } = useFundingLongShort(tab)
  const bar = (pct, color) => (
    <div className={`h-2 rounded ${color}`} style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} />
  )

  const fundingText = data ? `${(data.funding * 100).toFixed(3)}%` : '-'
  const fundingTone = data && data.funding >= 0 ? 'text-emerald-300' : 'text-rose-300'

  return (
    <section className="rounded-xl border border-white/10 bg-[#13161A] p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {['BTC', 'ETH'].map((s) => (
            <button key={s} onClick={() => setTab(s)} className={`px-2.5 py-1 rounded text-xs border ${tab===s?'bg-white/10 text-white border-white/20':'text-gray-300 border-white/10 hover:bg-white/5'}`}>{s}</button>
          ))}
        </div>
        <button onClick={() => refetch()} disabled={isFetching} className="text-xs px-2 py-1 rounded border border-white/10 text-gray-300 hover:bg-white/5 disabled:opacity-50">새로고침</button>
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <div className="text-gray-400 text-xs">펀딩비</div>
          <div className={`text-white font-semibold ${fundingTone}`}>{isLoading ? '-' : fundingText}</div>
        </div>
        <div>
          <div className="text-gray-400 text-xs">롱/숏 비율</div>
          <div className="text-white font-semibold">{isLoading ? '-' : `${data.longRatio}% / ${data.shortRatio}%`}</div>
        </div>
      </div>

      <div className="w-full bg-white/5 rounded overflow-hidden">
        <div className="flex">
          {bar(isLoading ? 50 : data.longRatio, 'bg-emerald-500/70')}
          {bar(isLoading ? 50 : data.shortRatio, 'bg-rose-500/70')}
        </div>
      </div>
      <div className="flex justify-between text-[11px] text-gray-400">
        <span>Long</span>
        <span>Short</span>
      </div>
    </section>
  )
}

