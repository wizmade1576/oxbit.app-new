import React from "react";
import { useMarketTickers } from '../hooks/useMarketTickers'

export default function PairsBoard({ limit = 10, exchange = 'binance' }) {
  const { list, isLoading } = useMarketTickers({ exchange, limit, refetchMs: 60_000 })
  const getLogo = (symbol) => `https://cryptoicons.org/api/icon/${symbol.toLowerCase()}/64`;

  return (
    <div
      className="w-full rounded-xl overflow-hidden shadow-lg backdrop-blur-md border border-black/10 bg-white/90 text-gray-900 dark:border-gray-800 dark:bg-[#0d0f12]/95 dark:text-gray-100"
      style={{ width: "100%" }}
    >
      <div className="px-4 py-3 flex justify-between items-center border-b border-black/10 bg-black/5 dark:border-gray-800 dark:bg-[#14171c]">
        <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-200">실시간 마켓 (USDT)</h3>
        {isLoading && <span className="text-xs text-gray-600 dark:text-gray-500">업데이트 중</span>}
      </div>

      <table className="w-full text-sm">
        <thead className="bg-black/5 text-gray-500 dark:bg-[#14171c] dark:text-gray-400">
          <tr>
            <th className="text-left px-3 py-2 w-8">#</th>
            <th className="text-left px-3 py-2">종목</th>
            <th className="text-right px-3 py-2">가격(USDT)</th>
            <th className="text-right px-3 py-2">24H 변화</th>
          </tr>
        </thead>
        <tbody>
          {list.map((r, i) => {
            const up = r.changePct > 0;
            return (
              <tr key={r.symbol} className="transition-colors border-b border-black/5 hover:bg-black/5 dark:border-gray-800 dark:hover:bg-[#1b1f27]">
                <td className="px-3 py-2 text-gray-600 dark:text-gray-500">{i + 1}</td>
                <td className="px-3 py-2 flex items-center gap-2">
                  <img
                    src={getLogo(r.base)}
                    alt={r.base}
                    loading="lazy"
                    onError={(e) => { e.currentTarget.style.display = 'none'; }}
                    className="w-5 h-5 rounded-full"
                  />
                  <span className="font-medium text-gray-900 dark:text-gray-100">{r.base}/USDT</span>
                </td>
                <td className="px-3 py-2 text-right font-semibold text-gray-900 dark:text-gray-200">{isFinite(r.last) ? r.last.toLocaleString() : '-'}</td>
                <td className={`px-3 py-2 text-right font-bold ${up ? 'text-red-600 dark:text-red-400' : 'text-blue-600 dark:text-blue-400'}`}>{isFinite(r.changePct) ? `${r.changePct.toFixed(2)}%` : '-'}</td>
              </tr>
            );
          })}
          {!isLoading && list.length === 0 && (
            <tr>
              <td colSpan={4} className="text-center text-xs text-gray-600 dark:text-gray-500 py-4">표시할 데이터가 없습니다.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

