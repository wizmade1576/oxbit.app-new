import React from 'react'

import { getCoinIcon, getCoinIconCandidates } from '../services/iconService'
// �ѱ��� ���θ� (�ʿ�� Ȯ��)
const KOR_NAMES = {
  BTC: '��Ʈ����',
  ETH: '�̴�����',
  XRP: '����',
  SOL: '�ֶ�',
  DOGE: '��������',
  BNB: '���̳�������',
  ADA: '���̴�',
  AVAX: '�ƹ߶�ü',
  TRX: 'Ʈ��',
  LINK: 'ü�θ�ũ',
  MATIC: '������',
}

export default function CoinRow({ item, index, region = 'global', krwRate = 1350, view = 'table' }) {
  const [imgErr, setImgErr] = React.useState(false)
  const up = item.changePct > 0
  const price = isFinite(item.last) ? item.last : null
  const priceDisp = region === 'krw' ? (price != null ? (price * krwRate).toLocaleString() : '-') : (price != null ? price.toLocaleString() : '-')
  const volDisp = isFinite(item.quoteVolume) ? item.quoteVolume.toLocaleString() : '-'
  const changeDisp = isFinite(item.changePct) ? `${item.changePct.toFixed(2)}%` : '-'
  const baseUpper = (item.base || '').toUpperCase()
  const [srcIdx, setSrcIdx] = React.useState(0)
  const sources = React.useMemo(() => getCoinIconCandidates(baseUpper, { size: 64 }), [baseUpper])
  const logo = sources[srcIdx]
  React.useEffect(() => { setSrcIdx(0); setImgErr(false) }, [baseUpper])

  const domesticName = KOR_NAMES[baseUpper] ? `${KOR_NAMES[baseUpper]} (${baseUpper})` : baseUpper
  const symbolDisplay = (() => {
    if (region === 'krw') return domesticName
    const sym = String(item.symbol || '')
    if (sym.includes('-')) {
      const [b, q] = sym.split('-')
      return `${(b||baseUpper).toUpperCase()}/${(q||'USDT').toUpperCase()}`
    }
    const u = sym.toUpperCase()
    if (u.endsWith('USDT')) return `${baseUpper}/USDT`
    if (u.endsWith('USD')) return `${baseUpper}/USD`
    return `${baseUpper}/USDT`
  })()

  const FallbackIcon = ({ size = 20 }) => (
    <div
      className="inline-flex items-center justify-center rounded-full bg-white/10 text-gray-200"
      style={{ width: size, height: size, fontSize: Math.max(10, Math.floor(size * 0.45)) }}
      aria-label={`${baseUpper} icon`}
    >
      {baseUpper.slice(0, 2)}
    </div>
  )

  if (view === 'card') {
    return (
      <div className="rounded-lg border border-white/10 bg-[#111318] p-3 flex items-center justify-between hover:bg-white/5 transition">
        <div className="flex items-center gap-3 min-w-0">
          {!imgErr ? (
            <img src={logo} alt={item.base} className="w-7 h-7 rounded-full" onError={() => { if (srcIdx < (sources.length - 1)) setSrcIdx(i => i + 1); else setImgErr(true) }} />
          ) : (
            <FallbackIcon size={28} />
          )}
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-gray-100 truncate">{symbolDisplay}</span>
            </div>
            <div className="text-xs text-gray-400">24H {volDisp}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm font-semibold text-gray-100 whitespace-nowrap">{region === 'krw' ? `\ ${priceDisp}` : `$ ${priceDisp}`}</div>
          <div className={`text-xs font-bold ${up ? 'text-red-400' : 'text-blue-400'}`}>{changeDisp}</div>
        </div>
      </div>
    )
  }

  return (
    <tr className="hover:bg-[#1b1f27] transition-colors">
      <td className="px-3 py-2 text-gray-500">{index + 1}</td>
      <td className="px-3 py-2">
        <div className="flex items-center gap-2">
          {!imgErr ? (
            <img src={logo} alt={item.base} className="w-5 h-5 rounded-full" onError={() => { if (srcIdx < (sources.length - 1)) setSrcIdx(i => i + 1); else setImgErr(true) }} />
          ) : (
            <FallbackIcon size={20} />
          )}
          <div className="min-w-0">
            <div className="font-medium text-gray-100 truncate">{region==='krw' ? domesticName : symbolDisplay}</div>
          </div>
        </div>
      </td>
      <td className="px-3 py-2 text-right font-semibold text-gray-200 whitespace-nowrap">{region === 'krw' ? `\ ${priceDisp}` : `$ ${priceDisp}`}</td>
      <td className={`px-3 py-2 text-right font-bold whitespace-nowrap ${up ? 'text-red-400' : 'text-blue-400'}`}>{changeDisp}</td>
      <td className="px-3 py-2 text-right text-gray-300 whitespace-nowrap">{volDisp}</td>
    </tr>
  )
}

