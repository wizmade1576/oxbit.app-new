﻿import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchOpenInterestBinance } from '../../../services/futuresService'

export default function OpenInterest({ base = 'BTC' }) {
  const symbol = `${base}USDT`
  const { data, isLoading, isError, refetch, isFetching } = useQuery({
    queryKey: ['futures:oi', { symbol, period: '1h' }],
    queryFn: () => fetchOpenInterestBinance(symbol, '1h', 30),
    staleTime: 60_000,
    refetchInterval: 120_000,
  })

  const total = data?.latest ?? 0
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-white/10 bg-[#111318] p-4">
        <div className="text-xs text-gray-400">미결제약정 (종목: {base})</div>
        <div className="mt-1 text-lg font-semibold text-blue-300">총 {Math.round(total).toLocaleString()} USD</div>
      </div>

      <div className="rounded-xl border border-white/10 overflow-hidden bg-[#0F1114]">
        <div className="px-4 py-3 border-b border-white/10 text-sm text-gray-300">시계열</div>
        <div className="p-4 text-xs text-gray-400">표시는 간략화되어 있습니다.</div>
      </div>

      {isError && (
        <div className="text-sm text-rose-300">불러오기 실패
          <button onClick={() => refetch()} className="ml-2 px-2 py-1 rounded border border-white/10 text-gray-200 hover:bg-white/10 text-xs" disabled={isFetching}>다시 시도</button>
        </div>
      )}
    </div>
  )
}
