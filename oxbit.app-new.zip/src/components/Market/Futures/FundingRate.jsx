﻿import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchFundingRateBinance } from '../../../services/futuresService'

export default function FundingRate({ coin = 'BTC' }) {
  const symbol = `${coin}USDT`
  const { data, isLoading, isError, refetch, isFetching } = useQuery({
    queryKey: ['futures:funding', { symbol }],
    queryFn: () => fetchFundingRateBinance(symbol),
    staleTime: 60_000,
    refetchInterval: 120_000,
  })

  const rows = data ? [{ name: '바이낸스', rate: data.fundingRate }] : []
  const highest = rows[0] || { name: '-', rate: 0 }
  const lowest = rows[0] || { name: '-', rate: 0 }

  return (
    <div className="space-y-4">
      {/* Highest/Lowest cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <HiLoCard title="최고 자금조달비용" item={highest} tone="up" />
        <HiLoCard title="최저 자금조달비용" item={lowest} tone="down" />
      </div>

      <div className="rounded-xl border border-white/10 overflow-hidden bg-[#0F1114]">
        <div className="px-4 py-3 border-b border-white/10 text-sm text-gray-300">거래소별 자금조달비용</div>
        <table className="w-full text-sm">
          <thead className="bg-black/20 text-gray-400">
            <tr className="divide-x divide-white/5">
              <th className="px-3 py-2 text-left">거래소</th>
              <th className="px-3 py-2 text-right">자금조달비용</th>
              <th className="px-3 py-2 text-right">막대</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {rows.map((r) => (
              <tr key={r.name} className="hover:bg-white/5 transition-colors">
                <td className="px-3 py-2 text-gray-100 font-medium">{r.name}</td>
                <td className={`px-3 py-2 text-right font-semibold ${r.rate>=0?'text-emerald-300':'text-rose-300'}`}>{(r.rate*100).toFixed(3)}%</td>
                <td className="px-3 py-2 text-right">
                  <div className="h-3 w-40 rounded bg-white/5 inline-flex overflow-hidden">
                    <div className={`${r.rate>=0?'bg-emerald-500/80':'bg-rose-500/80'}`} style={{ width: `${Math.min(100, Math.abs(r.rate*100)*5)}%` }} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isError && (
        <div className="text-sm text-rose-300">불러오기 실패
          <button onClick={() => refetch()} className="ml-2 px-2 py-1 rounded border border-white/10 text-gray-200 hover:bg-white/10 text-xs" disabled={isFetching}>다시 시도</button>
        </div>
      )}
    </div>
  )
}

function HiLoCard({ title, item, tone }) {
  const color = tone==='up' ? 'text-emerald-300' : 'text-rose-300'
  return (
    <div className="rounded-xl border border-white/10 bg-[#111318] p-4">
      <div className="text-xs text-gray-400">{title}</div>
      <div className="mt-2 flex items-baseline justify-between">
        <div className="text-gray-100 font-semibold">{item.name}</div>
        <div className={`text-lg font-semibold ${color}`}>{(item.rate*100).toFixed(3)}%</div>
      </div>
    </div>
  )
}
