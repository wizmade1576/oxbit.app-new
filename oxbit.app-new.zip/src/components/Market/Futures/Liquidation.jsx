﻿import React, { useMemo } from 'react'

// Mock liquidation dataset (replace with API calls later)
// totals in KRW (billions), per-exchange breakdown
const MOCK = {
  '1h': {
    total: 42_000_000_000,
    long: 26_000_000_000, 
    short: 16_000_000_000,
    exchanges: [
      { name: '바이낸스', long: 12e9, short: 7e9 },
      { name: '바이빗', long: 7e9, short: 5e9 },
      { name: 'OKX', long: 4e9, short: 3e9 },
      { name: '비트겟', long: 3e9, short: 1e9 },
    ],
  },
  '4h': { total: 98e9, long: 62e9, short: 36e9, exchanges: [
    { name: '바이낸스', long: 28e9, short: 15e9 },
    { name: '바이빗', long: 16e9, short: 9e9 },
    { name: 'OKX', long: 12e9, short: 7e9 },
    { name: '비트겟', long: 6e9, short: 5e9 },
  ]},
  '12h': { total: 210e9, long: 130e9, short: 80e9, exchanges: [
    { name: '바이낸스', long: 60e9, short: 30e9 },
    { name: '바이빗', long: 34e9, short: 18e9 },
    { name: 'OKX', long: 20e9, short: 16e9 },
    { name: '비트겟', long: 16e9, short: 10e9 },
  ]},
  '24h': { total: 380e9, long: 230e9, short: 150e9, exchanges: [
    { name: '바이낸스', long: 110e9, short: 70e9 },
    { name: '바이빗', long: 60e9, short: 40e9 },
    { name: 'OKX', long: 36e9, short: 28e9 },
    { name: '비트겟', long: 24e9, short: 12e9 },
  ]},
}

export default function Liquidation({ timeframe = '1h' }) {
  const data = MOCK[timeframe] || MOCK['1h']
  const ratio = useMemo(() => {
    const t = data.long + data.short
    return t > 0 ? { long: (data.long / t) * 100, short: (data.short / t) * 100 } : { long: 0, short: 0 }
  }, [data])

  return (
    <div className="space-y-4">
      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <Card title="총 청산금액" value={data.total} tone="primary" />
        <Card title="롱 청산" value={data.long} tone="long" />
        <Card title="숏 청산" value={data.short} tone="short" />
        <div className="rounded-xl border border-white/10 bg-[#111318] p-4">
          <div className="text-xs text-gray-400 mb-2">롱/숏 비율</div>
          <div className="h-3 w-full rounded bg-white/5 overflow-hidden">
            <div className="h-full bg-emerald-500/70" style={{ width: `${ratio.long}%` }} />
          </div>
          <div className="mt-2 text-xs text-gray-300">롱 {ratio.long.toFixed(1)}% · 숏 {ratio.short.toFixed(1)}%</div>
        </div>
      </div>

      {/* Exchange breakdown */}
      <div className="rounded-xl border border-white/10 overflow-hidden bg-[#0F1114]">
        <div className="px-4 py-3 border-b border-white/10 text-sm text-gray-300">거래소별 청산 금액</div>
        <ul className="divide-y divide-white/10">
          {data.exchanges.map((ex) => {
            const total = ex.long + ex.short
            const l = total ? (ex.long / total) * 100 : 0
            const s = total ? (ex.short / total) * 100 : 0
            return (
              <li key={ex.name} className="p-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="text-gray-100 font-medium">{ex.name}</div>
                  <div className="text-gray-400">총 {Math.round(total).toLocaleString()} KRW</div>
                </div>
                <div className="mt-2 h-3 w-full rounded bg-white/5 overflow-hidden flex">
                  <div className="h-full bg-emerald-500/70" style={{ width: `${l}%` }} />
                  <div className="h-full bg-rose-500/70" style={{ width: `${s}%` }} />
                </div>
                <div className="mt-1 text-xs text-gray-400">롱 {Math.round(l)}% · 숏 {Math.round(s)}%</div>
              </li>
            )
          })}
        </ul>
      </div>

      {/* NOTE: Replace MOCK with real API calls and pass timeframe to server */}
    </div>
  )
}

function Card({ title, value, tone = 'primary' }) {
  const cls = tone === 'long' ? 'text-emerald-300' : tone === 'short' ? 'text-rose-300' : 'text-blue-300'
  return (
    <div className="rounded-xl border border-white/10 bg-[#111318] p-4">
      <div className="text-xs text-gray-400">{title}</div>
      <div className={`mt-2 text-lg font-semibold ${cls}`}>{Math.round(value).toLocaleString()} KRW</div>
    </div>
  )
}
