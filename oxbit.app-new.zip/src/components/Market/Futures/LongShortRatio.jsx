﻿import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchLongShortRatioBinance } from '../../../services/futuresService'

export default function LongShortRatio({ coin = 'BTC' }) {
  const symbol = `${coin}USDT`
  const { data, isLoading, isError, refetch, isFetching } = useQuery({
    queryKey: ['futures:lsr', { symbol, period: '1h' }],
    queryFn: () => fetchLongShortRatioBinance(symbol, '1h', 1),
    staleTime: 60_000,
    refetchInterval: 120_000,
  })
  const long = data ? data.long : 0.5
  const short = 1 - long

  return (
    <div className="space-y-4">
      {/* Overall bar */}
      <div className="rounded-xl border border-white/10 bg-[#111318] p-4">
        <div className="text-xs text-gray-400 mb-2">전체 롱/숏 비율 ({coin})</div>
        <div className="h-4 w-full rounded bg-white/5 overflow-hidden flex">
          <div className="h-full bg-emerald-500/80" style={{ width: `${long * 100}%` }} />
          <div className="h-full bg-rose-500/80" style={{ width: `${short * 100}%` }} />
        </div>
        <div className="mt-1 text-xs text-gray-300">롱 { (long*100).toFixed(1)}% · 숏 { (short*100).toFixed(1)}%</div>
      </div>

      <div className="text-xs text-gray-400">데이터 출처: Binance Global Long/Short Account Ratio</div>
      {isError && (
        <div className="text-sm text-rose-300">불러오기 실패
          <button onClick={() => refetch()} className="ml-2 px-2 py-1 rounded border border-white/10 text-gray-200 hover:bg-white/10 text-xs" disabled={isFetching}>다시 시도</button>
        </div>
      )}
    </div>
  )
}
