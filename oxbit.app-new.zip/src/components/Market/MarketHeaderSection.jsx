import React from 'react'
import { NavLink } from 'react-router-dom'

// Segmented main tabs for the Market section
// Routes are kept to existing pages
const TABS = [
  { key: 'coin', to: '/market/spot-kr', label: '코인' },
  { key: 'theme', to: '/market/index', label: '테마' },
  { key: 'kimchi', to: '/market/kimchi', label: '김프' },
  { key: 'schedule', to: '/market/schedule', label: '일정' },
  { key: 'futures', to: '/market/futures', label: '선물' },
]

export default function MarketHeaderSection({ issueCount = 0, issueText = '', className = '' }) {
  return (
    <div className={`space-y-3 ${className}`}>
      <h1 className="text-xl font-bold text-white">마켓</h1>

      {/* Issue ticker pill */}
      <div className="w-full">
        <div className="inline-flex items-center gap-3 rounded-full bg-white/5 border border-white/10 px-4 py-2 text-sm text-gray-200">
          <span className="text-gray-300">이슈</span>
          <span className="px-2 py-0.5 rounded-full bg-[#1D6FEA] text-white text-xs font-semibold">{issueCount}</span>
          <span className="truncate max-w-[70vw] sm:max-w-none text-gray-100">{issueText || '마켓 이슈가 여기에 표시됩니다.'}</span>
        </div>
      </div>

      {/* Segmented tabs */}
      <div className="flex gap-6 border-b border-white/10 text-sm">
        {TABS.map((t) => (
          <NavLink
            key={t.key}
            to={t.to}
            className={({ isActive }) =>
              `relative py-2 text-gray-300 hover:text-white ${isActive ? 'text-white' : ''}`
            }
          >
            {({ isActive }) => (
              <>
                <span>{t.label}</span>
                <span
                  className={`absolute left-0 right-0 -bottom-px h-[2px] ${
                    isActive ? 'bg-[#1D6FEA]' : 'bg-transparent'
                  }`}
                />
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  )
}

