import React from 'react'
import Dropdown from '../../components/Dropdown.jsx'

export default function CoinFilterBar({
  onReset,
  search,
  onSearch,
  exchangeValue,
  onExchangeChange,
  exchangeOptions = [],
  className = '',
}) {
  return (
    <div className={`flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between ${className}`}>
      <div className="flex items-center gap-2">
        <button
          onClick={onReset}
          className="px-3 py-1.5 rounded-full bg-white/10 text-white text-sm border border-white/15"
        >
          전체
        </button>
        <div className="relative">
          <input
            value={search}
            onChange={(e) => onSearch?.(e.target.value)}
            placeholder="코인검색"
            className="pl-3 pr-9 py-2 rounded-full bg-white/5 border border-white/10 text-sm text-gray-100 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-white/20"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">🔍</div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Dropdown
          value={exchangeValue}
          onChange={onExchangeChange}
          options={exchangeOptions}
          buttonClassName="rounded-full justify-between"
        />
      </div>
    </div>
  )
}

