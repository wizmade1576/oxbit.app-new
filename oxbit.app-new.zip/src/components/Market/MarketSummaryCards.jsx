import React from 'react'

export default function MarketSummaryCards({ up = 0, down = 0, className = '' }) {
  return (
    <div className={`grid grid-cols-2 gap-3 ${className}`}>
      <div className="rounded-xl border border-white/10 bg-[#0F1114] p-4">
        <div className="text-2xl font-bold text-emerald-300">{up.toLocaleString()}</div>
        <div className="text-xs text-gray-300 mt-1">코인이 상승중이네요!</div>
      </div>
      <div className="rounded-xl border border-white/10 bg-[#0F1114] p-4">
        <div className="text-2xl font-bold text-rose-300">{down.toLocaleString()}</div>
        <div className="text-xs text-gray-300 mt-1">코인이 하락중이네요!</div>
      </div>
    </div>
  )
}

