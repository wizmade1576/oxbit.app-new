import React from 'react'

export default function ScheduleItem({ item }) {
  const [open, setOpen] = React.useState(false)
  const d = new Date(item.date)
  const day = String(d.getDate()).padStart(2, '0')
  const weekday = item.day || ['일요일','월요일','화요일','수요일','목요일','금요일','토요일'][d.getDay()]

  return (
    <article className="rounded-xl border border-white/10 bg-[#111318] p-4 hover:bg-white/5 transition">
      <div className="flex items-start gap-4">
        {/* Date box */}
        <div className="flex flex-col items-center justify-center w-16 shrink-0 rounded-lg bg-white/5 border border-white/10 py-2">
          <div className="text-xl font-bold text-blue-300 leading-none">{day}</div>
          <div className="text-[11px] text-gray-400 mt-1">{weekday}</div>
        </div>

        {/* Content */}
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <button onClick={()=>setOpen(o=>!o)} className="text-left flex-1">
              <h4 className="text-gray-100 font-semibold leading-snug truncate">{item.title}</h4>
            </button>
            {item.link && (
              <a href={item.link} target="_blank" rel="noopener noreferrer" title={item.source || '바로가기'}
                 className="text-gray-300 hover:text-white">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                  <path d="M13.5 4.5h6v6h-1.5V7.06L12.28 12.8l-1.06-1.06 5.72-5.72H13.5V4.5z"/>
                  <path d="M19.5 19.5h-15v-15H12V3H3a1.5 1.5 0 0 0-1.5 1.5v15A1.5 1.5 0 0 0 3 21h15a1.5 1.5 0 0 0 1.5-1.5v-9H19.5v9z"/>
                </svg>
              </a>
            )}
          </div>
          {/* Tags */}
          <div className="mt-2 flex flex-wrap gap-2 text-xs">
            {Array.isArray(item.tags) && item.tags.map((t) => (
              <span key={t} className="rounded-full bg-white/5 border border-white/10 px-2 py-1 text-gray-300">{t}</span>
            ))}
          </div>

          {open && (
            <div className="mt-3 space-y-2 text-sm text-gray-300">
              {item.desc && <p className="leading-relaxed">{item.desc}</p>}
              {item.memo && <p className="leading-relaxed text-gray-400">메모: {item.memo}</p>}
              {Array.isArray(item.attachments) && item.attachments.length > 0 && (
                <div className="pt-1">
                  <div className="text-xs text-gray-400 mb-1">첨부</div>
                  <ul className="list-disc list-inside space-y-1">
                    {item.attachments.map((a, idx) => (
                      <li key={idx}>
                        <a href={a.url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">
                          {a.label || a.url}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </article>
  )
}

