import React, { useEffect, useMemo, useState } from 'react'

const FALLBACK = [
  { date: '2025-11-20', day: '목', title: 'BTC 옵션 만기 (대규모)', category: 'major', link: 'https://deribit.com' },
  { date: '2025-11-22', day: '토', title: '바이낸스 상장투표 4차 라운드 시작', category: 'exchange', link: 'https://www.binance.com' },
  { date: '2025-11-25', day: '화', title: 'SOL 메인넷 업그레이드 v1.19 (예정)', category: 'project', link: 'https://status.solana.com' },
  { date: '2025-11-27', day: '목', title: 'ETH Dencun 코어개발자 콜', category: 'major', link: 'https://github.com/ethereum/pm' },
  { date: '2025-12-02', day: '화', title: 'OKX 상장 이벤트 · 수수료 할인', category: 'exchange', link: 'https://www.okx.com' },
  { date: '2025-12-05', day: '금', title: '인플루언서 트레이딩 대회 (커뮤니티)', category: 'event' },
  { date: '2025-12-10', day: '수', title: 'CARDANO 네트워크 파라미터 변경', category: 'project' },
  { date: '2025-12-18', day: '목', title: 'FED FOMC 의사록 공개', category: 'major' },
]

const CAT = {
  major: '#주요이슈',
  project: '#프로젝트',
  exchange: '#거래소',
  event: '#이벤트',
}

function bySoonest(a, b) {
  return new Date(a.date).getTime() - new Date(b.date).getTime()
}

export default function SidebarSchedule({ max = 7 }) {
  const [items, setItems] = useState([])

  useEffect(() => {
    let alive = true
    async function load() {
      try {
        const p = new URLSearchParams({ sort: 'asc', page: '1', pageSize: '200' })
        const res = await fetch(`/api/schedule?${p.toString()}`)
        const data = await res.json().catch(() => null)
        const arr = Array.isArray(data?.items) ? data.items : FALLBACK
        if (!alive) return
        setItems(arr)
      } catch {
        if (alive) setItems(FALLBACK)
      }
    }
    load()
    const id = setInterval(load, 60_000 * 10)
    return () => { alive = false; clearInterval(id) }
  }, [])

  const soon = useMemo(() => {
    const now = Date.now()
    const future = (items || []).filter((it) => {
      const t = new Date(it.date).getTime()
      return isFinite(t) && t >= now - 24*60*60*1000 // allow today
    }).sort(bySoonest)
    return future.slice(0, max)
  }, [items, max])

  // Group by month label for section headers
  const groups = useMemo(() => {
    const out = []
    let cur = null
    soon.forEach((it) => {
      const d = new Date(it.date)
      const label = `${d.getFullYear()}년 ${d.getMonth() + 1}월`
      if (!cur || cur.label !== label) {
        cur = { label, items: [] }
        out.push(cur)
      }
      cur.items.push(it)
    })
    return out
  }, [soon])

  return (
    <section className="rounded-xl border border-white/10 bg-[#14171c]/70 backdrop-blur-md">
      <header className="flex items-center gap-2 px-3 py-3 border-b border-white/10">
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-emerald-400">
          <path d="M7 2a1 1 0 0 1 1 1v1h8V3a1 1 0 1 1 2 0v1h1.5A2.5 2.5 0 0 1 22 6.5v13A2.5 2.5 0 0 1 19.5 22h-15A2.5 2.5 0 0 1 2 19.5v-13A2.5 2.5 0 0 1 4.5 4H6V3a1 1 0 0 1 1-1Zm12.5 7.5h-15v10a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1v-10Z"/>
        </svg>
        <h3 className="text-sm font-semibold text-gray-100">코인 주요 일정</h3>
      </header>
      <ul className="divide-y divide-white/10">
        {groups.map((g) => (
          <React.Fragment key={g.label}>
            <li className="px-3 pt-4 pb-2 text-xs font-semibold text-gray-300">{g.label}</li>
            {g.items.map((it) => {
              const dt = new Date(it.date)
              const month = dt.getMonth() + 1
              const day = dt.getDate()
              const weekday = it.day || ['일','월','화','수','목','금','토'][dt.getDay()]
              return (
                <li key={`${it.date}-${it.title}`} className="flex items-start gap-4 px-3 py-3">
                  <div className="shrink-0">
                    <div className="flex flex-col items-center justify-center w-14 h-14 rounded-lg bg-white/5 border border-white/10">
                      <div className="text-xl font-bold text-gray-100 leading-none">{String(day).padStart(2,'0')}</div>
                      <div className="text-[11px] text-gray-500 leading-none mt-1">{weekday}</div>
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] text-gray-400 mb-1">{CAT[it.category] || '#기타'}</div>
                    <div className="text-sm text-gray-100 truncate" title={it.title}>{it.title}</div>
                  </div>
                  {it.link && (
                    <a href={it.link} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-gray-200" title="바로가기">
                      <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                        <path d="M13.5 4.5h6v6h-1.5V7.06L12.28 12.8l-1.06-1.06 5.72-5.72H13.5V4.5z"/>
                        <path d="M19.5 19.5h-15v-15H12V3H3a1.5 1.5 0 0 0-1.5 1.5v15A1.5 1.5 0 0 0 3 21h15a1.5 1.5 0 0 0 1.5-1.5v-9H19.5v9z"/>
                      </svg>
                    </a>
                  )}
                </li>
              )
            })}
          </React.Fragment>
        ))}
        {!soon.length && (
          <li className="px-3 py-6 text-sm text-gray-400 text-center">표시할 일정이 없습니다.</li>
        )}
      </ul>
    </section>
  )
}
