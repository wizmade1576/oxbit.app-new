import React from 'react'

const TABS = [
  { key: 'all', label: '전체' },
  { key: 'major', label: '주요 이슈' },
  { key: 'project', label: '프로젝트' },
  { key: 'exchange', label: '거래소' },
  { key: 'event', label: '이벤트' },
]

export default function FilterTabs({ value = 'all', onChange }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {TABS.map((t) => (
        <button
          key={t.key}
          type="button"
          onClick={() => onChange?.(t.key)}
          className={`px-3 py-2 rounded-md text-sm border ${value === t.key ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'}`}
        >
          {t.label}
        </button>
      ))}
    </div>
  )
}

