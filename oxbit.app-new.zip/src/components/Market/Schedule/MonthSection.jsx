import React from 'react'
import ScheduleItem from './ScheduleItem.jsx'

export default function MonthSection({ monthLabel, items }) {
  return (
    <section className="space-y-3">
      <h3 className="text-sm font-semibold text-gray-300 px-1">{monthLabel}</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {items.map((it) => (
          <ScheduleItem key={`${it.date}-${it.title}`} item={it} />
        ))}
      </div>
    </section>
  )
}

