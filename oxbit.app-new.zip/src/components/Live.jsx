import React, { useEffect, useState } from 'react'
import LiveFeed from '../components/LiveFeed.jsx'
import FuturesTrades from './whale/FuturesTrades.jsx'
import FuturesLiquidations from './whale/FuturesLiquidations.jsx'
import SpotBuys from './whale/SpotBuys.jsx'
import SpotSells from './whale/SpotSells.jsx'

export default function Live() {
  const [tab, setTab] = useState('live') // 'live' | 'whale'

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-2">
        {[
          { key: 'live', label: '라이브' },
          { key: 'whale', label: '고래추적' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-3 py-2 rounded-md text-sm border ${
              tab === t.key ? 'bg-[#1D6FEA] border-[#1D6FEA] text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'live' ? (
        <>
          <LiveSnapshot />
          <div className="mt-6">
            <LiveFeed />
          </div>
        </>
      ) : (
        <WhaleTracker />
      )}
    </section>
  )
}

function LiveSnapshot() {
  const bgUrl = "/live-snapshot.png"
  const [loaded, setLoaded] = useState(false)
  useEffect(() => {
    const img = new Image()
    img.onload = () => setLoaded(true)
    img.onerror = () => setLoaded(false)
    img.src = bgUrl
  }, [])

  return (
    <div className="relative overflow-hidden rounded-xl border border-white/10">
      <div
        className={`min-h-[50vh] sm:min-h-[60vh] bg-center bg-cover ${loaded ? '' : 'bg-gradient-to-br from-slate-800/40 to-slate-900/60'}`}
        style={loaded ? { backgroundImage: `url(${bgUrl})` } : undefined}
      />
      <div className="absolute inset-0 bg-black/40" />
      <div className="absolute inset-0 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="text-xs uppercase tracking-wider text-gray-300">Live Snapshot</div>
          <h3 className="mt-2 text-2xl font-bold text-white">실시간 포지션 트래커 (Live Snapshot)</h3>
          <p className="mt-2 text-sm text-gray-300">화면은 모바일/태블릿/PC 환경에 자동 응답합니다.</p>
        </div>
      </div>
    </div>
  )
}

function WhaleTracker() {
  const [sub, setSub] = useState('futures') // 'futures' | 'spot'
  return (
    <section className="space-y-3">
      <div className="flex items-center gap-2">
        {[
          { key: 'futures', label: '선물 고래' },
          { key: 'spot', label: '현물 고래' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setSub(t.key)}
            className={`px-3 py-2 rounded-md text-sm border ${
              sub === t.key ? 'bg-white/10 border-white/20 text-white' : 'border-white/10 text-gray-300 hover:bg-white/10'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {sub === 'futures' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <FuturesTrades />
          <FuturesLiquidations />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SpotBuys />
          <SpotSells />
        </div>
      )}
    </section>
  )
}

// Whale table sections are now extracted into components/whale/*

function Card({ title, children }) {
  return (
    <div className="rounded-xl border border-white/10 bg-[#0F1114]/80 backdrop-blur p-3 sm:p-4">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-200">{title}</h3>
      </div>
      {children}
    </div>
  )
}

function ScrollableTable({ loading, columns, rows, rowClass, format = {} }) {
  return (
    <div className="relative">
      <div className="max-h-96 overflow-auto rounded-md border border-white/5">
        <table className="w-full text-xs sm:text-sm">
          <thead className="sticky top-0 bg-black/40 text-gray-400 backdrop-blur">
            <tr className="divide-x divide-white/5">
              {columns.map((c) => (
                <th key={c.key} className={`px-3 py-2 ${alignCls(c.align)}`}>{c.label}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {loading ? (
              [...Array(8)].map((_, i) => (
                <tr key={i} className="animate-pulse">
                  {columns.map((c) => (
                    <td key={c.key} className={`px-3 py-2 ${alignCls(c.align)}`}>
                      <div className="h-3 rounded bg-white/10" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              rows.map((r, i) => (
                <tr key={i} className={rowClass ? rowClass(r) : ''}>
                  {columns.map((c) => (
                    <td key={c.key} className={`px-3 py-2 ${alignCls(c.align)}`}>
                      {renderCell(r[c.key], c.key, format)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function renderCell(value, key, format) {
  const fmt = format[key]
  return fmt ? fmt(value) : value
}

function alignCls(align) {
  switch (align) {
    case 'right':
      return 'text-right'
    case 'center':
      return 'text-center'
    default:
      return 'text-left'
  }
}

function formatNumber(v) {
  if (typeof v !== 'number' || !isFinite(v)) return '-'
  if (v >= 1_000_000_000) return (v / 1_000_000_000).toFixed(2) + 'B'
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(2) + 'M'
  if (v >= 1_000) return (v / 1_000).toFixed(2) + 'K'
  return v.toLocaleString()
}

function formatCurrency(v) {
  if (typeof v !== 'number' || !isFinite(v)) return '-'
  try {
    return new Intl.NumberFormat('ko-KR', { style: 'currency', currency: 'KRW', maximumFractionDigits: 0 }).format(v)
  } catch {
    return v.toLocaleString()
  }
}
