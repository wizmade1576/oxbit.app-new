import React, { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Community() {
  const navigate = useNavigate()

  // 인기글 (1~10)
  const topPosts = useMemo(
    () => [
      { id: 1, rank: 1, cat: '이슈', time: '1시간 전', title: 'BTC 급락 후 반등, 핵심 지지/저항 레벨 정리', comments: 132 },
      { id: 2, rank: 2, cat: '자유', time: '2시간 전', title: '포지션 리스크 체감 지표 공유', comments: 89 },
      { id: 3, rank: 3, cat: '이벤트', time: '3시간 전', title: '[이벤트] 신규 가입 보너스 + 초대 보상', comments: 67 },
      { id: 4, rank: 4, cat: '인플루언서', time: '4시간 전', title: '파생 포지션으로 본 고래 흐름(주간)', comments: 41 },
      { id: 5, rank: 5, cat: '자유', time: '5시간 전', title: '김프/역프 가속도: 국내/해외 가격차', comments: 58 },
      { id: 6, rank: 6, cat: '이슈', time: '6시간 전', title: 'ETF 자금 유입/유출 현황 체크포인트', comments: 36 },
      { id: 7, rank: 7, cat: '자유', time: '7시간 전', title: '선물/현물 차이 간단 요약', comments: 77 },
      { id: 8, rank: 8, cat: '인플루언서', time: '8시간 전', title: '메이저 5개 코인 기술 관점', comments: 24 },
      { id: 9, rank: 9, cat: '이벤트', time: '9시간 전', title: '주말 출석체크 챌린지 진행', comments: 52 },
      { id: 10, rank: 10, cat: '자유', time: '10시간 전', title: '출금지연 이슈 정리 및 대응', comments: 19 },
    ],
    []
  )

  // 피드 기본 데이터
  const feedBase = useMemo(
    () => [
      { id: 'p1', nick: '코인비둘기', avatar: 'https://i.pravatar.cc/72?img=12', time: '방금 전', title: '오늘 FOMC 이후 현금 비중 어떻게?', excerpt: '손절, 분할 진입, 현물/선물 비중입니다. 전략 공유해요.', comments: 23, likes: 112, cat: '자유' },
      { id: 'p2', nick: '체인리포트', avatar: 'https://i.pravatar.cc/72?img=33', time: '13분 전', title: 'SOL 거래량 급등 원인', excerpt: 'dApp 거래량 급증 + 메인넷 이슈.', comments: 11, likes: 78, cat: '이슈' },
      { id: 'p3', nick: '차트냥이', avatar: 'https://i.pravatar.cc/72?img=45', time: '31분 전', title: '단기 모멘텀 코인 3선(개인 의견)', excerpt: '투자 권유 아님. 리스크 관리 필수.', comments: 56, likes: 214, cat: '인플루언서' },
      { id: 'p4', nick: '운영요정', avatar: 'https://i.pravatar.cc/72?img=4', time: '1시간 전', title: '[이벤트] 주간 출석 보너스 향상', excerpt: '지속 출석 시 추가 보너스 지급!', comments: 9, likes: 63, cat: '이벤트' },
    ],
    []
  )

  const [active, setActive] = useState('all')
  const [loading, setLoading] = useState(true)
  const [list, setList] = useState([])
  const [visible, setVisible] = useState(8)
  const sentinelRef = useRef(null)

  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => {
      setList(feedBase.concat(feedBase.map((p, i) => ({ ...p, id: p.id + '_d' + i, time: '어제', comments: p.comments + 2, likes: p.likes + 5 }))))
      setLoading(false)
    }, 200)
    return () => clearTimeout(t)
  }, [feedBase])

  useEffect(() => {
    if (!sentinelRef.current) return
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) setVisible((v) => Math.min(v + 6, filtered.length)) })
    }, { rootMargin: '200px' })
    io.observe(sentinelRef.current)
    return () => io.disconnect()
  }, [])

  const filtered = useMemo(() => {
    switch (active) {
      case 'hot': return list.filter((p) => p.likes >= 100)
      case 'event': return list.filter((p) => p.cat === '이벤트')
      case 'influencer': return list.filter((p) => p.cat === '인플루언서')
      default: return list
    }
  }, [list, active])

  const leftTop = topPosts.slice(0, 5)
  const rightTop = topPosts.slice(5, 10)

  return (
    <section className="space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl font-bold text-white">커뮤니티</h1>
        <p className="text-sm text-gray-400">코인 뉴스·토론, 트레이더 인사이트 한곳에</p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TopPostsColumn title="인기글 1~5" posts={leftTop} onOpen={(id)=>navigate(`/community/post/${id}`)} />
        <TopPostsColumn title="인기글 6~10" posts={rightTop} onOpen={(id)=>navigate(`/community/post/${id}`)} />
      </section>

      <section className="rounded-xl border border-white/10 bg-[#0F1114] p-4">
        <div className="h-20 rounded-md bg-gradient-to-r from-blue-600/30 to-cyan-500/30 flex items-center justify-center text-sm text-gray-200">광고 배너 (970x90 / 반응형)</div>
      </section>

      <div className="sticky top-16 z-40 bg-[#0F1114]/80 backdrop-blur border-b border-white/5">
        <div className="py-3 flex items-center gap-2">
          {[
            { key: 'all', label: '전체' },
            { key: 'hot', label: 'HOT' },
            { key: 'event', label: '이벤트' },
            { key: 'influencer', label: '트레이더' },
          ].map((t) => (
            <button key={t.key} onClick={() => { setActive(t.key); setVisible(8) }} className={`px-3 py-1.5 rounded-full text-sm border ${active===t.key?'bg-[#1D6FEA] border-[#1D6FEA] text-white':'border-white/10 text-gray-300 hover:bg-white/10'}`}>{t.label}</button>
          ))}
        </div>
      </div>

      <section className="space-y-3">
        {loading ? (
          <SkeletonList count={6} />
        ) : (
          <>
            {filtered.slice(0, visible).map((p) => (
              <PostCard key={p.id} post={p} onOpen={(id)=>navigate(`/community/post/${id}`, { state: { post: p } })} />
            ))}
            <div ref={sentinelRef} className="h-10" />
            {visible < filtered.length && (
              <div className="text-center">
                <button onClick={() => setVisible((v) => Math.min(v + 6, filtered.length))} className="px-4 py-2 rounded-md border border-white/10 text-sm text-gray-200 hover:bg-white/10">더 보기</button>
              </div>
            )}
            {!filtered.length && <div className="text-sm text-gray-400 py-8 text-center">표시할 게시글이 없습니다.</div>}
          </>
        )}
      </section>
    </section>
  )
}

function TopPostsColumn({ title, posts, onOpen }) {
  return (
    <div className="rounded-xl border border-white/10 bg-[#0F1114] p-3">
      <div className="px-1 pb-2 text-sm text-gray-400">{title}</div>
      <ul className="space-y-1">
        {posts.map((p) => (
          <li key={p.id} onClick={() => onOpen?.(p.id)} className="group flex items-center gap-3 rounded-md px-2 py-2 hover:bg-white/5 transition-colors cursor-pointer" role="button" tabIndex={0}>
            <div className="w-6 shrink-0 text-center font-bold text-gray-300 group-hover:text-white">{p.rank}</div>
            <span className="shrink-0 px-2 py-0.5 rounded-full text-[11px] border border-white/10 text-gray-300">{p.cat}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm text-gray-100 group-hover:text-white">{p.title}</div>
              <div className="text-[11px] text-gray-400">{p.time}</div>
            </div>
            <div className="shrink-0 text-xs text-gray-400">댓글 {p.comments}</div>
          </li>
        ))}
      </ul>
    </div>
  )
}

function PostCard({ post, onOpen }) {
  return (
    <article onClick={() => onOpen?.(post.id)} className="rounded-xl border border-white/10 bg-[#0F1114] p-3 hover:bg-white/5 transition-colors cursor-pointer">
      <div className="flex items-start gap-3">
        <img src={post.avatar} alt={post.nick} className="w-10 h-10 rounded-full object-cover" onError={(e) => { e.currentTarget.src = 'https://i.pravatar.cc/72?img=5' }} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <div className="text-sm font-medium text-gray-100">{post.nick}</div>
            <span className="text-[11px] text-gray-400">· {post.time}</span>
            <span className="ml-auto hidden sm:inline text-[11px] px-2 py-0.5 rounded-full border border-white/10 text-gray-300">{post.cat}</span>
          </div>
          <h3 className="mt-1 text-gray-100 font-semibold">{post.title}</h3>
          {post.excerpt && <p className="mt-1 text-sm text-gray-300 line-clamp-2">{post.excerpt}</p>}
          <div className="mt-2 flex items-center gap-3 text-xs text-gray-400"><span>댓글 {post.comments}</span><span>좋아요 {post.likes}</span></div>
        </div>
      </div>
    </article>
  )
}

function SkeletonList({ count = 5 }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="rounded-xl border border-white/10 bg-[#0F1114] p-3">
          <div className="flex items-start gap-3 animate-pulse">
            <div className="w-10 h-10 rounded-full bg-white/10" />
            <div className="min-w-0 flex-1 space-y-2">
              <div className="h-3 w-1/5 bg-white/10 rounded" />
              <div className="h-4 w-3/5 bg-white/10 rounded" />
              <div className="h-3 w-4/5 bg-white/10 rounded" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

