import React from 'react'

// Responsive banner: 320x100 (mobile), 728x90 (md), 970x90 (lg)
// Placeholder block with a clear "광고" label. Replace inner content with your ad tag.
export default function AdBanner({ slot = 'default', className = '' }) {
  return (
    <div className={`w-full flex justify-center ${className}`} aria-label={`ad-slot-${slot}`}>
      <div
        className="
          relative w-full
          max-w-[320px] h-[100px]
          md:max-w-[728px] md:h-[90px]
          lg:max-w-[970px] lg:h-[90px]
          rounded-md border border-white/10 bg-white/5
          flex items-center justify-center text-xs text-gray-300
        "
      >
        <span className="absolute top-1 left-2 rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-gray-300">광고</span>
        <span className="opacity-80">970×90 / 728×90 / 320×100 (placeholder)</span>
      </div>
    </div>
  )
}

