﻿import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { fetchUsdKrwRate, buildKimpRows } from '../services/kimpService.js'

function useKimpSummary() {
  return useQuery({
    queryKey: ['kimp:summary', { kr: 'upbit', gl: 'binance' }],
    queryFn: async () => {
      const rate = await fetchUsdKrwRate()
      const rows = await buildKimpRows({ rate, kr: 'upbit', gl: 'binance' })
      return { rate, rows }
    },
    staleTime: 60_000,
    refetchInterval: 120_000,
  })
}

export default function KimpSummary({ limit = 6, cols = 1 }) {
  const { data, isLoading, isError, refetch, isFetching } = useKimpSummary()
  const rate = data?.rate || null
  const rows = Array.isArray(data?.rows) ? data.rows : []
  const list = rows
    .filter((r) => Number.isFinite(r.kimpPct))
    .sort((a, b) => Math.abs(b.kimpPct || 0) - Math.abs(a.kimpPct || 0))
    .slice(0, limit)

  return (
    <section className="rounded-xl border border-white/10 bg-[#13161A] p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm text-gray-300">김프 상위 종목</h3>
        <div className="text-xs text-gray-400">환율(USD/KRW): {rate ? Number(rate).toFixed(2) : '-'}</div>
      </div>

      {isError ? (
        <div className="text-sm text-rose-300">
          불러오기 실패
          <button onClick={() => refetch()} className="ml-2 px-2 py-1 rounded border border-white/10 text-gray-200 hover:bg-white/10 text-xs" disabled={isFetching}>다시 시도</button>
        </div>
      ) : (
        <div className={`grid gap-2 ${cols > 1 ? 'md:grid-cols-2' : 'grid-cols-1'}`}>
          {(isLoading ? Array.from({ length: limit }) : list).map((r, i) => (
            <div key={isLoading ? i : r.base} className="rounded-lg bg-white/5 border border-white/10 px-3 py-2 flex items-center justify-between">
              {isLoading ? (
                <div className="w-full animate-pulse">
                  <div className="h-4 w-1/3 bg-white/10 rounded mb-1" />
                  <div className="h-3 w-2/3 bg-white/10 rounded" />
                </div>
              ) : (
                <>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-gray-100 truncate">{r.base}</div>
                    <div className="text-[11px] text-gray-400">국내 KRW: {Number(r.krPrice || 0).toLocaleString()}  · 글로벌 KRW: {Number(r.usPrice || 0).toLocaleString()}</div>
                  </div>
                  <div className={`text-sm font-semibold ${r.kimpPct >= 0 ? 'text-rose-400' : 'text-blue-400'}`}>{Number(r.kimpPct).toFixed(2)}%</div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  )
}


