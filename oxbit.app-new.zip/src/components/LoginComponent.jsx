import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuthStore } from '../store/useAuthStore'

export default function LoginComponent() {
  const { signInWithPassword, signOut, user } = useAuthStore()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')

  const onSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSending(true)
    try {
      await signInWithPassword(email, password)
    } catch (err) {
      setError(err?.message || '로그인에 실패했습니다')
    } finally {
      setSending(false)
    }
  }

  return (
    <section className="mx-auto max-w-md w-full">
      <div className="rounded-xl border border-white/10 bg-[#13161A] p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">로그인</h2>
          {user ? (
            <button onClick={signOut} className="text-xs px-3 py-1 rounded border border-white/10 hover:bg-white/5">로그아웃</button>
          ) : (
            <Link to="/signup" className="text-xs text-blue-400 hover:text-blue-300">회원가입</Link>
          )}
        </div>

        {!user && (
          <form onSubmit={onSubmit} className="space-y-3">
            <div className="space-y-2">
              <label className="text-xs text-gray-300">이메일</label>
              <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required placeholder="name@example.com" className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-gray-300">비밀번호</label>
              <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={6} className="w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm" />
            </div>
            {error && <div className="text-sm text-rose-400">{error}</div>}
            <button disabled={sending} className="w-full px-4 py-2 bg-[#1D6FEA] text-white rounded-md disabled:opacity-60">
              {sending ? '처리 중…' : '로그인'}
            </button>
          </form>
        )}

        {user && (
          <div className="flex items-center justify-between text-sm text-gray-400">
            <span>{user.email} 로 로그인됨</span>
            <Link to="/profile/edit" className="text-xs text-blue-400 hover:text-blue-300">프로필 수정</Link>
          </div>
        )}
      </div>
    </section>
  )
}
