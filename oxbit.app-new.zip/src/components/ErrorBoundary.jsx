import React from 'react'

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }
  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary]', error, info)
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="mx-auto max-w-3xl px-4 py-10">
          <div className="rounded-lg border border-red-800 bg-red-950/30 p-6 text-sm text-red-200">
            <p className="font-semibold">화면을 렌더링하는 중 오류가 발생했습니다.</p>
            <p className="mt-2 opacity-80">{String(this.state.error?.message || this.state.error)}</p>
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

