﻿import React from 'react'

export default function Modal({ open, title, onClose, children }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70" onClick={onClose} />
      <div className="relative w-full max-w-2xl rounded-xl border border-white/10 bg-[#13161A] p-5 shadow-lg">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-semibold text-gray-100">{title}</h3>
          <button onClick={onClose} className="text-sm text-gray-300 hover:text-white">닫기</button>
        </div>
        <div className="prose prose-invert max-w-none text-sm text-gray-300">{children}</div>
      </div>
    </div>
  )
}


