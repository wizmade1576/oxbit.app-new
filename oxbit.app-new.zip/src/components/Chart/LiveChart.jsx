import React, { useEffect, useRef, useState } from 'react'
import { createChart } from 'lightweight-charts'

export default function LiveChart({ compact = false }) {
  const containerRef = useRef(null)
  const chartRef = useRef(null)
  const seriesRef = useRef(null)
  const wsRef = useRef(null)
  const resizeObserverRef = useRef(null)

  const [symbol, setSymbol] = useState('BTCUSDT')
  const [interval, setInterval] = useState('1m')
  const [search, setSearch] = useState('')

  const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d']

  const loadInitial = async (pair, tf) => {
    try {
      const res = await fetch(
        `https://api.binance.com/api/v3/klines?symbol=${pair}&interval=${tf}&limit=200`
      )
      const data = await res.json()
      const formatted = data.map(k => ({
        time: k[0] / 1000,
        open: +k[1],
        high: +k[2],
        low: +k[3],
        close: +k[4],
      }))
      seriesRef.current.setData(formatted)
    } catch {}
  }

  const setupWS = (pair, tf) => {
    if (wsRef.current) {
      try { wsRef.current.close() } catch {}
    }

    const ws = new WebSocket(`wss://stream.binance.com:9443/ws/${pair.toLowerCase()}@kline_${tf}`)
    ws.onmessage = (e) => {
      const json = JSON.parse(e.data)
      if (!json.k) return
      const k = json.k
      const candle = {
        time: k.t / 1000,
        open: +k.o,
        high: +k.h,
        low: +k.l,
        close: +k.c,
      }
      seriesRef.current.update(candle)
    }
    wsRef.current = ws
  }

  // create chart only once
  useEffect(() => {
    let mounted = true
    const el = containerRef.current
    if (!el) return
    if (chartRef.current) return

    const width = el.clientWidth || 600
    const height = el.clientHeight || 300

    const chart = createChart(el, {
      width,
      height,
      layout: { background: { color: 'rgba(0,0,0,0)' }, textColor: '#fff' },
      grid: { vertLines: { color: '#1E293B' }, horzLines: { color: '#1E293B' } },
      rightPriceScale: { borderVisible: false },
      timeScale: { borderVisible: false },
      crosshair: { mode: 0 },
    })

    const series = chart.addCandlestickSeries({
      upColor: '#10b981',
      downColor: '#ef4444',
      borderUpColor: '#10b981',
      borderDownColor: '#ef4444',
      wickUpColor: '#10b981',
      wickDownColor: '#ef4444',
    })

    chartRef.current = chart
    seriesRef.current = series

    loadInitial(symbol, interval)
    setupWS(symbol, interval)

    const ro = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect
      if (width > 0 && height > 0) {
        chart.applyOptions({ width, height })
      }
    })
    ro.observe(el)
    resizeObserverRef.current = ro

    return () => {
      mounted = false
      if (wsRef.current) wsRef.current.close()
      if (resizeObserverRef.current) resizeObserverRef.current.disconnect()
      if (chartRef.current) chartRef.current.remove()
      wsRef.current = null
      chartRef.current = null
      seriesRef.current = null
    }
  }, [])

  // change timeframe or symbol
  useEffect(() => {
    if (!seriesRef.current) return
    loadInitial(symbol, interval)
    setupWS(symbol, interval)
  }, [symbol, interval])

  const handleSearch = () => {
    if (!search) return
    setSymbol(search.toUpperCase() + 'USDT')
  }

  const handleTop50 = () => {
    window.open('https://www.binance.com/en/markets', '_blank')
  }

  const containerHeightCls = compact ? 'h-[180px] sm:h-[300px]' : 'h-[300px] sm:h-[500px]'

  return (
    <section className="rounded-xl overflow-hidden border border-white/10 bg-[#0F1114] text-white space-y-2 p-2">

      {/* ✅ Chart Toolbar */}
      <div className="flex flex-wrap gap-2 items-center">
        {/* Search */}
        <input
          placeholder="BTC, ETH..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="px-2 py-1 rounded bg-black/40 border border-white/10 text-sm"
        />
        <button onClick={handleSearch} className="px-2 py-1 rounded bg-blue-600 text-xs">검색</button>

        {/* Top 50 */}
        <button onClick={handleTop50} className="px-2 py-1 rounded bg-white/10 text-xs border border-white/10">
          Top 50
        </button>

        {/* Timeframe buttons */}
        {timeframes.map(tf => (
          <button
            key={tf}
            onClick={() => setInterval(tf)}
            className={`px-2 py-1 text-xs rounded ${
              interval === tf ? 'bg-blue-600' : 'bg-white/10'
            }`}
          >
            {tf}
          </button>
        ))}
      </div>

      {/* Chart */}
      <div ref={containerRef} className={`${containerHeightCls} w-full`} />
    </section>
  )
}
