import React, { useEffect, useState } from 'react'
import { fetchOnchainIndicators } from '../../services/onchain/onchainService'
import { formatNumber, formatCurrency } from '../../utils/format'

export default function OnchainCards() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const res = await fetchOnchainIndicators('BTC')
        if (!mounted) return
        setData(res)
      } catch (e) {
        setError('온체인 지표 로드 오류')
      } finally {
        setLoading(false)
      }
    })()
    return () => { mounted = false }
  }, [])

  const cards = data ? [
    { key: 'realizedPrice', name: 'Realized Price', value: formatCurrency(data.realizedPrice.value, 'USD', 0), change: data.realizedPrice.change, series: data.realizedPrice.series },
    { key: 'exchangeInflow', name: 'Exchange Inflow', value: formatNumber(data.exchangeInflow.value), change: data.exchangeInflow.change, series: data.exchangeInflow.series },
    { key: 'exchangeOutflow', name: 'Exchange Outflow', value: formatNumber(data.exchangeOutflow.value), change: data.exchangeOutflow.change, series: data.exchangeOutflow.series },
    { key: 'stablecoinInflow', name: 'Stablecoin Inflow', value: formatNumber(data.stablecoinInflow.value), change: data.stablecoinInflow.change, series: data.stablecoinInflow.series },
    { key: 'minerReserve', name: 'Miner Reserve', value: formatNumber(data.minerReserve.value), change: data.minerReserve.change, series: data.minerReserve.series },
    { key: 'whaleTransfer', name: 'Whale Wallet Transfer (1K+ BTC)', value: formatNumber(data.whaleTransfer.value), change: data.whaleTransfer.change, series: data.whaleTransfer.series },
  ] : []

  return (
    <section className="rounded-xl border border-white/10 bg-[#0F1114]/60 p-3 sm:p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-100">온체인 가격 및 지표</h3>
        {error ? <span className="text-xs text-rose-400" role="alert">{error}</span> : null}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {loading ? (
          [...Array(6)].map((_, i) => (
            <div key={i} className="rounded-lg border border-white/10 p-3 bg-white/5 animate-pulse h-[110px]" />
          ))
        ) : (
          cards.map((c) => (
            <article key={c.key} className="rounded-lg border border-white/10 p-3 bg-white/5">
              <div className="flex items-center justify-between">
                <div className="text-xs text-gray-400">{c.name}</div>
                <div className={`text-xs ${c.change >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>{c.change > 0 ? '+' : ''}{c.change}%</div>
              </div>
              <div className="mt-1 text-lg font-semibold text-gray-100">{c.value}</div>
              <Sparkline series={c.series} />
            </article>
          ))
        )}
      </div>
    </section>
  )
}

function Sparkline({ series = [] }) {
  // Simple SVG sparkline
  if (!series.length) return <div className="h-8" />
  const w = 240, h = 40, pad = 4
  const xs = series.map((p) => p.t)
  const ys = series.map((p) => p.v)
  const minX = Math.min(...xs), maxX = Math.max(...xs)
  const minY = Math.min(...ys), maxY = Math.max(...ys)
  const path = series.map((p, i) => {
    const x = pad + (w - pad * 2) * ((p.t - minX) / (maxX - minX || 1))
    const y = h - pad - (h - pad * 2) * ((p.v - minY) / (maxY - minY || 1))
    return `${i ? 'L' : 'M'}${x},${y}`
  }).join(' ')
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} className="mt-2" aria-hidden>
      <path d={path} fill="none" stroke="#60a5fa" strokeWidth="2"/>
    </svg>
  )
}

