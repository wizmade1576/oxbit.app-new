﻿// Auto-generated wrapper to route all imports to the new component.
export { default } from './NewsFeedNew.jsx'

