﻿import React from "react";
import { useNavigate } from "react-router-dom";

export default function LoginPromoCard({
  title = "",
  message = "실시간 속보·뉴스를 가장 빠르게\n\nOxbit.app에 로그인하고 다양한 서비스와 혜택을 누리세요!",
  ctaText = "로그인",
  onLogin,
  onReset,
  onSignup,
  className = "",
}) {
  const navigate = useNavigate();
  const handleLogin = onLogin || (() => navigate("/login"));
  const handleReset = onReset || (() => navigate("/login?mode=reset"));
  const handleSignup = onSignup || (() => navigate("/login?mode=signup"));

  return (
    <div className={`rounded-xl shadow-xl p-5 text-center ${className} border border-black/10 bg-white text-gray-900 dark:border-[#1e1f25] dark:bg-[#111318] dark:text-gray-200`}>
      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">{title}</h3>
      <p className="text-sm text-gray-600 dark:text-gray-400 whitespace-pre-line leading-relaxed mb-4">{message}</p>
      <button
        type="button"
        onClick={handleLogin}
        className="w-full bg-[#1E6FFF] hover:bg-[#155FDD] transition-colors duration-150 text-white font-semibold py-2.5 rounded-lg text-sm"
      >
        {ctaText}
      </button>
      <div className="flex justify-between mt-3 text-xs text-gray-400">
        <button type="button" onClick={handleReset} className="hover:text-white transition">비밀번호 찾기</button>
        <button type="button" onClick={handleSignup} className="hover:text-white transition">회원가입</button>
      </div>
    </div>
  );
}
