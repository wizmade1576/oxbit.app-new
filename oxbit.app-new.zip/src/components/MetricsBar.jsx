import { useEffect, useState } from 'react'
import axios from 'axios'

export default function MetricsBar() {
  const [data, setData] = useState({
    btcUsd: null,
    btcChange: null,
    ethUsd: null,
    ethChange: null,
    usdKrw: null,
    krwBtc: null,
    krwEth: null,
    kimchiBtc: null,
    btcDominance: null,
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        setLoading(true)
        // Try Edge proxy first (Vercel)
        try {
          const resp = await axios.get('/api/proxy-metrics?ttl=60&swr=300')
          const d = resp?.data || {}
          if (d && (d.btcUsd != null || d.ethUsd != null || d.usdKrw != null)) {
            if (!mounted) return
            setData({
              btcUsd: d.btcUsd ?? null,
              btcChange: d.btcChange ?? null,
              ethUsd: d.ethUsd ?? null,
              ethChange: d.ethChange ?? null,
              usdKrw: d.usdKrw ?? null,
              krwBtc: d.krwBtc ?? null,
              krwEth: d.krwEth ?? null,
              kimchiBtc: d.kimchiBtc ?? null,
              btcDominance: d.btcDominance ?? null,
            })
            return
          }
        } catch {}

        // Fallback: public APIs (local dev)
        const results = await Promise.allSettled([
          axios.get('https://api.coinstats.app/public/v1/coins?skip=0&limit=50&currency=USD'),
          axios.get('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true'),
          axios.get('https://api.exchangerate.host/latest?base=USD&symbols=KRW'),
          axios.get('https://api.upbit.com/v1/ticker?markets=KRW-BTC,KRW-ETH'),
          axios.get('https://api.coingecko.com/api/v3/global'),
          axios.get('https://api.coinbase.com/v2/exchange-rates?currency=USD'),
          axios.get('https://open.er-api.com/v6/latest/USD'),
        ])

        let btc = null, eth = null, btcChange = null, ethChange = null
        if (results[0].status === 'fulfilled') {
          const coins = results[0].value.data?.coins || []
          const btcRow = coins.find((c) => c.symbol === 'BTC')
          const ethRow = coins.find((c) => c.symbol === 'ETH')
          btc = { price: btcRow?.price }
          eth = { price: ethRow?.price }
          btcChange = typeof btcRow?.priceChange1d === 'number' ? btcRow.priceChange1d : null
          ethChange = typeof ethRow?.priceChange1d === 'number' ? ethRow.priceChange1d : null
        } else if (results[1].status === 'fulfilled') {
          const m = results[1].value.data || {}
          const b = m.bitcoin || {}
          const e = m.ethereum || {}
          btc = { price: typeof b.usd === 'number' ? b.usd : null }
          eth = { price: typeof e.usd === 'number' ? e.usd : null }
          btcChange = typeof b.usd_24h_change === 'number' ? b.usd_24h_change : null
          ethChange = typeof e.usd_24h_change === 'number' ? e.usd_24h_change : null
        }

        let usdKrw = null
        if (results[2].status === 'fulfilled') {
          usdKrw = results[2].value.data?.rates?.KRW || null
        }
        if (!usdKrw && results[5].status === 'fulfilled') {
          const v = results[5].value?.data?.data?.rates?.KRW
          usdKrw = v ? Number(v) : null
        }
        if (!usdKrw && results[6].status === 'fulfilled') {
          usdKrw = results[6].value?.data?.rates?.KRW || null
        }

        let krwBtc = null, krwEth = null
        if (results[3].status === 'fulfilled' && Array.isArray(results[3].value.data)) {
          const arr = results[3].value.data
          krwBtc = (arr.find((t) => t?.market === 'KRW-BTC') || arr[0])?.trade_price ?? null
          krwEth = (arr.find((t) => t?.market === 'KRW-ETH'))?.trade_price ?? null
        }

        let kimchiBtc = null
        if (btc?.price && usdKrw && krwBtc) {
          const globalKrw = btc.price * usdKrw
          kimchiBtc = ((krwBtc / globalKrw) - 1) * 100
        }

        const dominance = results[4].status === 'fulfilled' ? (results[4].value?.data?.data?.market_cap_percentage?.btc ?? null) : null

        if (mounted) setData({
          btcUsd: btc?.price ?? null,
          btcChange,
          ethUsd: eth?.price ?? null,
          ethChange,
          usdKrw,
          krwBtc,
          krwEth,
          kimchiBtc,
          btcDominance: dominance,
        })
      } catch {
        // keep placeholders
      } finally { if (mounted) setLoading(false) }
    }
    load()
    const id = setInterval(load, 60_000)
    return () => { mounted = false; clearInterval(id) }
  }, [])

  const fmtUsd = (n) => (n == null ? '-' : `$${Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 })}`)
  const fmtPct = (n) => (n == null ? '-' : `${Number(n).toFixed(2)}%`)
  const fmtKrw = (n) => (n == null ? '-' : `${Number(n).toLocaleString()}원`)

  return (
    <section className="w-full overflow-x-auto">
      <div className="min-w-full border-y border-white/10 bg-black/20">
        <div className="ox-container px-0">
          <ul className="flex flex-wrap items-center justify-center gap-6 py-3 text-sm">
            <li className="whitespace-nowrap text-center">
              <span className="text-gray-400 mr-2">BTC:</span>
              <span className="font-medium text-gray-100">{fmtUsd(data.btcUsd)}</span>
              {typeof data.btcChange === 'number' && (
                <span className={data.btcChange >= 0 ? 'ml-2 text-red-400' : 'ml-2 text-blue-400'}>{fmtPct(data.btcChange)}</span>
              )}
            </li>
            <li className="whitespace-nowrap text-center">
              <span className="text-gray-400 mr-2">ETH:</span>
              <span className="font-medium text-gray-100">{fmtUsd(data.ethUsd)}</span>
              {typeof data.ethChange === 'number' && (
                <span className={data.ethChange >= 0 ? 'ml-2 text-red-400' : 'ml-2 text-blue-400'}>{fmtPct(data.ethChange)}</span>
              )}
            </li>
            <li className="whitespace-nowrap text-center">
              <span className="text-gray-400 mr-2">김프(BTC 기준):</span>
              <span className={data.kimchiBtc != null && data.kimchiBtc >= 0 ? 'text-red-400 font-medium' : 'text-blue-400 font-medium'}>
                {fmtPct(data.kimchiBtc)}
              </span>
            </li>
            <li className="whitespace-nowrap text-center">
              <span className="text-gray-400 mr-2">환율(USD/KRW):</span>
              <span className="font-medium text-gray-100">{data.usdKrw ? Number(data.usdKrw).toFixed(2) : '-'}</span>
            </li>
            <li className="whitespace-nowrap text-center">
              <span className="text-gray-400 mr-2">BTC 도미넌스:</span>
              <span className="font-medium text-gray-100">{data.btcDominance == null ? '-' : `${Number(data.btcDominance).toFixed(2)}%`}</span>
            </li>
            {loading && <li className="text-xs text-gray-400 text-center">업데이트 중</li>}
          </ul>
        </div>
      </div>
    </section>
  )
}

