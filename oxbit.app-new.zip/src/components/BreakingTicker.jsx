﻿import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { listBreaking, subscribeBreaking } from '../services/breakingService'

const defaultItems = []

export default function BreakingTicker({ items = defaultItems, intervalMs = 3000, compact = false, label = '속보' }) {
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const timerRef = useRef(null)
  const navigate = useNavigate()
  const containerRef = useRef(null)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!items.length || paused) return
    timerRef.current = setInterval(() => setIndex((i) => (i + 1) % items.length), intervalMs)
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [items.length, intervalMs, paused])

  useEffect(() => {
    if (!open) return
    const onDown = (e) => {
      if (!containerRef.current) return
      if (!containerRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [open])

  // fetch initial top items
  const { data: fetchedTop = [] } = useQuery({
    queryKey: ['breakingTop5'],
    queryFn: () => listBreaking({ limit: 5 }),
    staleTime: 30_000,
  })

  // realtime overlay
  const [live, setLive] = useState([])
  useEffect(() => {
    const unsubscribe = subscribeBreaking({
      onInsert: (row) => setLive((a) => [{ id: row.id, title: row.title }, ...a].slice(0, 5)),
    })
    return () => unsubscribe?.()
  }, [])

  const useItems = (live.length ? live : fetchedTop).length ? (live.length ? live : fetchedTop) : items
  if (!useItems.length) return null

  if (compact) {
    const seq = useItems.slice(0, 5)
    const pos = seq.length ? index % seq.length : 0
    const current = seq[pos]
    const number = seq.length ? pos + 1 : 0
    return (
      <div
        ref={containerRef}
        className="relative w-[160px] lg:w-[210px] overflow-visible"
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
      >
        <div
          className="flex items-center gap-2 px-2 py-1 rounded-full bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
          onClick={() => setOpen((v) => !v)}
        >
          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-[#1D6FEA]/20 text-[#1D6FEA] shrink-0">
            {label}
          </span>
          <span className="text-sm text-gray-200 truncate">
            {current ? `${number}. ${current.title}` : ''}
          </span>
        </div>
        {open && (
          <div className="absolute right-0 mt-2 w-[260px] rounded-md border border-white/10 bg-[#0F1114] shadow-lg z-50 origin-top-right animate-scale-fade">
            <ul className="max-h-80 overflow-auto py-1">
              {seq.map((it, i) => (
                <li key={it.id}>
                  <button
                    type="button"
                    className="w-full text-left px-3 py-2 text-sm hover:bg-white/10 text-gray-100 flex gap-2"
                    onClick={() => {
                      setOpen(false)
                      navigate(`/breaking/detail?id=${encodeURIComponent(it.id)}`)
                    }}
                  >
                    <span className="text-[#1D6FEA] shrink-0">{i + 1}.</span>
                    <span className="truncate">{it.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="w-full overflow-hidden border border-white/10 rounded-md bg-black/20" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="whitespace-nowrap py-2 px-3 text-sm">
        <span className="font-semibold text-[#1D6FEA] mr-2">{label}</span>
        <span className="text-gray-200">{useItems[index % useItems.length]?.title}</span>
      </div>
    </div>
  )
}
