// Fetch list of tradable USDT spot symbols from major exchange (Binance)
// Falls back to a small default list when network/CORS fails.

const DEFAULT_SYMBOLS = [
  'BTCUSDT','ETHUSDT','SOLUSDT','XRPUSDT','BNBUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT',
  'OPUSDT','ARBUSDT','SUIUSDT','APTUSDT','LINKUSDT','MATICUSDT','TONUSDT'
]

async function tryFetch(url, opts) {
  try {
    const res = await fetch(`/api/proxy?url=${encodeURIComponent(url)}`, { ...opts, method: 'GET' })
    if (res.ok) return await res.json()
  } catch {}
  try {
    const res = await fetch(url, { ...opts, method: 'GET' })
    if (res.ok) return await res.json()
  } catch {}
  return null
}

export async function fetchUsdtSymbols() {
  const data = await tryFetch('https://api.binance.com/api/v3/exchangeInfo')
  try {
    const list = Array.isArray(data?.symbols) ? data.symbols : []
    const out = list
      .filter((s) => s?.quoteAsset === 'USDT' && s?.status === 'TRADING')
      .map((s) => s?.symbol)
      .filter(Boolean)
    return out.length ? out.sort() : DEFAULT_SYMBOLS
  } catch {
    return DEFAULT_SYMBOLS
  }
}

export function defaultSymbols() {
  return DEFAULT_SYMBOLS.slice()
}

