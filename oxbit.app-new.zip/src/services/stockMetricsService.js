import axios from 'axios'

function isBrowser() { return typeof window !== 'undefined' }

async function safeGet(url, opts = {}) {
  const timeout = opts.timeout ?? 15000
  const forceProxy = !!opts.forceProxy
  // 1) Try backend proxy first (recommended)
  if (isBrowser()) {
    try {
      const proxyUrl = `/api/proxy?url=${encodeURIComponent(url)}`
      const res = await axios.get(proxyUrl, { timeout })
      return res.data
    } catch (_) {
      // fall through
    }
  }
  // 2) Fallback to direct request if proxy not available or failed
  if (!forceProxy) {
    try {
      const res = await axios.get(url, { timeout })
      return res.data
    } catch (_) {}
  }
  return null
}

async function yahooQuoteOne(symbol) {
  const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(symbol)}`
  const data = await safeGet(url, { forceProxy: true })
  const q = data?.quoteResponse?.result?.[0]
  if (!q) return null
  // Robust fallbacks: some indices (e.g., ^NDX) omit certain fields
  const num = (v) => {
    const n = Number(v)
    return isFinite(n) ? n : NaN
  }
  const prevClose = [
    q.regularMarketPreviousClose,
    q.previousClose,
    q.regularMarketOpen,
    q.open,
  ].map(num).find((n) => isFinite(n))

  const high = [
    q.regularMarketDayHigh,
    q.dayHigh,
    q.high,
  ].map(num).find((n) => isFinite(n))

  const low = [
    q.regularMarketDayLow,
    q.dayLow,
    q.low,
  ].map(num).find((n) => isFinite(n))

  return {
    price: num(q.regularMarketPrice),
    changePct: num(q.regularMarketChangePercent),
    changeAbs: num(q.regularMarketChange),
    prevClose: prevClose,
    high: high,
    low: low,
  }
}

async function yahooTry(symbols = []) {
  for (const s of symbols) {
    const r = await yahooQuoteOne(s)
    if (r && isFinite(r.price)) return r
  }
  return { price: NaN, changePct: NaN }
}

async function binanceTicker(symbol = 'BTCUSDT') {
  const url = `https://api.binance.com/api/v3/ticker/24hr?symbol=${encodeURIComponent(symbol)}`
  const d = await safeGet(url)
  return {
    price: Number(d?.lastPrice),
    changePct: Number(d?.priceChangePercent),
    changeAbs: Number(d?.priceChange),
    prevClose: Number(d?.prevClosePrice),
    high: Number(d?.highPrice),
    low: Number(d?.lowPrice),
  }
}

async function btcDominance() {
  const d = await safeGet('https://api.coingecko.com/api/v3/global')
  const dom = Number(d?.data?.market_cap_percentage?.btc)
  return { price: isFinite(dom) ? dom : NaN, changePct: NaN, changeAbs: NaN, prevClose: NaN, high: NaN, low: NaN }
}

export async function fetchStockTopMetrics() {
  const [nas, spx, dxy, btc, dom] = await Promise.all([
    // NASDAQ100 (^NDX as primary, sometimes ^IXIC is Nasdaq Composite but we prefer NDX)
    yahooTry(['^NDX','NDX','NASDAQ:NDX']),
    // S&P500
    yahooTry(['^GSPC','SPY']),
    // DXY (several aliases)
    yahooTry(['DX-Y.NYB','DXY','DX=F']),
    // Binance BTC
    binanceTicker('BTCUSDT'),
    // Dominance
    btcDominance(),
  ])

  return {
    nasdaq: nas,
    spx: spx,
    dxy: dxy,
    btc: btc,
    dominance: dom,
  }
}

export const STOCK_ICONS = {
  nasdaq: 'https://www.google.com/s2/favicons?domain=nasdaq.com&sz=64',
  spx: 'https://www.google.com/s2/favicons?domain=spglobal.com&sz=64',
  dxy: 'https://www.google.com/s2/favicons?domain=ice.com&sz=64',
  btc: 'https://www.google.com/s2/favicons?domain=binance.com&sz=64',
  dominance: 'https://www.google.com/s2/favicons?domain=bitcoin.org&sz=64',
}
