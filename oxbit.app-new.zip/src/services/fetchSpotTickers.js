// Temporary shim so callers can import a focused function
// without depending on the whole marketService module.
import { fetchSpotTickers as _fetchSpotTickers } from './marketService'

export const fetchSpotTickers = _fetchSpotTickers

