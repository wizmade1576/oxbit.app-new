import axios from 'axios'

const CS_ENDPOINT = 'https://api.coinstats.app/public/v1/news'
const CP_ENDPOINT = 'https://cryptopanic.com/api/v1/posts/'

const cache = new Map()
function setCache(key, value, ttlMs = 60_000) { cache.set(key, { value, expireAt: Date.now() + ttlMs }) }
function getCache(key) {
  const hit = cache.get(key)
  if (!hit) return null
  if (hit.expireAt < Date.now()) { cache.delete(key); return null }
  return hit.value
}

async function fetchFromCoinStats(limit) {
  const url = `${CS_ENDPOINT}?skip=0&limit=${limit}`
  const { data } = await axios.get(url)
  const list = data?.news || []
  return list.slice(0, limit).map((n) => ({
    id: n.id || n._id || slugify(n.title),
    slug: slugify(n.title),
    title: n.title,
    url: n.link || n.url,
    source: n.source || 'CoinStats',
    published_at: n.feedDate ? new Date(n.feedDate).toISOString() : new Date().toISOString(),
    image: n.imgURL || n.image || '',
    description: n.description || n.text || '',
  }))
}

async function fetchFromCryptoPanic(limit) {
  const token = import.meta?.env?.VITE_CRYPTOPANIC_TOKEN
  if (!token) return []
  const url = `${CP_ENDPOINT}?auth_token=${token}&kind=news&public=true`
  const { data } = await axios.get(url)
  const list = data?.results || []
  return list.slice(0, limit).map((n) => ({
    id: String(n.id || slugify(n.title)),
    slug: slugify(n.title),
    title: n.title,
    url: n.url,
    source: n.domain || 'CryptoPanic',
    published_at: n.published_at ? new Date(n.published_at).toISOString() : new Date().toISOString(),
    image: '',
    description: n.slug || n.title || '',
  }))
}

async function fetchFromSources(limit) {
  const key = `mix:${limit}`
  const hit = getCache(key)
  if (hit) return hit
  // Prefer server proxy when deployed
  try {
    const { data } = await axios.get(`/api/proxy-news?limit=${limit}`)
    if (Array.isArray(data?.news)) { setCache(key, data.news); return data.news }
  } catch {}
  const res = await Promise.allSettled([
    fetchFromCoinStats(limit),
    fetchFromCryptoPanic(limit),
  ])
  const cs = res[0].status === 'fulfilled' ? res[0].value : []
  const cp = res[1].status === 'fulfilled' ? res[1].value : []
  let merged = [...cs, ...cp]
  if (!merged.length) {
    merged = Array.from({ length: Math.max(10, limit) }).map((_, i) => ({
      id: `mock-${i + 1}`,
      slug: `mock-${i + 1}`,
      title: `모의 뉴스 ${i + 1} - BTC/ETH 시장 업데이트`,
      url: '#',
      source: 'Mock',
      published_at: new Date(Date.now() - i * 60000).toISOString(),
      image: '',
      description: '네트워크/레이트리밋/CORS 이슈 시 임시 데이터입니다.',
    }))
  }
  const seen = new Set()
  const uniq = []
  for (const it of merged) {
    const k = String(it.id || it.slug)
    if (seen.has(k)) continue
    seen.add(k)
    uniq.push(it)
  }
  setCache(key, uniq, 60_000)
  return uniq
}

export async function fetchLatestNews(limit = 10) {
  const all = await fetchFromSources(limit)
  return all.slice(0, limit)
}

export async function searchNews(limit = 50) {
  const all = await fetchFromSources(limit)
  return all.slice(0, limit)
}

export async function fetchNewsDetail({ id, title }) {
  const all = await searchNews(100)
  let found = null
  if (id) found = all.find((n) => String(n.id) === String(id))
  if (!found && title) {
    const q = String(title).toLowerCase()
    found = all.find((n) => n.title?.toLowerCase() === q) || all.find((n) => n.title?.toLowerCase().includes(q))
  }
  return found || null
}

function slugify(s = '') {
  return String(s)
    .toLowerCase()
    .replace(/[^a-z0-9가-힣\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
}

