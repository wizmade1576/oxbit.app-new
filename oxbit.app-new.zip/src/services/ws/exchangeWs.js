// WebSocket helpers for Binance/Bybit kline streams with auto-reconnect.

const BINANCE_WS = (symbol = 'BTCUSDT', interval = '1m') => `wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@kline_${interval}`
const BYBIT_WS = (symbol = 'BTCUSDT', interval = '1') => `wss://stream.bybit.com/v5/public/linear`

export function createBinanceKlineStream({ symbol = 'BTCUSDT', interval = '1m', onKline }) {
  let ws
  let closed = false
  let timer

  const connect = () => {
    ws = new WebSocket(BINANCE_WS(symbol, interval))
    ws.onopen = () => {}
    ws.onmessage = (ev) => {
      try {
        const data = JSON.parse(ev.data)
        const k = data.k
        if (!k) return
        onKline && onKline({
          openTime: k.t,
          closeTime: k.T,
          open: Number(k.o),
          high: Number(k.h),
          low: Number(k.l),
          close: Number(k.c),
          volume: Number(k.v),
          isFinal: !!k.x,
        })
      } catch {}
    }
    ws.onclose = () => {
      if (closed) return
      timer = setTimeout(connect, 1500)
    }
    ws.onerror = () => {
      try { ws.close() } catch {}
    }
  }

  connect()

  return {
    close() {
      closed = true
      try { ws && ws.close() } catch {}
      if (timer) clearTimeout(timer)
    },
  }
}

// Bybit v5 public requires a subscribe frame after open.
export function createBybitKlineStream({ symbol = 'BTCUSDT', interval = '1', onKline }) {
  let ws
  let closed = false
  let timer

  const connect = () => {
    ws = new WebSocket(BYBIT_WS(symbol, interval))
    ws.onopen = () => {
      const topic = `kline.${interval}.${symbol}`
      ws.send(JSON.stringify({ op: 'subscribe', args: [topic] }))
    }
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data)
        const d = msg.data && Array.isArray(msg.data) ? msg.data[0] : null
        if (!d) return
        onKline && onKline({
          openTime: Number(d.start),
          closeTime: Number(d.end),
          open: Number(d.open),
          high: Number(d.high),
          low: Number(d.low),
          close: Number(d.close),
          volume: Number(d.volume),
          isFinal: msg.type === 'snapshot' ? true : false,
        })
      } catch {}
    }
    ws.onclose = () => {
      if (closed) return
      timer = setTimeout(connect, 1500)
    }
    ws.onerror = () => {
      try { ws.close() } catch {}
    }
  }

  connect()

  return {
    close() {
      closed = true
      try { ws && ws.close() } catch {}
      if (timer) clearTimeout(timer)
    },
  }
}

