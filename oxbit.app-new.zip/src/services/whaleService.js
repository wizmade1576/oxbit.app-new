// Placeholder service for whale tracking related data.
// Later, replace mock implementations with real API calls (via proxy if needed).

export async function fetchFuturesTrades(params = {}) {
  // TODO: call your backend/proxy to aggregate futures whale trades.
  return []
}

export async function fetchFuturesLiquidations(params = {}) {
  return []
}

export async function fetchSpotBuys(params = {}) {
  return []
}

export async function fetchSpotSells(params = {}) {
  return []
}

