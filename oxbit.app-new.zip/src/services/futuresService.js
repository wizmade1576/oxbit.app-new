import axios from 'axios'

async function safeGet(url, opts = {}) {
  const timeout = opts.timeout ?? 15000
  const isBrowser = typeof window !== 'undefined'
  if (isBrowser) {
    try {
      const proxyUrl = `/api/proxy?url=${encodeURIComponent(url)}`
      const res = await axios.get(proxyUrl, { timeout, ...opts })
      return res.data
    } catch (_) { /* fall through */ }
  }
  const res = await axios.get(url, { timeout, ...opts })
  return res.data
}

export async function fetchFundingRateBinance(symbol = 'BTCUSDT') {
  const data = await safeGet(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${encodeURIComponent(symbol)}`)
  const fundingRate = Number(data?.lastFundingRate ?? data?.fundingRate ?? data?.lastFundingRate)
  const nextFundingTime = data?.nextFundingTime ? Number(data.nextFundingTime) : null
  return { exchange: 'binance', symbol, fundingRate: isFinite(fundingRate) ? fundingRate : 0, nextFundingTime }
}

export async function fetchLongShortRatioBinance(symbol = 'BTCUSDT', period = '1h', limit = 1) {
  const arr = await safeGet(`https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=${encodeURIComponent(symbol)}&period=${encodeURIComponent(period)}&limit=${limit}`)
  const last = Array.isArray(arr) && arr.length ? arr[arr.length - 1] : null
  const ratio = Number(last?.longShortRatio)
  // Binance returns Long/Short ratio; convert to long share [0..1]
  const longShare = isFinite(ratio) ? (ratio / (1 + ratio)) : 0.5
  return { exchange: 'binance', symbol, long: longShare, short: 1 - longShare, raw: last }
}

export async function fetchOpenInterestBinance(symbol = 'BTCUSDT', period = '1h', limit = 30) {
  const arr = await safeGet(`https://fapi.binance.com/futures/data/openInterestHist?symbol=${encodeURIComponent(symbol)}&period=${encodeURIComponent(period)}&limit=${limit}`)
  const series = Array.isArray(arr) ? arr.map((r) => ({ time: Number(r.timestamp), oi: Number(r.sumOpenInterestValue || r.sumOpenInterest) })) : []
  const last = series.length ? series[series.length - 1].oi : 0
  return { exchange: 'binance', symbol, latest: last, series }
}

// NOTE: Public liquidation aggregate APIs across exchanges are limited.
// For full multi-exchange liquidation, consider a paid provider (e.g., Coinglass).
// Here we attempt Binance 24h liquidation by symbol if available; otherwise return null.
export async function fetchLiquidationsBinance(symbol = 'BTCUSDT', limit = 50) {
  try {
    const arr = await safeGet(`https://fapi.binance.com/futures/data/liquidationOrders?symbol=${encodeURIComponent(symbol)}&limit=${limit}`)
    return Array.isArray(arr) ? arr : null
  } catch {
    return null
  }
}

