﻿// Kimp service: fetch tickers for KR (KRW) and Global (USD/USDT) exchanges
// Normalized shape: { [BASE]: price }
// Notes:
// - US exchanges often quote in USDT; we treat USDT ~= USD for premium calc.
// - Fallbacks keep UI usable when an exchange API is temporarily unavailable.

import axios from 'axios'

function todayYMD() {
  const d = new Date()
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}${m}${day}`
}

async function safeGet(url, opts = {}) {
  const timeout = opts.timeout ?? 15000
  const isBrowser = typeof window !== 'undefined'

  // 1) Try proxy first when running in browser (if backend route exists)
  if (isBrowser) {
    try {
      const proxyUrl = `/api/proxy?url=${encodeURIComponent(url)}`
      const res = await axios.get(proxyUrl, { timeout, ...opts })
      return res.data
    } catch (_) {
      // fall through to direct request
    }
  }

  // 2) Fallback to direct request (most of these public APIs support CORS)
  try {
    const res = await axios.get(url, { timeout, ...opts })
    return res.data
  } catch (e) {
    return null
  }
}

// ---- KRW exchanges ----
export async function fetchUpbitKRW() {
  // Get market list then tickers (KRW-*)
  const markets = await safeGet('https://api.upbit.com/v1/market/all?isDetails=false')
  const krw = (Array.isArray(markets) ? markets : []).filter((m) => m.market?.startsWith('KRW-')).map((m) => m.market)
  if (krw.length === 0) return {}
  const chunks = []
  for (let i = 0; i < krw.length; i += 100) chunks.push(krw.slice(i, i + 100))
  const out = {}
  for (const c of chunks) {
    const data = await safeGet(`https://api.upbit.com/v1/ticker?markets=${encodeURIComponent(c.join(','))}`)
    if (Array.isArray(data)) {
      for (const t of data) {
        const base = String(t.market || '').replace(/^KRW-/, '')
        const price = Number(t.trade_price)
        if (base && isFinite(price)) out[base] = price
      }
    }
  }
  return out
}

export async function fetchBithumbKRW() {
  const data = await safeGet('https://api.bithumb.com/public/ticker/ALL_KRW')
  const o = data?.data || {}
  const out = {}
  Object.keys(o).forEach((k) => {
    if (k === 'date') return
    const price = Number(o[k]?.closing_price)
    if (isFinite(price)) out[k.toUpperCase()] = price
  })
  return out
}

export async function fetchCoinoneKRW() {
  const data = await safeGet('https://api.coinone.co.kr/public/v2/ticker_new/ALL_KRW')
  const o = data?.tickers || data?.result || {}
  const out = {}
  Object.keys(o).forEach((k) => {
    const price = Number(o[k]?.last || o[k]?.closing_price)
    if (isFinite(price)) out[k.toUpperCase()] = price
  })
  return out
}

export async function fetchKorbitKRW() {
  const data = await safeGet('https://api.korbit.co.kr/v1/ticker/detailed/all')
  const out = {}
  Object.keys(data || {}).forEach((pair) => {
    if (!pair.endsWith('_krw')) return
    const [base] = pair.split('_')
    const price = Number(data[pair]?.last)
    if (isFinite(price)) out[base.toUpperCase()] = price
  })
  return out
}

// ---- Global exchanges (USD/USDT) ----
export async function fetchBinanceUSD() {
  const data = await safeGet('https://api.binance.com/api/v3/ticker/24hr')
  const out = {}
  ;(Array.isArray(data) ? data : []).forEach((t) => {
    const sym = String(t.symbol || '')
    if (sym.endsWith('USDT')) {
      const base = sym.replace(/USDT$/, '')
      const price = Number(t.lastPrice)
      if (isFinite(price)) out[base] = price
    }
  })
  return out
}

export async function fetchOkxUSD() {
  const data = await safeGet('https://www.okx.com/api/v5/market/tickers?instType=SPOT')
  const arr = data?.data || []
  const out = {}
  arr.forEach((t) => {
    const inst = t.instId || '' // e.g., BTC-USDT
    const [base, quote] = inst.split('-')
    if (quote === 'USDT') {
      const price = Number(t.last)
      if (isFinite(price)) out[base] = price
    }
  })
  return out
}

export async function fetchBybitUSD() {
  const data = await safeGet('https://api.bybit.com/v5/market/tickers?category=spot')
  const arr = data?.result?.list || []
  const out = {}
  arr.forEach((t) => {
    const sym = String(t.symbol || '') // e.g., BTCUSDT
    if (sym.endsWith('USDT')) {
      const base = sym.replace(/USDT$/, '')
      const price = Number(t.lastPrice)
      if (isFinite(price)) out[base] = price
    }
  })
  return out
}

export async function fetchBitgetUSD() {
  const data = await safeGet('https://api.bitget.com/api/spot/v1/market/tickers')
  const arr = data?.data || []
  const out = {}
  arr.forEach((t) => {
    const sym = String(t.symbol || '') // e.g., BTCUSDT
    if (sym.endsWith('USDT')) {
      const base = sym.replace(/USDT$/, '')
      const price = Number(t.close)
      if (isFinite(price)) out[base] = price
    }
  })
  return out
}

export async function fetchCoinbaseUSD() {
  // Coinbase Advanced API ??fetch product list then parallel ticker requests for *-USD or *-USDT pairs
  const products = await safeGet('https://api.exchange.coinbase.com/products')
  const list = Array.isArray(products) ? products : []
  const targets = list
    .filter((p) => typeof p?.id === 'string' && (/\-USD$/.test(p.id) || /\-USDT$/.test(p.id)))
    .slice(0, 200) // cap to avoid excessive requests

  const out = {}
  const limit = 8
  for (let i = 0; i < targets.length; i += limit) {
    const chunk = targets.slice(i, i + limit)
    const data = await Promise.all(
      chunk.map(async (p) => {
        const id = p.id
        const base = id.split('-')[0]
        const t = await safeGet(`https://api.exchange.coinbase.com/products/${encodeURIComponent(id)}/ticker`)
        const price = Number(t?.price)
        if (base && isFinite(price)) return { base, price }
        return null
      })
    )
    data.forEach((r) => { if (r && r.base) out[r.base] = r.price })
  }
  return out
}

export async function fetchUsdKrwRate() {
  // 1) Korea EximBank (optional, requires key)
  const eximKey = typeof import.meta !== 'undefined' ? import.meta.env?.VITE_EXIM_API_KEY : undefined
  if (eximKey) {
    const ymd = todayYMD()
    const api = `https://www.koreaexim.go.kr/site/program/financial/exchangeJSON?authkey=${encodeURIComponent(eximKey)}&searchdate=${ymd}&data=AP01`
    const exim = await safeGet(api)
    if (Array.isArray(exim)) {
      const usd = exim.find((x) => String(x?.cur_unit).toUpperCase() === 'USD')
      const val = usd?.deal_bas_r ? Number(String(usd.deal_bas_r).replace(/,/g, '')) : NaN
      if (isFinite(val) && val > 0) return val
    }
  }

  // 2) exchangerate.host (no key)
  const host = await safeGet('https://api.exchangerate.host/latest?base=USD&symbols=KRW')
  let rate = Number(host?.rates?.KRW)
  if (isFinite(rate) && rate > 0) return rate

  // 3) open.er-api fallback
  const data = await safeGet('https://open.er-api.com/v6/latest/USD')
  rate = Number(data?.rates?.KRW)
  return isFinite(rate) && rate > 0 ? rate : 1350
}

// Use Google S2 favicons proxy to avoid hotlink/CORS issues
const fav = (domain) => `https://www.google.com/s2/favicons?domain=${domain}&sz=64`


export const KR_EXCHANGES = {
  upbit: { label: '업비트', fetcher: fetchUpbitKRW, icon: fav('upbit.com') },
  bithumb: { label: '빗썸', fetcher: fetchBithumbKRW, icon: fav('bithumb.com') },
  coinone: { label: '코인원', fetcher: fetchCoinoneKRW, icon: fav('coinone.co.kr') },
  korbit: { label: '코빗', fetcher: fetchKorbitKRW, icon: fav('korbit.co.kr') },
}

export const GLOBAL_EXCHANGES = {
  binance: { label: '바이낸스', fetcher: fetchBinanceUSD, icon: fav('binance.com') },
  coinbase: { label: '코인베이스', fetcher: fetchCoinbaseUSD, icon: fav('coinbase.com') },
  okx: { label: 'OKX', fetcher: fetchOkxUSD, icon: fav('okx.com') },
  bybit: { label: '바이빗', fetcher: fetchBybitUSD, icon: fav('bybit.com') },
  bitget: { label: '비트겟', fetcher: fetchBitgetUSD, icon: fav('bitget.com') },
}

function median(nums) {
  const arr = (nums || []).filter((n) => typeof n === 'number' && isFinite(n)).sort((a,b)=>a-b)
  if (arr.length === 0) return NaN
  const m = Math.floor(arr.length / 2)
  return arr.length % 2 ? arr[m] : (arr[m-1] + arr[m]) / 2
}

export async function buildKimpRows({
  kr = 'upbit',
  gl = 'binance',
  rate,
  glList = ['binance','coinbase','okx','bybit','bitget'],
  useMedian = true,
  calibrateBy = 'BTC',
} = {}) {
  const krFetcher = KR_EXCHANGES[kr]?.fetcher || fetchUpbitKRW
  const glFetchers = (glList || []).map((k) => GLOBAL_EXCHANGES[k]?.fetcher).filter(Boolean)
  if (glFetchers.length === 0) glFetchers.push(GLOBAL_EXCHANGES[gl]?.fetcher || fetchBinanceUSD)

  const [krMap, ...glMaps] = await Promise.all([
    krFetcher(),
    ...glFetchers.map((f) => f()),
  ])

  // Effective KRW/USD rate (optionally calibrated by BTC)
  let effRate = rate
  const baseCal = String(calibrateBy || '').toUpperCase()
  if (isFinite(rate) && baseCal) {
    const krBtc = krMap[baseCal]
    const usdCandidates = glMaps.map((m) => m?.[baseCal]).filter((v) => isFinite(v))
    const usdMed = useMedian ? median(usdCandidates) : (usdCandidates.find((x)=>isFinite(x)) ?? NaN)
    if (isFinite(krBtc) && isFinite(usdMed) && usdMed > 0) {
      const implied = krBtc / usdMed
      const factor = Math.max(0.97, Math.min(1.03, implied / rate))
      effRate = rate * factor
    }
  }

  const bases = Array.from(new Set([
    ...Object.keys(krMap || {}),
    ...glMaps.flatMap((m) => Object.keys(m || {})),
  ])).sort()

  const rows = bases.map((base) => {
    const krw = krMap[base]
    const usdVals = glMaps.map((m) => m?.[base]).filter((v) => isFinite(v))
    const usd = useMedian ? median(usdVals) : (usdVals.find((x)=>isFinite(x)) ?? NaN)
    const usdKrw = isFinite(usd) && isFinite(effRate) ? usd * effRate : NaN
    const diff = isFinite(krw) && isFinite(usdKrw) ? krw - usdKrw : NaN
    const kimp = isFinite(diff) && isFinite(usdKrw) && usdKrw !== 0 ? (diff / usdKrw) * 100 : NaN
    return { base, krPrice: krw, usPrice: usdKrw, diffKr: diff, kimpPct: kimp }
  })
  return rows
}
