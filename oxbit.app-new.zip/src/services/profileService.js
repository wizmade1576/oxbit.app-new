import { supabase } from './supabase'

// Upsert a row into `profiles` with user.id as primary key
// Expects a table schema roughly: profiles(id uuid pk, nickname text, phone text, gender text, interest text, updated_at timestamptz)
export async function upsertProfile({ id, nickname, phone, gender, interest, avatar_url }) {
  const payload = {
    id,
    nickname: nickname || null,
    phone: phone || null,
    gender: gender || null,
    interest: interest || null,
    avatar_url: avatar_url || null,
    updated_at: new Date().toISOString(),
  }
  const { error } = await supabase.from('profiles').upsert(payload, { onConflict: 'id' })
  if (error) throw error
  return true
}

// Convenience: derive profile fields from user metadata
export async function upsertProfileFromUser(user) {
  if (!user?.id) return false
  const md = user.user_metadata || {}
  try {
    await upsertProfile({
      id: user.id,
      nickname: md.nickname,
      phone: md.phone,
      gender: md.gender,
      interest: md.interest,
      avatar_url: md.avatar_url,
    })
    return true
  } catch (_) {
    return false
  }
}
