import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  // eslint-disable-next-line no-console
  console.error('[breakingService] Missing env: VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY')
}

export const supabase = createClient(SUPABASE_URL || '', SUPABASE_ANON_KEY || '')

function wrapError(e) {
  const msg = e?.message || '요청 실패'
  const code = e?.code ? ` (code: ${e.code})` : ''
  const details = e?.details ? ` - ${e.details}` : ''
  return new Error(`${msg}${code}${details}`)
}

async function healthCheck() {
  if (!SUPABASE_URL) return { ok: false, reason: 'no-url' }
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/health`, { method: 'GET', mode: 'cors' })
    return { ok: res.ok, status: res.status }
  } catch (e) {
    return { ok: false, reason: e?.message || 'fetch-failed' }
  }
}

export function getEnvStatus() {
  return { hasUrl: !!SUPABASE_URL, hasKey: !!SUPABASE_ANON_KEY, url: SUPABASE_URL || '' }
}

export async function listBreaking({ limit = 50, status } = {}) {
  try {
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) throw new Error('환경변수 누락: VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY')
    if (import.meta?.env?.DEV) {
      const hc = await healthCheck()
      if (!hc.ok) {
        const hint = typeof hc.status === 'number' ? `status=${hc.status}` : hc.reason
        // eslint-disable-next-line no-console
        console.error('[Supabase healthCheck failed]', hint, '— CORS(Allowed Origins) 또는 URL을 확인하세요.')
      }
    }
    let q = supabase
      .from('breaking_news')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit)
    if (status) q = q.eq('status', status)
    const { data, error } = await q
    if (error) throw error
    return data || []
  } catch (e) {
    throw wrapError(e)
  }
}

export async function getBreakingById(id) {
  try {
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) throw new Error('환경변수 누락: VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY')
    const { data, error } = await supabase
      .from('breaking_news')
      .select('*')
      .eq('id', id)
      .single()
    if (error) throw error
    return data
  } catch (e) {
    throw wrapError(e)
  }
}

export function subscribeBreaking(handler) {
  const channel = supabase
    .channel('realtime:public:breaking_news')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'breaking_news' }, (payload) => {
      try { handler(payload) } catch {}
    })
    .subscribe()
  return () => {
    try { supabase.removeChannel(channel) } catch {}
  }
}

export async function createBreaking(row) {
  // omit optional fields that may not exist in the new schema
  const payload = { ...row }
  if (!payload.image_url) delete payload.image_url
  const { data, error } = await supabase.from('breaking_news').insert(payload).select().single()
  if (error) throw wrapError(error)
  return data
}

export async function updateBreaking(id, patch) {
  const payload = { ...patch }
  if (payload.image_url === '' || payload.image_url == null) delete payload.image_url
  const { data, error } = await supabase.from('breaking_news').update(payload).eq('id', id).select()
  if (error) throw wrapError(error)
  return Array.isArray(data) ? data[0] : data
}

export async function deleteBreaking(id) {
  const { error } = await supabase.from('breaking_news').delete().eq('id', id)
  if (error) throw wrapError(error)
  return true
}

export async function listBreakingPaged({ page = 1, pageSize = 50, status } = {}) {
  try {
    if (page < 1) page = 1
    const from = (page - 1) * pageSize
    const to = from + pageSize
    let q = supabase
      .from('breaking_news')
      .select('*')
      .order('created_at', { ascending: false })
      .range(from, to)
    if (status) q = q.eq('status', status)
    const { data, error } = await q
    if (error) throw error
    const items = Array.isArray(data) ? data.slice(0, pageSize) : []
    const hasMore = (data?.length || 0) > pageSize
    return { items, page, hasMore, nextPage: hasMore ? page + 1 : null }
  } catch (e) {
    throw wrapError(e)
  }
}
