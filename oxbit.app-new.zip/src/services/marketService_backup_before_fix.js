﻿// Normalized market ticker fetchers for multiple exchanges
// Output shape for each item:
// { symbol, base, last, changePct, quoteVolume }

import axios from 'axios'

export async function fetchSpotTickers(exchange = 'binance') {
  const EX = {
    binance: 'https://api.binance.com/api/v3/ticker/24hr',
    bybit: 'https://api.bybit.com/v5/market/tickers?category=spot',
    okx: 'https://www.okx.com/api/v5/market/tickers?instType=SPOT',
    bitget: 'https://api.bitget.com/api/spot/v1/market/tickers',
  }
  let list = []

  // Upbit KRW spot (native KRW)
  if (exchange === 'upbit-krw') {
    // 1) markets list
    const marketsRes = await axios.get('https://api.upbit.com/v1/market/all?isDetails=false', { timeout: 15000 })
    const markets = (Array.isArray(marketsRes.data) ? marketsRes.data : [])
      .filter((m) => String(m.market || '').startsWith('KRW-'))
      .map((m) => m.market)
    if (markets.length === 0) return []

    // 2) chunked ticker requests (<=100 per request)
    const chunks = []
    for (let i = 0; i < markets.length; i += 100) chunks.push(markets.slice(i, i + 100))
    const acc = []
    for (const c of chunks) {
      const url = `https://api.upbit.com/v1/ticker?markets=${encodeURIComponent(c.join(','))}`
      const res = await axios.get(url, { timeout: 15000 })
      const arr = Array.isArray(res.data) ? res.data : []
      acc.push(...arr)
    }
    list = acc.map((t) => ({
      symbol: String(t.market || ''), // e.g., KRW-BTC
      base: String(t.market || '').replace(/^KRW-/, ''),
      last: Number(t.trade_price),
      changePct: Number(t.signed_change_rate) * 100,
      quoteVolume: Number(t.acc_trade_price_24h), // already KRW
    })).filter((r) => r.base && isFinite(r.last))
    // sort by 24h quote volume desc
    return list.sort((a, b) => (isFinite(b.quoteVolume) ? b.quoteVolume : 0) - (isFinite(a.quoteVolume) ? a.quoteVolume : 0))
  }

  // Bithumb KRW spot
  if (exchange === 'bithumb-krw') {
    const res = await axios.get('https://api.bithumb.com/public/ticker/ALL_KRW', { timeout: 15000 })
    const o = res.data?.data || {}
    list = Object.keys(o)
      .filter((k) => k && k !== 'date')
      .map((k) => {
        const t = o[k] || {}
        const base = String(k).toUpperCase()
        const last = Number(t.closing_price)
        const changePct = Number(t.fluctate_rate_24H ?? t.fluctate_rate_24h ?? 0)
        const qv = Number(t.acc_trade_value_24H ?? t.acc_trade_value_24h ?? 0)
        return { symbol: `KRW-${base}`, base, last, changePct, quoteVolume: qv }
      })
      .filter((r) => r.base && isFinite(r.last))
    return list.sort((a, b) => (isFinite(b.quoteVolume) ? b.quoteVolume : 0) - (isFinite(a.quoteVolume) ? a.quoteVolume : 0))
  }

  // Coinone KRW spot
  if (exchange === 'coinone-krw') {
    const res = await axios.get('https://api.coinone.co.kr/public/v2/ticker_new/ALL_KRW', { timeout: 15000 })
    const o = res.data?.tickers || res.data?.result || {}
    list = Object.keys(o)
      .map((k) => {
        const t = o[k] || {}
        const base = String(k).toUpperCase()
        const last = Number(t.last ?? t.closing_price)
        const y = Number(t.yesterday_last ?? t.yesterday_closing_price)
        const changePct = isFinite(last) && isFinite(y) && y > 0 ? ((last - y) / y) * 100 : 0
        const vol = Number(t.volume ?? t.volume_24h ?? 0) // base volume
        const qv = isFinite(vol) && isFinite(last) ? vol * last : vol
        return { symbol: `KRW-${base}`, base, last, changePct, quoteVolume: qv }
      })
      .filter((r) => r.base && isFinite(r.last))
    return list.sort((a, b) => (isFinite(b.quoteVolume) ? b.quoteVolume : 0) - (isFinite(a.quoteVolume) ? a.quoteVolume : 0))
  }

  // Korbit KRW spot
  if (exchange === 'korbit-krw') {
    const res = await axios.get('https://api.korbit.co.kr/v1/ticker/detailed/all', { timeout: 15000 })
    const o = res.data || {}
    list = Object.keys(o)
      .filter((pair) => pair && pair.endsWith('_krw'))
      .map((pair) => {
        const t = o[pair] || {}
        const base = String(pair.split('_')[0] || '').toUpperCase()
        const last = Number(t.last)
        const changePct = Number(t.changePercent ?? 0)
        const vol = Number(t.volume ?? 0)
        const qv = isFinite(vol) && isFinite(last) ? vol * last : vol
        return { symbol: `KRW-${base}`, base, last, changePct, quoteVolume: qv }
      })
      .filter((r) => r.base && isFinite(r.last))
    return list.sort((a, b) => (isFinite(b.quoteVolume) ? b.quoteVolume : 0) - (isFinite(a.quoteVolume) ? a.quoteVolume : 0))
  }

  const src = EX[exchange] || EX.binance
  const res = await axios.get(src, { timeout: 15000 })

  if (exchange === 'binance') {
    const arr = Array.isArray(res.data) ? res.data : []
    list = arr.map((t) => ({
      symbol: t.symbol,
      base: t.symbol?.replace(/USDT$/, '') || t.symbol,
      last: Number(t.lastPrice),
      changePct: Number(t.priceChangePercent),
      quoteVolume: Number(t.quoteVolume),
    }))
  } else if (exchange === 'bybit') {
    const arr = res.data?.result?.list || []
    list = arr.map((t) => ({
      symbol: t.symbol,
      base: (t.symbol || '').replace(/USDT$/, ''),
      last: Number(t.lastPrice),
      changePct: (Number(t.price24hPcnt) || 0) * 100,
      quoteVolume: Number(t.volume24h),
    }))
  } else if (exchange === 'okx') {
    const arr = res.data?.data || []
    list = arr.map((t) => {
      const inst = t.instId || ''
      const [base] = inst.split('-')
      return {
        symbol: inst,
        base,
        last: Number(t.last),
        changePct: Number(t.change24h) || 0,
        quoteVolume: Number(t.vol24h || 0),
      }
    })
  } else if (exchange === 'bitget') {
    const arr = res.data?.data || []
    list = arr.map((t) => ({
      symbol: String(t.symbol || ''), // e.g., BTCUSDT
      base: String(t.symbol || '').replace(/USDT$/, ''),
      last: Number(t.close),
      changePct: Number(t.change) || Number(t.changeUtc) || Number(t.change24h) || 0,
      quoteVolume: Number(t.quoteVol24h || t.baseVol24h || 0),
    }))
  }

  // Coinbase: fetch products then per-product ticker (USD/USDT)
  if (exchange === 'coinbase') {
    const productsRes = await axios.get('https://api.exchange.coinbase.com/products', { timeout: 15000 })
    const products = Array.isArray(productsRes.data) ? productsRes.data : []
    const targets = products.filter((p) => /-(USDT|USD)$/.test(String(p.id))).slice(0, 200)
    const out = []
    const limit = 8
    for (let i = 0; i < targets.length; i += limit) {
      const chunk = targets.slice(i, i + limit)
      const rows = await Promise.all(
        chunk.map(async (p) => {
          try {
            const url = `https://api.exchange.coinbase.com/products/${encodeURIComponent(p.id)}/ticker`
            const t = await axios.get(url, { timeout: 15000 })
            const price = Number(t.data?.price)
            const [base, quote] = String(p.id).split('-')
            if (!base || !quote || !isFinite(price)) return null
            return { symbol: p.id, base, quote, last: price, changePct: 0, quoteVolume: 0 }
          } catch {
            return null
          }
        })
      )
      rows.forEach((r) => { if (r) out.push(r) })
    }
    return out
  }

  // Normalize: USDT quote only, sort by quote volume desc
  return list
    .filter((r) => r.base && isFinite(r.last) && String(r.symbol).toUpperCase().endsWith('USDT'))
    .sort((a, b) => (isFinite(b.quoteVolume) ? b.quoteVolume : 0) - (isFinite(a.quoteVolume) ? a.quoteVolume : 0))
}

