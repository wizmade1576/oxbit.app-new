// Centralized coin icon URL provider
// Priority: custom map -> cryptoicons CDN -> optional local path (public/coins/SYMBOL.png)

const CUSTOM_ICON_MAP = {
  // Add special/novel tickers here if you want guaranteed icons
  // Example:
  // TRUMP: '/coins/TRUMP.png',
  // VIRTUAL: '/coins/VIRTUAL.png',
}

export function getCoinIcon(symbol, { size = 64 } = {}) {
  const s = String(symbol || '').toUpperCase()
  if (!s) return null
  if (CUSTOM_ICON_MAP[s]) return CUSTOM_ICON_MAP[s]
  // Cryptoicons CDN (covers most majors, dark-friendly round icons)
  const cdn = `https://cryptoicons.org/api/icon/${s.toLowerCase()}/${size}`
  return cdn
}

// Multiple candidates to improve success rate across symbols
export function getCoinIconCandidates(symbol, { size = 64 } = {}) {
  const s = String(symbol || '').toUpperCase()
  if (!s) return []
  const first = CUSTOM_ICON_MAP[s]
  const lower = s.toLowerCase()
  const rest = [
    // SpotHQ cryptocurrency-icons via jsDelivr
    `https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/128/color/${lower}.png`,
    // Cryptoicons
    `https://cryptoicons.org/api/icon/${lower}/${size}`,
    // Raw fallback to the same repo (direct GitHub link)
    `https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/128/color/${lower}.png`,
  ]
  return first ? [first, ...rest] : rest
}

export function setCustomIcon(symbol, url) {
  const s = String(symbol || '').toUpperCase()
  if (!s || !url) return
  CUSTOM_ICON_MAP[s] = url
}

export function getCustomIconMap() {
  return { ...CUSTOM_ICON_MAP }
}
