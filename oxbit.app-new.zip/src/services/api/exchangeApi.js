// Simple REST fetchers; replace with proxy if CORS blocks

export async function fetchBinanceKlines(symbol = 'BTCUSDT', interval = '1m', limit = 500) {
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
  const res = await fetch(url)
  if (!res.ok) throw new Error('Binance klines error')
  const arr = await res.json()
  return arr.map((k) => ({
    openTime: k[0], open: Number(k[1]), high: Number(k[2]), low: Number(k[3]), close: Number(k[4]), volume: Number(k[5]), closeTime: k[6],
  }))
}

