// Mock on-chain indicators; replace with real sources later

export async function fetchOnchainIndicators(symbol = 'BTC') {
  // Fake data: values and mini series for sparklines
  const now = Date.now()
  const genSeries = (base) => Array.from({ length: 24 }, (_, i) => ({ t: now - (23 - i) * 3600_000, v: base * (0.98 + Math.random() * 0.04) }))

  return {
    realizedPrice: { value: 58000, change: 1.2, series: genSeries(58000) },
    exchangeInflow: { value: 12450, change: -2.1, series: genSeries(12000) },
    exchangeOutflow: { value: 15120, change: 3.4, series: genSeries(15000) },
    stablecoinInflow: { value: 980_000_000, change: 0.6, series: genSeries(9.8e8) },
    minerReserve: { value: 1_840_000, change: -0.2, series: genSeries(1.84e6) },
    whaleTransfer: { value: 12_500, change: 4.1, series: genSeries(12500) },
  }
}

