// RLS verification script
// Env: SUPABASE_URL, SUPABASE_ANON_KEY, ADMIN_EMAIL, ADMIN_PASSWORD, USER_EMAIL, USER_PASSWORD
import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL;
const anon = process.env.SUPABASE_ANON_KEY;

function client(jwt) {
  return createClient(url, anon, {
    global: jwt ? { headers: { Authorization: `Bearer ${jwt}` } } : undefined,
  });
}

async function signIn(email, password) {
  const c = createClient(url, anon);
  const { data, error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.session.access_token;
}

async function queryBreakingNews(caption, jwt) {
  const c = client(jwt);
  const { data, error } = await c
    .from('breaking_news')
    .select('id,title,status,created_at')
    .order('created_at', { ascending: false });
  console.log(`\n[${caption}]`, error ? error.message : data);
}

async function tryInsertBreakingNews(caption, jwt) {
  const c = client(jwt);
  const payload = { title: `RLS test ${caption}`, status: 'public' };
  const { data, error } = await c.from('breaking_news').insert(payload).select();
  console.log(`\n[${caption} insert]`, error ? error.message : data);
}

async function main() {
  if (!url || !anon) {
    console.error('Missing SUPABASE_URL or SUPABASE_ANON_KEY');
    process.exit(1);
  }

  await queryBreakingNews('anon', null);
  await tryInsertBreakingNews('anon', null);

  const userEmail = process.env.USER_EMAIL;
  const userPass = process.env.USER_PASSWORD;
  if (userEmail && userPass) {
    const userJwt = await signIn(userEmail, userPass);
    await queryBreakingNews('user', userJwt);
    await tryInsertBreakingNews('user', userJwt);
  } else {
    console.log('\n[user] skipped (set USER_EMAIL & USER_PASSWORD)');
  }

  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPass = process.env.ADMIN_PASSWORD;
  if (adminEmail && adminPass) {
    const adminJwt = await signIn(adminEmail, adminPass);
    await queryBreakingNews('admin', adminJwt);
    await tryInsertBreakingNews('admin', adminJwt);
  } else {
    console.log('\n[admin] skipped (set ADMIN_EMAIL & ADMIN_PASSWORD)');
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});

