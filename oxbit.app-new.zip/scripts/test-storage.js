// Storage policy verification script
// Pre-req: create a local file test.txt
// Env: SUPABASE_URL, SUPABASE_ANON_KEY, ADMIN_EMAIL, ADMIN_PASSWORD, USER_EMAIL, USER_PASSWORD
import { createClient } from '@supabase/supabase-js';
import fs from 'fs';

const url = process.env.SUPABASE_URL;
const anon = process.env.SUPABASE_ANON_KEY;

async function signIn(email, password) {
  const c = createClient(url, anon);
  const { data, error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.session.access_token;
}

function client(jwt) {
  return createClient(url, anon, {
    global: jwt ? { headers: { Authorization: `Bearer ${jwt}` } } : undefined,
  });
}

async function upload(caption, jwt) {
  const c = client(jwt);
  const path = `tests/${caption}-test.txt`;
  const file = fs.readFileSync('test.txt');
  const { data, error } = await c.storage
    .from('breaking')
    .upload(path, file, { upsert: true, contentType: 'text/plain' });
  console.log(`\n[${caption} upload]`, error ? error.message : data);
}

async function readList(caption, jwt) {
  const c = client(jwt);
  const { data, error } = await c.storage.from('breaking').list('tests', { limit: 10 });
  console.log(`\n[${caption} list]`, error ? error.message : data?.map((f) => f.name));
}

async function main() {
  if (!url || !anon) {
    console.error('Missing SUPABASE_URL or SUPABASE_ANON_KEY');
    process.exit(1);
  }

  await readList('anon', null);
  await upload('anon', null);

  const userEmail = process.env.USER_EMAIL;
  const userPass = process.env.USER_PASSWORD;
  if (userEmail && userPass) {
    const userJwt = await signIn(userEmail, userPass);
    await upload('user', userJwt);
  } else {
    console.log('\n[user] upload skipped (set USER_EMAIL & USER_PASSWORD)');
  }

  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPass = process.env.ADMIN_PASSWORD;
  if (adminEmail && adminPass) {
    const adminJwt = await signIn(adminEmail, adminPass);
    await upload('admin', adminJwt);
    await readList('admin', adminJwt);
  } else {
    console.log('\n[admin] upload/list skipped (set ADMIN_EMAIL & ADMIN_PASSWORD)');
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});

