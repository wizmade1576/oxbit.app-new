// Dev helper: trigger the breaking-ingest edge function locally or on deployed project
// Usage:
//  node scripts/triggerBreakingIngest.mjs http://localhost:54321/functions/v1/breaking-ingest
//  RSS override example:
//  node scripts/triggerBreakingIngest.mjs http://localhost:54321/functions/v1/breaking-ingest "https://www.binance.com/en/support/announcement/rss,https://www.coindesk.com/arc/outboundfeeds/rss/"

import fetch from 'node-fetch'

const endpoint = process.argv[2]
const rss = process.argv[3]
if (!endpoint) {
  console.error('Usage: node scripts/triggerBreakingIngest.mjs <edge-url> [rss-list]')
  process.exit(1)
}

const url = new URL(endpoint)
if (rss) url.searchParams.set('rss', rss)

const res = await fetch(url.toString(), { method: 'POST' })
const txt = await res.text()
console.log(res.status, txt)

