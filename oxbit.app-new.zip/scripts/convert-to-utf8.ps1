<#
  Convert text files from UTF-16 (LE/BE) to UTF-8.
  - Scans common project file extensions
  - Skips typical build/output folders
  - Idempotent: only rewrites when BOM indicates UTF‑16
#>

param(
  [string]$Root = (Resolve-Path "$PSScriptRoot/..\").Path
)

$exts = @('*.jsx','*.tsx','*.js','*.ts','*.json','*.css','*.sql','*.md','*.html','*.yml','*.yaml','*.toml','*.cjs','*.mjs')

Write-Host "Scanning for UTF-16 files under" $Root

$files = Get-ChildItem -Path $Root -Recurse -File -Include $exts |
  Where-Object { $_.FullName -notmatch "\\node_modules\\|\\dist\\|\\build\\|\\.git\\|\\coverage\\|\\.next\\|\\out\\" }

$converted = @()

foreach ($f in $files) {
  try {
    $fs = [System.IO.File]::Open($f.FullName, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
    try {
      $b0 = $fs.ReadByte()
      $b1 = $fs.ReadByte()
    } finally {
      $fs.Close()
    }

    $enc = $null
    if ($b0 -eq 0xFF -and $b1 -eq 0xFE) { $enc = 'Unicode' }           # UTF-16 LE
    elseif ($b0 -eq 0xFE -and $b1 -eq 0xFF) { $enc = 'BigEndianUnicode' } # UTF-16 BE

    if ($enc) {
      $raw = Get-Content -LiteralPath $f.FullName -Raw -Encoding $enc
      # Rewrite as UTF-8 (with BOM on Windows PowerShell). For PS7+, you may switch to -Encoding utf8NoBOM.
      Set-Content -LiteralPath $f.FullName -Value $raw -Encoding utf8
      $converted += $f.FullName
      Write-Host "Converted ->" $f.FullName
    }
  } catch {
    Write-Warning "Skip (error): $($f.FullName) :: $($_.Exception.Message)"
  }
}

Write-Host "Done. Converted" $converted.Count "file(s)."
if ($converted.Count -gt 0) {
  Write-Host "Sample:" ($converted | Select-Object -First 5 | ForEach-Object { " - $_" })
}

