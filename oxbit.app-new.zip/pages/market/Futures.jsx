export { default } from '../../src/pages/Market/Futures.jsx'
