export { default } from '../../src/pages/Market/Index.jsx'
