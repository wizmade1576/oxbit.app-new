export { default } from '../../src/pages/Market/SpotGlobal.jsx'
