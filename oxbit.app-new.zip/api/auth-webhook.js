import { createClient } from '@supabase/supabase-js'

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' })
    return
  }

  const secret = process.env.WEBHOOK_SECRET
  if (!secret || req.headers['x-webhook-secret'] !== secret) {
    res.status(401).json({ error: 'Unauthorized' })
    return
  }

  try {
    const body = req.body || {}
    const event = body?.type || body?.event || ''
    const user = body?.user || body?.record || body?.data?.user || null
    if (!user?.id) {
      res.status(400).json({ error: 'Missing user' })
      return
    }

    const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL
    const serviceKey = process.env.SUPABASE_SERVICE_KEY
    if (!url || !serviceKey) {
      res.status(500).json({ error: 'Server not configured' })
      return
    }
    const admin = createClient(url, serviceKey)

    const md = user.user_metadata || {}
    const payload = {
      id: user.id,
      full_name: md.full_name || md.name || null,
      nickname: md.nickname || null,
      phone: (user.phone || md.phone || null),
      gender: md.gender || null,
      interest: md.interest || null,
      signup_source: md.signup_source || md.source || null,
      signup_referrer: md.signup_referrer || md.referrer || null,
      signup_meta: md.signup_meta || md.utm || null,
      updated_at: new Date().toISOString(),
    }
    const { error } = await admin.from('profiles').upsert(payload, { onConflict: 'id' })
    if (error) throw error

    res.status(200).json({ ok: true, event })
  } catch (e) {
    res.status(500).json({ error: String(e?.message || e) })
  }
}
