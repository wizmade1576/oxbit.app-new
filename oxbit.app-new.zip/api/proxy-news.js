export const config = { runtime: 'edge' }

const CS_ENDPOINT = 'https://api.coinstats.app/public/v1/news'
const CP_ENDPOINT = 'https://cryptopanic.com/api/v1/posts/'

async function getCoinStats(limit) {
  const url = `${CS_ENDPOINT}?skip=0&limit=${limit}`
  const res = await fetch(url, { headers: { 'user-agent': 'oxbit.app-proxy' } })
  if (!res.ok) throw new Error('coinstats_fail')
  const data = await res.json()
  const list = data?.news || []
  return list.slice(0, limit).map((n) => ({
    id: n.id || n._id || slugify(n.title),
    slug: slugify(n.title),
    title: n.title,
    url: n.link || n.url,
    source: n.source || 'CoinStats',
    published_at: n.feedDate ? new Date(n.feedDate).toISOString() : new Date().toISOString(),
    image: n.imgURL || n.image || '',
    description: n.description || n.text || '',
  }))
}

async function getCryptoPanic(limit, token) {
  if (!token) return []
  const url = `${CP_ENDPOINT}?auth_token=${token}&kind=news&public=true`
  const res = await fetch(url, { headers: { 'user-agent': 'oxbit.app-proxy' } })
  if (!res.ok) throw new Error('cryptopanic_fail')
  const data = await res.json()
  const list = data?.results || []
  return list.slice(0, limit).map((n) => ({
    id: String(n.id || slugify(n.title)),
    slug: slugify(n.title),
    title: n.title,
    url: n.url,
    source: n.domain || 'CryptoPanic',
    published_at: n.published_at ? new Date(n.published_at).toISOString() : new Date().toISOString(),
    image: '',
    description: n.slug || n.title || '',
  }))
}

function slugify(s = '') {
  return String(s).toLowerCase().replace(/[^a-z0-9가-힣\s-]/g, '').trim().replace(/\s+/g, '-')
}

export default async function handler(req) {
  try {
    const { searchParams } = new URL(req.url)
    const limit = Math.max(1, Math.min(100, Number(searchParams.get('limit') || '20')))
    const ttl = Math.max(1, Number(searchParams.get('ttl') || process.env.NEWS_TTL || 60))
    const swr = Math.max(0, Number(searchParams.get('swr') || process.env.NEWS_SWR || 300))
    const token = process.env.CRYPTOPANIC_TOKEN || process.env.VITE_CRYPTOPANIC_TOKEN

    const [cs, cp] = await Promise.allSettled([
      getCoinStats(limit),
      getCryptoPanic(limit, token),
    ])
    const a = cs.status === 'fulfilled' ? cs.value : []
    const b = cp.status === 'fulfilled' ? cp.value : []
    const merged = [...a, ...b]
    const seen = new Set()
    const uniq = []
    for (const it of merged) {
      const key = String(it.id || it.slug)
      if (seen.has(key)) continue
      seen.add(key)
      uniq.push(it)
    }

    return new Response(JSON.stringify({ news: uniq }), {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        // Cache on Vercel Edge CDN (configurable)
        'Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
        'CDN-Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
        'Vercel-CDN-Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
      },
    })
  } catch (e) {
    return new Response(JSON.stringify({ news: [], error: String(e && e.message || 'error') }), {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    })
  }
}
