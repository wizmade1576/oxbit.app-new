export default async function handler(req, res) {
  try {
    const url = req.query.url
    if (!url) return res.status(400).send('missing url')
    const target = new URL(url)

    const ALLOW = new Set([
      'query1.finance.yahoo.com',
      'query2.finance.yahoo.com',
      'finance.yahoo.com',
      'api.binance.com',
      'fapi.binance.com',
      'api.coingecko.com',
      'www.okx.com',
      'api.exchange.coinbase.com',
      'www.google.com',
      'stooq.com',
      'stooq.pl',
    ])

    if (!/^https?:$/.test(target.protocol)) {
      return res.status(400).send('invalid protocol')
    }
    if (!ALLOW.has(target.hostname)) {
      return res.status(403).send('host not allowed')
    }

    const r = await fetch(target.toString(), {
      headers: {
        'user-agent': 'vercel-proxy/1.0 (+demo)',
        accept: 'application/json,text/plain,*/*',
        'accept-language': 'ko,en;q=0.9',
      },
    })
    const buf = Buffer.from(await r.arrayBuffer())
    const ct = r.headers.get('content-type')
    if (ct) res.setHeader('content-type', ct)
    res.setHeader('cache-control', 'public, max-age=15')
    res.status(r.status).send(buf)
  } catch (e) {
    res.status(502).send('proxy error')
  }
}

