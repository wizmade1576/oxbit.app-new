import fs from 'fs'
import path from 'path'

const BUNDLE_PATH = path.join(process.cwd(), 'data', 'schedule.json')
const TMP_PATH = path.join('/tmp', 'schedule.json')

function readAll() {
  try {
    if (fs.existsSync(TMP_PATH)) {
      return JSON.parse(fs.readFileSync(TMP_PATH, 'utf-8'))
    }
  } catch {}
  try {
    return JSON.parse(fs.readFileSync(BUNDLE_PATH, 'utf-8'))
  } catch {
    return []
  }
}

function writeAll(items) {
  // On Vercel, write to /tmp (ephemeral) so POST/PUT/DELETE work for session
  try {
    fs.writeFileSync(TMP_PATH, JSON.stringify(items, null, 2))
    return true
  } catch {
    return false
  }
}

function toNum(d) { try { return Number(String(d).replace(/[-]/g, '')) } catch { return 0 } }

export default async function handler(req, res) {
  try {
    if (req.method === 'GET') {
      const { q = '', category, from, to, sort = 'desc', page = '1', pageSize = '20' } = req.query
      const items = readAll()
      const ql = String(q).trim().toLowerCase()
      const filtered = items.filter((it) => {
        const okCat = category ? String(it.category) === String(category) : true
        const okQ = ql ? (it.title?.toLowerCase().includes(ql) || (it.tags||[]).join(' ').toLowerCase().includes(ql)) : true
        const dn = toNum(it.date)
        const okFrom = from ? dn >= toNum(from) : true
        const okTo = to ? dn <= toNum(to) : true
        return okCat && okQ && okFrom && okTo
      })
      filtered.sort((a,b)=> (toNum(a.date)-toNum(b.date))*(sort==='asc'?1:-1))
      const p = Math.max(1, parseInt(page,10)||1)
      const ps = Math.max(1, Math.min(100, parseInt(pageSize,10)||20))
      const start = (p-1)*ps
      const slice = filtered.slice(start, start+ps)
      res.status(200).json({ items: slice, total: filtered.length, page: p, pageSize: ps })
      return
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {})
      const items = readAll()
      const id = body.id || `id-${Date.now()}`
      const item = {
        id,
        date: body.date,
        day: body.day,
        title: body.title,
        category: body.category || 'event',
        tags: Array.isArray(body.tags) ? body.tags : [],
        link: body.link || '',
        source: body.source || '',
        desc: body.desc || '',
        memo: body.memo || '',
        attachments: Array.isArray(body.attachments) ? body.attachments : [],
      }
      items.push(item)
      writeAll(items)
      res.status(201).json(item)
      return
    }

    if (req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {})
      const { id } = body
      if (!id) { res.status(400).json({ error: 'Missing id' }); return }
      const items = readAll()
      const i = items.findIndex((x)=>x.id===id)
      if (i < 0) { res.status(404).json({ error: 'Not found' }); return }
      items[i] = { ...items[i], ...body }
      writeAll(items)
      res.status(200).json(items[i])
      return
    }

    if (req.method === 'DELETE') {
      const { id } = req.query
      if (!id) { res.status(400).json({ error: 'Missing id' }); return }
      const items = readAll().filter((x)=>x.id!==id)
      writeAll(items)
      res.status(204).end()
      return
    }

    res.setHeader('Allow', ['GET','POST','PUT','DELETE'])
    res.status(405).end('Method Not Allowed')
  } catch (e) {
    res.status(500).json({ error: String(e?.message||e) })
  }
}

