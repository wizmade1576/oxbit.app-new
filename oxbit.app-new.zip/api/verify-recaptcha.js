export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' })
    return
  }
  try {
    const { token } = req.body || {}
    if (!token) {
      res.status(400).json({ success: false, error: 'Missing token' })
      return
    }
    const secret = process.env.RECAPTCHA_SECRET
    if (!secret) {
      // If not configured, fail-closed or mark as dev-ok
      res.status(200).json({ success: false, error: 'Server not configured' })
      return
    }
    const params = new URLSearchParams({ secret, response: token })
    const r = await fetch('https://www.google.com/recaptcha/api/siteverify', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
    })
    const j = await r.json()
    res.status(200).json({ success: !!j.success, score: j.score ?? null, action: j.action ?? null })
  } catch (e) {
    res.status(500).json({ success: false, error: String(e?.message || e) })
  }
}

