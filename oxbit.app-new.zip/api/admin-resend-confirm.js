import { createClient } from '@supabase/supabase-js'

export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed' })
      return
    }

    const auth = req.headers.authorization || ''
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : ''
    if (!token) {
      res.status(401).json({ error: 'Missing Authorization bearer token' })
      return
    }

    const { email, reason, note } = req.body || {}
    if (!email) {
      res.status(400).json({ error: 'Invalid payload: require { email }' })
      return
    }

    const url = process.env.SUPABASE_URL
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
    if (!url || !serviceKey) {
      res.status(500).json({ error: 'Server not configured with SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY' })
      return
    }

    const admin = createClient(url, serviceKey)

    // Verify caller
    const { data: userData, error: authErr } = await admin.auth.getUser(token)
    if (authErr || !userData?.user?.id) {
      res.status(401).json({ error: 'Invalid or expired token' })
      return
    }
    const callerId = userData.user.id

    // Check caller is admin via profiles table
    const { data: prof } = await admin
      .from('profiles')
      .select('role')
      .eq('id', callerId)
      .maybeSingle()

    if (String(prof?.role || '').toLowerCase() !== 'admin') {
      res.status(403).json({ error: 'Forbidden: admin only' })
      return
    }

    // Resend confirmation
    const { error: resendErr } = await admin.auth.resend({ type: 'signup', email })
    if (resendErr) {
      res.status(400).json({ error: resendErr.message })
      return
    }

    // Resolve target id for logging
    let targetId = null
    try {
      const { data } = await admin.rpc('admin_list_users', { search: email, page_size: 1, page_no: 1, sort_by: 'created_at', sort_dir: 'desc' })
      targetId = data?.[0]?.id || null
    } catch {}
    await admin.from('user_moderation_logs').insert({ user_id: targetId, actor_id: callerId, action: 'resend_confirm', reason: reason || null, note: note || null, meta: { email } })

    res.status(200).json({ ok: true })
  } catch (e) {
    res.status(500).json({ error: String(e?.message || e) })
  }
}

