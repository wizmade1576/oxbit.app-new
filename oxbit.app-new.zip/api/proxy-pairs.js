export const config = { runtime: 'edge' }

const EX = {
  binance: 'https://api.binance.com/api/v3/ticker/24hr',
  bybit: 'https://api.bybit.com/v5/market/tickers?category=spot',
  okx: 'https://www.okx.com/api/v5/market/tickers?instType=SPOT',
}

async function j(url) {
  const r = await fetch(url, { headers: { 'user-agent': 'oxbit.app-proxy' } })
  if (!r.ok) throw new Error('fetch_fail')
  return r.json()
}

function normalize({ ex, data }) {
  if (ex === 'binance') {
    const list = Array.isArray(data) ? data : []
    return list.map((t) => ({
      ex,
      symbol: t.symbol,
      base: t.symbol.replace(/USDT$/,'') || t.symbol,
      quote: 'USDT',
      last: Number(t.lastPrice),
      changePct: Number(t.priceChangePercent),
      quoteVolume: Number(t.quoteVolume),
    }))
  }
  if (ex === 'bybit') {
    const list = data?.result?.list || []
    return list.map((t) => {
      const s = t.symbol || '' // e.g., BTCUSDT
      return {
        ex,
        symbol: s,
        base: s.replace(/USDT$/,'') || s,
        quote: 'USDT',
        last: Number(t.lastPrice),
        changePct: Number(t.price24hPcnt) * 100 || Number(t.price24hPcnt), // v5 returns fraction; guard
        quoteVolume: Number(t.volume24h),
      }
    })
  }
  if (ex === 'okx') {
    const list = data?.data || []
    return list.map((t) => {
      const inst = t.instId || '' // BTC-USDT
      const [base, quote] = inst.split('-')
      return {
        ex,
        symbol: `${base}${quote}`,
        base,
        quote,
        last: Number(t.last),
        changePct: Number(t.sodUtc0) ? ((Number(t.last) - Number(t.sodUtc0)) / Number(t.sodUtc0)) * 100 : Number(t.change24h) || 0,
        quoteVolume: Number(t.volCcy24h || t.vol24h || 0),
      }
    })
  }
  return []
}

export default async function handler(req) {
  const { searchParams } = new URL(req.url)
  const ex = (searchParams.get('ex') || 'binance').toLowerCase()
  const limit = Math.max(1, Math.min(100, Number(searchParams.get('limit') || '20')))
  const ttl = Math.max(1, Number(searchParams.get('ttl') || process.env.PAIRS_TTL || 60))
  const swr = Math.max(0, Number(searchParams.get('swr') || process.env.PAIRS_SWR || 300))

  try {
    const src = EX[ex] || EX.binance
    const [tick, rate] = await Promise.all([
      j(src),
      j('https://api.exchangerate.host/latest?base=USD&symbols=KRW'),
    ])
    const usdKrw = rate?.rates?.KRW || null
    let list = normalize({ ex, data: tick })
      .filter((r) => r.quote === 'USDT' && isFinite(r.last))

    // 정렬: 거래량 기준 상위
    list.sort((a, b) => (isFinite(b.quoteVolume) ? b.quoteVolume : 0) - (isFinite(a.quoteVolume) ? a.quoteVolume : 0))
    list = list.slice(0, limit)

    // Upbit KRW price for kimchi premium (available bases only)
    let kimchiMap = {}
    try {
      const bases = Array.from(new Set(list.map((r) => r.base.toUpperCase())))
        .filter((b) => /^[A-Z0-9]{2,10}$/.test(b))
      const markets = bases.map((b) => `KRW-${b}`).join(',')
      const up = await j(`https://api.upbit.com/v1/ticker?markets=${encodeURI(markets)}`)
      if (Array.isArray(up)) {
        up.forEach((t) => {
          if (t?.market?.startsWith('KRW-')) {
            const b = t.market.replace('KRW-','').toUpperCase()
            kimchiMap[b] = Number(t.trade_price)
          }
        })
      }
    } catch {}

    const rows = list.map((r) => {
      const lastKrw = usdKrw ? r.last * usdKrw : null
      const upbitKrw = kimchiMap[r.base.toUpperCase()]
      const kimchiPct = (lastKrw && upbitKrw) ? ((upbitKrw / lastKrw) - 1) * 100 : null
      return { ...r, lastKrw, kimchiPct }
    })

    return new Response(JSON.stringify({ usdKrw, rows }), {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
        'CDN-Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
        'Vercel-CDN-Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
      },
    })
  } catch (e) {
    return new Response(JSON.stringify({ rows: [], error: String(e?.message || 'error') }), {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    })
  }
}

