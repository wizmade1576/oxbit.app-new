export const config = { runtime: 'edge' }

const CS_ENDPOINT = 'https://api.coinstats.app/public/v1/coins?skip=0&limit=50&currency=USD'
const CG_SIMPLE = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true'
const CG_GLOBAL = 'https://api.coingecko.com/api/v3/global'
const ER_HOST = 'https://api.exchangerate.host/latest?base=USD&symbols=KRW'
const COINBASE = 'https://api.coinbase.com/v2/exchange-rates?currency=USD'
const ER_API = 'https://open.er-api.com/v6/latest/USD'
const UPBIT = 'https://api.upbit.com/v1/ticker?markets=KRW-BTC,KRW-ETH'

async function j(url) {
  const res = await fetch(url, { headers: { 'user-agent': 'oxbit.app-proxy' } })
  if (!res.ok) throw new Error('fail')
  return res.json()
}

export default async function handler(req) {
  const { searchParams } = new URL(req.url)
  const ttl = Math.max(1, Number(searchParams.get('ttl') || process.env.METRICS_TTL || 60))
  const swr = Math.max(0, Number(searchParams.get('swr') || process.env.METRICS_SWR || 300))

  try {
    const [cs, cg, rate1, upbit, global, cb, er] = await Promise.allSettled([
      j(CS_ENDPOINT),
      j(CG_SIMPLE),
      j(ER_HOST),
      j(UPBIT),
      j(CG_GLOBAL),
      j(COINBASE),
      j(ER_API),
    ])

    let btcUsd = null, ethUsd = null, btcChange = null, ethChange = null
    if (cs.status === 'fulfilled') {
      const coins = cs.value?.coins || []
      const b = coins.find((c) => c.symbol === 'BTC')
      const e = coins.find((c) => c.symbol === 'ETH')
      btcUsd = b?.price ?? null
      ethUsd = e?.price ?? null
      btcChange = typeof b?.priceChange1d === 'number' ? b.priceChange1d : null
      ethChange = typeof e?.priceChange1d === 'number' ? e.priceChange1d : null
    }
    if ((btcUsd == null || ethUsd == null) && cg.status === 'fulfilled') {
      const b = cg.value?.bitcoin || {}
      const e = cg.value?.ethereum || {}
      if (btcUsd == null) btcUsd = typeof b.usd === 'number' ? b.usd : btcUsd
      if (ethUsd == null) ethUsd = typeof e.usd === 'number' ? e.usd : ethUsd
      if (btcChange == null) btcChange = typeof b.usd_24h_change === 'number' ? b.usd_24h_change : btcChange
      if (ethChange == null) ethChange = typeof e.usd_24h_change === 'number' ? e.usd_24h_change : ethChange
    }

    let usdKrw = null
    if (rate1.status === 'fulfilled') usdKrw = rate1.value?.rates?.KRW ?? null
    if (!usdKrw && cb.status === 'fulfilled') {
      const v = cb.value?.data?.rates?.KRW
      usdKrw = v ? Number(v) : null
    }
    if (!usdKrw && er.status === 'fulfilled') usdKrw = er.value?.rates?.KRW ?? null

    let krwBtc = null, krwEth = null
    if (upbit.status === 'fulfilled' && Array.isArray(upbit.value)) {
      const arr = upbit.value
      krwBtc = (arr.find((t) => t?.market === 'KRW-BTC') || arr[0])?.trade_price ?? null
      krwEth = (arr.find((t) => t?.market === 'KRW-ETH'))?.trade_price ?? null
    }

    let kimchiBtc = null
    if (btcUsd && usdKrw && krwBtc) {
      const globalKrw = btcUsd * usdKrw
      kimchiBtc = ((krwBtc / globalKrw) - 1) * 100
    }

    const dominance = global.status === 'fulfilled' ? (global.value?.data?.market_cap_percentage?.btc ?? null) : null

    const body = {
      btcUsd, btcChange,
      ethUsd, ethChange,
      usdKrw,
      krwBtc, krwEth,
      kimchiBtc,
      btcDominance: dominance,
    }

    return new Response(JSON.stringify(body), {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
        'CDN-Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
        'Vercel-CDN-Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${swr}`,
      },
    })
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e?.message || 'error') }), {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    })
  }
}

