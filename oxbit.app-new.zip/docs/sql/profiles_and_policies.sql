-- Create profiles table linked to auth.users
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text,
  phone text,
  gender text,
  interest text,
  avatar_url text,
  role text default 'user',
  updated_at timestamptz default now()
);

-- Enable Row Level Security
alter table public.profiles enable row level security;

-- Allow authenticated users to read their own row
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own
on public.profiles for select
to authenticated
using (auth.uid() = id);

-- Allow authenticated users to update their own row
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own
on public.profiles for update
to authenticated
using (auth.uid() = id);

-- Optional: insert own row (if you create rows from client instead of webhook)
drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own
on public.profiles for insert
to authenticated
with check (auth.uid() = id);

-- Storage bucket for avatars (create in Dashboard > Storage as `avatars`), then apply policies. 
-- Example storage policies (adjust as needed):
-- 1) Public read
--   (run in Storage policies UI)
--   (bucket_id = 'avatars') and (request.method = 'GET')
-- 2) Authenticated users can upload to their own folder
--   (bucket_id = 'avatars') and (auth.uid()::text = split_part(object.name, '/', 1)) and (request.method = 'POST')
-- 3) Authenticated users can update/delete files in their own folder
--   (bucket_id = 'avatars') and (auth.uid()::text = split_part(object.name, '/', 1)) and (request.method in ('PUT','DELETE'))
