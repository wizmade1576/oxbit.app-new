Vercel Beta Deploy (User + Admin projects)

Overview
- Two Vercel projects from the same repo:
  - User: all public pages (e.g. /, /breaking, /breaking/detail)
  - Admin: admin tools (e.g. /admin/breaking)
- SPA rewrites handled via vercel.json in the repo.

Prereqs
- Build locally: `npm ci && npm run build` (no errors)
- Env values ready:
  - `VITE_SUPABASE_URL` (Supabase Settings → API → Project URL)
  - `VITE_SUPABASE_ANON_KEY` (anon public key)

Create Vercel projects
1) User project
   - New Project → select this repo
   - Framework: Vite (auto)
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Environment Variables (Production + Preview):
     - `VITE_SUPABASE_URL`
     - `VITE_SUPABASE_ANON_KEY`
   - vercel.json already adds SPA rewrite for deep links.
   - Domain will look like: `YOUR-USER-PROJECT.vercel.app`.

2) Admin project
   - Create a second project from the same repo
   - Build/Output/Env same as user
   - Add a Redirect in Vercel UI (Project → Settings → Redirects):
     - Source: `/`
     - Destination: `/admin`
     - Status: 308
   - Domain will look like: `YOUR-ADMIN-PROJECT.vercel.app`.

Supabase setup
- Schema/RLS (one-time): run `supabase/sql/initial_schema.sql` in SQL Editor
- Realtime: run the block in `supabase/sql/admin_tools.sql` (breaking_news publication + replica identity)
- Admin role: upsert profile role for your admin email:
  ```sql
  insert into public.profiles(id, role)
  select id, 'admin' from auth.users where email='YOUR_EMAIL'
  on conflict (id) do update set role='admin';
  ```
- Auth/CORS:
  - Authentication → URL Configuration:
    - Site URL: `https://YOUR-USER-PROJECT.vercel.app`
    - Additional Redirect URLs: `https://YOUR-ADMIN-PROJECT.vercel.app`, `http://localhost:5173`
  - Settings → API → Allowed Origins (CORS): add both vercel domains and `http://localhost:5173`

App routing
- Ensure these routes exist in `src/App.tsx` (React Router v6):
  ```tsx
  import Breaking from './pages/Breaking.jsx'
  import BreakingDetail from './pages/BreakingDetail.jsx'
  // ...
  <Route path="/breaking" element={<Breaking />} />
  <Route path="/breaking/detail" element={<BreakingDetail />} />
  ```
  If you paste your Routes/children snippet, we can patch this in for you safely.

Verify
- User project:
  - `/breaking` list, search/filter, "더보기"
  - `/breaking/detail?id=...` detail + embed + related list
- Admin project:
  - `/admin/breaking` create/toggle/delete; toasts; realtime updates
- Realtime test:
  ```sql
  insert into public.breaking_news (title, body, status, important)
  values ('테스트', 'realtime', 'public', true);
  ```
  Changes should appear instantly in user list/ticker.

Rollback
- Vercel → Project → Deployments: promote previous build to rollback quickly.

