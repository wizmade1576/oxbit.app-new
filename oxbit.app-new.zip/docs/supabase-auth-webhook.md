Supabase Auth Webhook 연결 가이드

개요
- 회원가입/로그인 직후 사용자 메타데이터를 profiles 테이블에 동기화하는 서버리스 엔드포인트가 포함되어 있습니다.
- 엔드포인트: `/api/auth-webhook`

필수 환경 변수
- `VITE_SUPABASE_URL` 또는 `SUPABASE_URL`: Supabase 프로젝트 URL
- `SUPABASE_SERVICE_KEY`: Service Role Key (서버 전용)
- `WEBHOOK_SECRET`: 웹훅 보호용 비밀 값 (아래 헤더로 전달)

1) Vercel(또는 서버) 환경 변수 설정
```
SUPABASE_URL=https://<your-project>.supabase.co
SUPABASE_SERVICE_KEY=<service-role-key>
WEBHOOK_SECRET=<random-strong-secret>
```

2) Supabase 콘솔에서 Auth Webhook 등록
- Supabase > Authentication > Hooks (또는 Auth > Settings > Hooks)
- New Hook
  - Event: `user_signed_up` (필요 시 `user_updated`도 추가)
  - URL: `https://<your-domain>/api/auth-webhook`
  - Headers: `x-webhook-secret: <WEBHOOK_SECRET>`
  - Enabled: On

3) payload 예시
Supabase가 전송하는 본문은 환경에 따라 약간씩 다를 수 있습니다. 이 프로젝트의 핸들러는 아래 필드를 우선적으로 탐색합니다.
```json
{
  "type": "user_signed_up",
  "user": {
    "id": "uuid",
    "user_metadata": {
      "nickname": "닉네임",
      "phone": "010...",
      "gender": "male",
      "interest": "coin",
      "avatar_url": "https://..."
    }
  }
}
```

4) 동작
- `/api/auth-webhook` 는 `x-webhook-secret` 헤더를 검증합니다.
- Service Role 키로 `profiles` 테이블에 `id` 기준 upsert합니다.

5) 보안
- 반드시 Service Role Key는 서버에서만 사용하세요. 클라이언트에 노출 금지.
- `WEBHOOK_SECRET` 를 주기적으로 교체 권장.

부록: 프로필 테이블 스키마 예시 (SQL)
```sql
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text,
  phone text,
  gender text,
  interest text,
  avatar_url text,
  updated_at timestamptz default now()
);
```

