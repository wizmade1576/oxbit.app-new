-- Ensure external_id exists and is unique for upsert from ingest function
alter table if exists public.breaking_news add column if not exists external_id text;
create unique index if not exists breaking_news_external_id_key on public.breaking_news (external_id);

-- Optional helper columns (non-breaking):
alter table if exists public.breaking_news add column if not exists source text;
alter table if exists public.breaking_news add column if not exists url text;

