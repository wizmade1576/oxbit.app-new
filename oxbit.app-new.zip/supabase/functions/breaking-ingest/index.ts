// Supabase Edge Function (Deno) — Breaking News Ingest
// - Fetches external feeds (RSS and/or CryptoPanic JSON) and upserts into public.breaking_news
// - Requires: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
// - Optional: CRYPTOPANIC_TOKEN, FEED_SOURCES (comma-separated RSS URLs)

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

type Item = {
  title: string
  body?: string
  url?: string
  published_at?: string
  source?: string
}

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || ''
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
const CRYPTOPANIC_TOKEN = Deno.env.get('CRYPTOPANIC_TOKEN') || ''
const FEED_SOURCES = (Deno.env.get('FEED_SOURCES') || '').split(',').map(s => s.trim()).filter(Boolean)

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
})

function textBetween(xml: string, tag: string): string | undefined {
  const m = xml.match(new RegExp(`<${tag}[^>]*>([\s\S]*?)<\/${tag}>`, 'i'))
  if (!m) return undefined
  const v = m[1]?.replace(/<!\[CDATA\[(.*?)\]\]>/g, '$1')?.trim()
  return v
}

function parseRssItems(xml: string): Item[] {
  const items: Item[] = []
  const blocks = xml.match(/<item[\s\S]*?<\/item>/gi) || []
  for (const b of blocks) {
    const title = textBetween(b, 'title') || ''
    const link = textBetween(b, 'link') || ''
    const desc = textBetween(b, 'description') || ''
    const pub = textBetween(b, 'pubDate') || textBetween(b, 'updated') || undefined
    if (!title) continue
    items.push({ title, body: desc, url: link, published_at: pub, source: 'rss' })
  }
  return items
}

async function fetchRss(url: string): Promise<Item[]> {
  try {
    const res = await fetch(url, { headers: { 'accept': 'application/rss+xml,application/xml,text/xml;q=0.9,*/*;q=0.8' } })
    if (!res.ok) return []
    const xml = await res.text()
    return parseRssItems(xml)
  } catch { return [] }
}

async function fetchCryptoPanic(): Promise<Item[]> {
  if (!CRYPTOPANIC_TOKEN) return []
  try {
    const u = new URL('https://cryptopanic.com/api/v1/posts/')
    u.searchParams.set('auth_token', CRYPTOPANIC_TOKEN)
    u.searchParams.set('public', 'true')
    u.searchParams.set('kind', 'news')
    u.searchParams.set('filter', 'rising|hot|important')
    const res = await fetch(u.toString())
    if (!res.ok) return []
    const data = await res.json()
    const results = Array.isArray(data?.results) ? data.results : []
    return results.map((r: any) => ({
      title: String(r?.title || ''),
      body: String(r?.domain || ''),
      url: String(r?.url || ''),
      published_at: r?.published_at || r?.created_at || undefined,
      source: 'cryptopanic',
    })).filter((x: Item) => x.title)
  } catch { return [] }
}

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input)
  const hash = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('')
}

async function upsert(items: Item[]) {
  if (!items.length) return { inserted: 0 }
  const rows = await Promise.all(items.map(async (it) => {
    const keyBase = `${it.source || 'ext'}|${it.url || it.title}|${it.published_at || ''}`
    const external_id = await sha256Hex(keyBase)
    return {
      external_id,
      title: it.title?.slice(0, 300),
      body: it.body?.slice(0, 2000) || null,
      image_url: null,
      status: 'public',
      important: false,
      created_at: it.published_at || new Date().toISOString(),
      source: it.source || null,
      url: it.url || null,
    }
  }))
  const { error } = await supabase.from('breaking_news').upsert(rows, { onConflict: 'external_id' })
  if (error) throw error
  return { inserted: rows.length }
}

export async function handler(req: Request): Promise<Response> {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return new Response('Missing SUPABASE env', { status: 500 })
  }
  const url = new URL(req.url)
  const sourceParam = url.searchParams.get('rss')
  const feeds: string[] = []
  if (sourceParam) feeds.push(...sourceParam.split(',').map(s => s.trim()).filter(Boolean))
  if (FEED_SOURCES.length) feeds.push(...FEED_SOURCES)

  let items: Item[] = []
  // CryptoPanic first (optional)
  const cp = await fetchCryptoPanic()
  items.push(...cp)
  // RSS feeds
  if (feeds.length) {
    const batch = await Promise.all(feeds.map((u) => fetchRss(u)))
    for (const b of batch) items.push(...b)
  }

  // Basic de-duplication before upsert
  const seen = new Set<string>()
  items = items.filter((it) => {
    const k = `${it.title}|${it.url}`
    if (seen.has(k)) return false
    seen.add(k)
    return true
  })

  try {
    const { inserted } = await upsert(items)
    return Response.json({ ok: true, count: inserted })
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 })
  }
}

// Serve the function
Deno.serve(handler)

