// deno-lint-ignore-file no-explicit-any
import 'jsr:@supabase/functions-js/edge-runtime.d.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

async function ensureAdmin(jwt: string | undefined, url: string, anon: string, svc: string) {
  if (!jwt) return false
  const auth = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${jwt}` } } })
  const { data } = await auth.auth.getUser()
  const uid = data?.user?.id
  if (!uid) return false
  const sys = createClient(url, svc)
  const { data: prof } = await sys.from('profiles').select('role').eq('id', uid).maybeSingle()
  return prof?.role === 'admin'
}

Deno.serve(async (req) => {
  const method = req.method
  const url = new URL(req.url)
  const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
  const ANON = Deno.env.get('SUPABASE_ANON_KEY')!
  const SERVICE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const sys = createClient(SUPABASE_URL, SERVICE)

  if (method === 'GET') {
    const limit = Number(url.searchParams.get('limit') ?? 30)
    const status = url.searchParams.get('status') ?? 'public'
    const { data, error } = await sys
      .from('breaking_news')
      .select('*')
      .eq('status', status)
      .order('created_at', { ascending: false })
      .limit(limit)
    return new Response(JSON.stringify(error ? { error } : data), { headers: { 'content-type': 'application/json' } })
  }

  const jwt = req.headers.get('authorization')?.replace(/Bearer\s+/i, '')
  const ok = await ensureAdmin(jwt, SUPABASE_URL, ANON, SERVICE)
  if (!ok) return new Response('forbidden', { status: 403 })

  if (method === 'POST') {
    const body = await req.json()
    const payload: any = {
      title: String(body.title || '').trim(),
      body: body.body || null,
      important: !!body.important,
      image_url: body.image_url || null,
      status: body.status || 'public',
    }
    if (!payload.title) return new Response('title required', { status: 400 })
    const { data, error } = await sys.from('breaking_news').insert(payload).select('*').single()
    return new Response(JSON.stringify(error ? { error } : data), { headers: { 'content-type': 'application/json' } })
  }

  if (method === 'PATCH') {
    const id = url.pathname.split('/').pop()
    const patch = await req.json()
    const { data, error } = await sys.from('breaking_news').update(patch).eq('id', id).select('*').single()
    return new Response(JSON.stringify(error ? { error } : data), { headers: { 'content-type': 'application/json' } })
  }

  if (method === 'DELETE') {
    const id = url.pathname.split('/').pop()
    const { error } = await sys.from('breaking_news').delete().eq('id', id)
    return new Response(JSON.stringify(error ? { error } : { ok: true }), { headers: { 'content-type': 'application/json' } })
  }

  return new Response('method not allowed', { status: 405 })
})

