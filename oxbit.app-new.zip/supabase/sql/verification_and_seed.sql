-- Verification and seed helpers
-- Run pieces as needed in Supabase SQL Editor

-- 1) Verify bucket exists
-- select id, name, public from storage.buckets where id = 'breaking';

-- 2) Verify profiles trigger/backfill needs
-- List users without profile rows
-- select u.id, u.email from auth.users u
-- left join public.profiles p on p.id = u.id
-- where p.id is null;

-- If needed, backfill using service-role (Edge/Server):
-- select public.backfill_profiles();

-- 3) Verify settings value
-- select key, value from public.settings where key = 'defaultBreakingStatus';

-- 4) Seed data (idempotent)
-- Announcements
insert into public.announcements (title, body, pinned)
values
  ('Welcome to the app', '첫 공지입니다. 즐거운 사용 되세요!', true),
  ('Update Notes', '이번 업데이트에는 성능 개선이 포함되었습니다.', false)
on conflict do nothing;

-- Breaking news
insert into public.breaking_news (title, body, important, image_url, status)
values
  ('Market Rally', 'BTC 급등 소식', true, null, 'public'),
  ('Admin Draft', '검토중인 내부 기사', false, null, 'private')
on conflict do nothing;

-- Positions (demo)
insert into public.positions (nick, image_url, symbol, side, lev, qty, entry, mark, pnl_pct, pnl_krw, status, rate_snapshot)
values
  ('alpha', null, 'BTCUSDT', 'Long', 10, 0.1, 60000, 60500, 0.83, 100000, 'open', 1320),
  ('beta',  null, 'ETHUSDT', 'Short', 5,  1.5,  3200,  3150,  -1.56, -50000, 'open', 980)
on conflict do nothing;

-- 5) Quick reads
-- select * from public.announcements order by created_at desc;
-- select id, title, status, created_at from public.breaking_news order by created_at desc;
-- select nick, symbol, side, lev, pnl_pct from public.positions order by created_at desc;

