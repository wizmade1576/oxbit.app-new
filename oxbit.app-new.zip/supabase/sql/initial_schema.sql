-- Supabase initial schema and RLS policies
-- Run in Supabase SQL Editor

begin;

-- 0) Ensure storage bucket 'breaking' exists and is public
insert into storage.buckets (id, name, public)
values ('breaking', 'breaking', true)
on conflict (id) do update set public = excluded.public;

-- 1) profiles: create if missing, ensure role column
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text check (role in ('admin','user')) default 'user',
  username text,
  full_name text,
  phone text,
  signup_source text,
  signup_referrer text,
  signup_meta jsonb,
  avatar_url text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table if exists public.profiles
  add column if not exists role text check (role in ('admin','user')) default 'user';
alter table if exists public.profiles
  add column if not exists phone text,
  add column if not exists signup_source text,
  add column if not exists signup_referrer text,
  add column if not exists signup_meta jsonb;

alter table public.profiles enable row level security;

-- profiles RLS: users can read/update only their row (enables role check in policies)
drop policy if exists profiles_read_own on public.profiles;
create policy profiles_read_own on public.profiles
  for select using (auth.uid() = id);

drop policy if exists profiles_insert_self on public.profiles;
create policy profiles_insert_self on public.profiles
  for insert with check (auth.uid() = id);

drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- Admins can read all profiles
drop policy if exists profiles_admin_read_all on public.profiles;
create policy profiles_admin_read_all on public.profiles
  for select using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Admins can write any profile (for disabled flags etc.)
drop policy if exists profiles_admin_write on public.profiles;
create policy profiles_admin_write on public.profiles
  for all using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Add soft-delete/disable fields on profiles
alter table if exists public.profiles
  add column if not exists disabled boolean default false,
  add column if not exists disabled_at timestamp with time zone,
  add column if not exists disabled_reason text;

-- Secure RPC: admin-only user listing with email join
create or replace function public.admin_list_users(
  search text default null,
  page_size int default 20,
  page_no int default 1,
  sort_by text default 'created_at',
  sort_dir text default 'desc'
)
returns table (
  id uuid,
  email text,
  phone text,
  role text,
  username text,
  full_name text,
  created_at timestamp with time zone,
  disabled boolean,
  email_confirmed_at timestamp with time zone,
  phone_confirmed_at timestamp with time zone,
  last_sign_in_at timestamp with time zone,
  banned_until timestamp with time zone,
  signup_source text,
  signup_referrer text
)
language plpgsql
security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin') then
    raise exception 'Forbidden: admin only';
  end if;
  return query
  with base as (
    select p.id, u.email, u.phone, p.role, p.username, p.full_name, p.created_at, p.disabled,
           u.email_confirmed_at, u.phone_confirmed_at, u.last_sign_in_at, u.banned_until,
           p.signup_source, p.signup_referrer
    from auth.users u
    join public.profiles p on p.id = u.id
    where (search is null
           or u.email ilike '%' || search || '%'
           or u.phone ilike '%' || search || '%'
           or coalesce(p.username,'') ilike '%' || search || '%'
           or coalesce(p.full_name,'') ilike '%' || search || '%')
  )
  select * from base
  order by
    case when sort_by = 'email' and sort_dir = 'asc' then email end asc,
    case when sort_by = 'email' and sort_dir = 'desc' then email end desc,
    case when sort_by = 'phone' and sort_dir = 'asc' then phone end asc,
    case when sort_by = 'phone' and sort_dir = 'desc' then phone end desc,
    case when sort_by = 'role' and sort_dir = 'asc' then role end asc,
    case when sort_by = 'role' and sort_dir = 'desc' then role end desc,
    case when sort_by = 'created_at' and sort_dir = 'asc' then created_at end asc,
    case when sort_by = 'created_at' and sort_dir = 'desc' then created_at end desc,
    case when sort_by = 'last_sign_in_at' and sort_dir = 'asc' then last_sign_in_at end asc,
    case when sort_by = 'last_sign_in_at' and sort_dir = 'desc' then last_sign_in_at end desc,
    case when sort_by = 'banned_until' and sort_dir = 'asc' then banned_until end asc,
    case when sort_by = 'banned_until' and sort_dir = 'desc' then banned_until end desc
  limit greatest(page_size, 1)
  offset greatest(page_no - 1, 0) * greatest(page_size, 1);
end;
$$;

revoke all on function public.admin_list_users(text, int, int, text, text) from public;
grant execute on function public.admin_list_users(text, int, int, text, text) to anon, authenticated;

-- Count helper for pagination
create or replace function public.admin_count_users(search text default null)
returns integer
language plpgsql
security definer set search_path = public
as $$
declare
  total int;
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin') then
    raise exception 'Forbidden: admin only';
  end if;
  select count(*) into total
  from auth.users u
  join public.profiles p on p.id = u.id
  where (search is null
         or u.email ilike '%' || search || '%'
         or coalesce(p.username,'') ilike '%' || search || '%'
         or coalesce(p.full_name,'') ilike '%' || search || '%');
  return total;
end;
$$;

revoke all on function public.admin_count_users(text) from public;
grant execute on function public.admin_count_users(text) to anon, authenticated;

-- Moderation logs table
create table if not exists public.user_moderation_logs (
  id bigserial primary key,
  user_id uuid references auth.users(id) on delete set null,
  actor_id uuid references auth.users(id) on delete set null,
  action text check (action in ('ban','unban','delete','set_role','disable','enable','resend_confirm')) not null,
  reason text,
  note text,
  meta jsonb default '{}'::jsonb,
  created_at timestamp with time zone default now()
);
alter table public.user_moderation_logs enable row level security;

-- Admins can read/insert logs
drop policy if exists logs_admin_all on public.user_moderation_logs;
create policy logs_admin_all on public.user_moderation_logs
  for all using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Helper to write logs from SQL if needed
create or replace function public.log_moderation(
  actor uuid,
  target uuid,
  action text,
  reason text default null,
  note text default null,
  meta jsonb default '{}'::jsonb
)
returns void
language plpgsql
security definer set search_path = public
as $$
declare
  caller uuid := auth.uid();
begin
  if caller is null or caller <> actor then
    raise exception 'Forbidden';
  end if;
  if not exists (select 1 from public.profiles p where p.id = caller and p.role = 'admin') then
    raise exception 'Forbidden: admin only';
  end if;
  insert into public.user_moderation_logs(user_id, actor_id, action, reason, note, meta)
  values (target, caller, action, reason, note, meta);
end;
$$;

revoke all on function public.log_moderation(uuid, uuid, text, text, text, jsonb) from public;
grant execute on function public.log_moderation(uuid, uuid, text, text, text, jsonb) to anon, authenticated;

-- Admin logs listing with emails (security definer)
create or replace function public.admin_list_logs(
  search text default null,
  action_filter text default null,
  page_size int default 20,
  page_no int default 1
)
returns table (
  id bigint,
  user_id uuid,
  user_email text,
  actor_id uuid,
  actor_email text,
  action text,
  reason text,
  note text,
  meta jsonb,
  created_at timestamp with time zone
)
language plpgsql
security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin') then
    raise exception 'Forbidden: admin only';
  end if;
  return query
  with base as (
    select l.id, l.user_id, tu.email as user_email,
           l.actor_id, au.email as actor_email,
           l.action, l.reason, l.note, l.meta, l.created_at
    from public.user_moderation_logs l
    left join auth.users tu on tu.id = l.user_id
    left join auth.users au on au.id = l.actor_id
    where (action_filter is null or l.action = action_filter)
      and (search is null or
           coalesce(tu.email,'') ilike '%' || search || '%' or
           coalesce(au.email,'') ilike '%' || search || '%' or
           coalesce(l.reason,'') ilike '%' || search || '%' or
           coalesce(l.note,'') ilike '%' || search || '%')
  )
  select * from base
  order by created_at desc
  limit greatest(page_size, 1)
  offset greatest(page_no - 1, 0) * greatest(page_size, 1);
end;
$$;

revoke all on function public.admin_list_logs(text, text, int, int) from public;
grant execute on function public.admin_list_logs(text, text, int, int) to anon, authenticated;

-- Auto-create a profile row when a new auth user signs up
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id)
  values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 2) breaking_news
create table if not exists public.breaking_news (
  id bigserial primary key,
  title text not null,
  body text,
  important boolean default false,
  image_url text,
  status text default 'public',
  created_at timestamp with time zone default now()
);
create index if not exists idx_breaking_created_at on public.breaking_news (created_at desc);
create index if not exists idx_breaking_status on public.breaking_news (status);
alter table public.breaking_news enable row level security;

-- policies for breaking_news (drop then create for idempotency)
drop policy if exists breaking_public_read on public.breaking_news;
create policy breaking_public_read
  on public.breaking_news
  for select
  using (status = 'public');

drop policy if exists breaking_admin_read_all on public.breaking_news;
create policy breaking_admin_read_all
  on public.breaking_news
  for select
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

drop policy if exists breaking_admin_write on public.breaking_news;
create policy breaking_admin_write
  on public.breaking_news
  for all
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- 3) announcements
create table if not exists public.announcements (
  id bigserial primary key,
  title text not null,
  body text,
  pinned boolean default false,
  created_at timestamp with time zone default now()
);
alter table public.announcements enable row level security;

drop policy if exists ann_read_all on public.announcements;
create policy ann_read_all on public.announcements for select using (true);

drop policy if exists ann_admin_write on public.announcements;
create policy ann_admin_write on public.announcements for all
 using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'))
 with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'));

-- 4) settings
create table if not exists public.settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamp with time zone default now()
);
alter table public.settings enable row level security;

drop policy if exists settings_read_all on public.settings;
create policy settings_read_all on public.settings for select using (true);

drop policy if exists settings_admin_write on public.settings;
create policy settings_admin_write on public.settings for all
 using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'))
 with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'));

-- store JSON string value "public"
insert into public.settings(key, value) values ('defaultBreakingStatus', '"public"'::jsonb)
on conflict (key) do nothing;

-- 5) positions
create table if not exists public.positions (
  id bigserial primary key,
  nick text not null,
  image_url text,
  symbol text not null,
  side text check (side in ('Long','Short')) not null,
  lev int check (lev between 2 and 100),
  qty numeric,
  entry numeric,
  mark numeric,
  pnl_pct numeric,
  pnl_krw numeric,
  status text,
  rate_snapshot numeric,
  created_at timestamp with time zone default now()
);
create index if not exists idx_positions_nick on public.positions(nick);
create index if not exists idx_positions_created on public.positions(created_at desc);
alter table public.positions enable row level security;

drop policy if exists positions_read_all on public.positions;
create policy positions_read_all on public.positions for select using (true);

drop policy if exists positions_admin_write on public.positions;
create policy positions_admin_write on public.positions for all
 using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'))
 with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role='admin'));

-- 6) storage.objects policies (for bucket 'breaking')
-- Read public
drop policy if exists storage_breaking_read on storage.objects;
create policy storage_breaking_read
on storage.objects for select
using (bucket_id = 'breaking');

-- Admin write
drop policy if exists storage_breaking_admin_write on storage.objects;
create policy storage_breaking_admin_write
on storage.objects for all
using (bucket_id = 'breaking'
   and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
with check (bucket_id = 'breaking'
   and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

commit;
