-- Admin utilities: lookups and safe role management
-- Run snippets in Supabase SQL Editor as needed.


-- =============================================================
-- Realtime enable for public.breaking_news (idempotent helpers)
-- Run in Supabase SQL Editor when Realtime is not firing
-- =============================================================

begin;

-- 1) Ensure table is in supabase_realtime publication (idempotent)
do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'breaking_news'
  ) then
    execute 'alter publication supabase_realtime add table public.breaking_news';
  end if;
end$$;

-- 2) Optionally include previous row data for updates/deletes (safe to re-run)
alter table public.breaking_news replica identity full;

commit;

-- 3) Verify publication membership
select pubname, schemaname, tablename
from pg_publication_tables
where pubname = 'supabase_realtime'
  and schemaname = 'public'
  and tablename = 'breaking_news';

-- 4) Optional: quick test insert (uncomment to test Realtime delivery)
-- insert into public.breaking_news (title, body, status, important)
-- values ('실시간 테스트', 'supabase realtime test', 'public', true)
-- returning id, created_at;

-- 1) Look up a user UUID by email
-- Usage: replace your@email.com
-- select u.id, u.email, p.role, p.username, p.full_name, p.created_at
-- from auth.users u
-- left join public.profiles p on p.id = u.id
-- where lower(u.email) = lower('your@email.com');

-- 2) List all admins (email + profile)
-- select u.id, u.email, p.role, p.username, p.full_name, p.created_at
-- from auth.users u
-- join public.profiles p on p.id = u.id
-- where p.role = 'admin'
-- order by p.created_at;

-- 3) Promote/Demote by UUID (manual)
-- update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-000000000000';
-- update public.profiles set role = 'user'  where id = '00000000-0000-0000-0000-000000000000';

-- 4) Promote/Demote by Email (manual; resolves email -> uuid)
-- with target as (
--   select id from auth.users where lower(email) = lower('your@email.com')
-- )
-- update public.profiles p
-- set role = 'admin'
-- from target t
-- where p.id = t.id;

-- 5) Service-role gated function: set role by UUID
create or replace function public.admin_set_role(target uuid, new_role text)
returns void
language plpgsql
security definer set search_path = public
as $$
begin
  if current_setting('request.jwt.claim.role', true) is distinct from 'service_role' then
    raise exception 'Not allowed: service_role only';
  end if;
  if new_role not in ('admin','user') then
    raise exception 'Invalid role: %', new_role;
  end if;
  update public.profiles set role = new_role where id = target;
end;
$$;

revoke all on function public.admin_set_role(uuid, text) from public;
grant execute on function public.admin_set_role(uuid, text) to anon, authenticated; -- allowed to call, but will pass only with service_role

-- 6) Service-role gated function: set role by Email
create or replace function public.admin_set_role_by_email(target_email text, new_role text)
returns void
language plpgsql
security definer set search_path = public
as $$
declare
  uid uuid;
begin
  if current_setting('request.jwt.claim.role', true) is distinct from 'service_role' then
    raise exception 'Not allowed: service_role only';
  end if;
  select id into uid from auth.users where lower(email) = lower(target_email);
  if uid is null then
    raise exception 'User not found for email %', target_email;
  end if;
  perform public.admin_set_role(uid, new_role);
end;
$$;

revoke all on function public.admin_set_role_by_email(text, text) from public;
grant execute on function public.admin_set_role_by_email(text, text) to anon, authenticated; -- service_role check inside

-- 7) Optional: ensure at least one admin exists (first user)
-- insert into public.profiles(id, role)
-- select id, 'admin'
-- from auth.users
-- where not exists (
--   select 1 from public.profiles where role = 'admin'
-- )
-- order by created_at asc
-- limit 1
-- on conflict (id) do update set role = excluded.role;

-- 8) Backfill profiles for existing users (service-role only)
create or replace function public.backfill_profiles()
returns integer
language plpgsql
security definer set search_path = public
as $$
declare
  inserted integer;
begin
  if current_setting('request.jwt.claim.role', true) is distinct from 'service_role' then
    raise exception 'Not allowed: service_role only';
  end if;
  insert into public.profiles(id)
  select u.id
  from auth.users u
  left join public.profiles p on p.id = u.id
  where p.id is null
  on conflict do nothing;
  get diagnostics inserted = ROW_COUNT;
  return inserted;
end;
$$;

revoke all on function public.backfill_profiles() from public;
grant execute on function public.backfill_profiles() to anon, authenticated; -- gated by service_role check
