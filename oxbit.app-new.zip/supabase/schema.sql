-- Supabase schema for Oxbit.app MVP
-- Enable necessary extensions
create extension if not exists pgcrypto with schema public;

-- Breaking news table
create table if not exists public.breaking_news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  created_at timestamptz not null default now(),
  author uuid references auth.users(id)
);

-- Realtime publication (usually enabled by default)
alter publication supabase_realtime add table public.breaking_news;

-- Row Level Security
alter table public.breaking_news enable row level security;

-- Public read policy
create policy if not exists "Public read breaking news"
on public.breaking_news for select
to anon, authenticated
using (true);

-- Admin-only insert policy (example: restrict to specific email domain)
create policy if not exists "Admins insert breaking news"
on public.breaking_news for insert
to authenticated
with check (
  -- Replace example.com with your domain or adjust condition
  position('@example.com' in coalesce(auth.email(), '')) > 0
);

-- Optional: authenticated users can delete their own entries
create policy if not exists "Owner delete own breaking news"
on public.breaking_news for delete
to authenticated
using (author = auth.uid());

-- Helpful index
create index if not exists idx_breaking_news_created_at on public.breaking_news (created_at desc);

